# Lia AI — Google Play Store Release & Submission Guide

## 1. Build Artifact to Upload
- **Flavor**: `play` ONLY (`com.Lia.assistant`, `bundlePlayRelease`).
- **Command**: `./gradlew bundlePlayRelease` (or `gradle bundlePlayRelease` inside AI Studio).
- **Output Path**: `app/build/outputs/bundle/playRelease/app-play-release.aab`
- **Do NOT upload** `direct` builds to Google Play (`direct` contains `AccessibilityService`, `NotificationListenerService`, `QUERY_ALL_PACKAGES`, and `SYSTEM_ALERT_WINDOW`).

## 2. Play Store Listing Copy
- **App Title** (<= 30 chars): `Lia AI`
- **Short Description** (<= 80 chars): `Voice & chat AI companion in Hindi, Hinglish & English with live 3D Website Forge.`
- **Full Description**:
  Meet Lia AI — a calm, expressive voice and chat companion powered by Gemini.

  - Real-time full-duplex voice conversation with natural interruption handling
  - Speaks and understands Hindi, Hinglish, and English seamlessly
  - 10 customizable personalities (Normal, Friendly, Professional, Funny, Companion, Affectionate, Teacher, Developer, Foodie, Nautanki)
  - 7 customizable 3D orb styles & adaptive Night/Light design system
  - Website Forge: describe a webpage and watch a live 3D website generate and preview right on your device
  - Privacy first: bring your own Gemini API key stored locally on-device

## 3. Data Safety Answers
- **Does your app collect or share any required user data types?** No developer-hosted collection. Requests are sent directly from the user's device to Google Gemini APIs using the user's own API key.
- **Data stored locally on device**:
  - Gemini API key (user-provided, private `SharedPreferences`, never logged or sent to third parties)
  - Typed conversation history & assistant preferences (private app storage, deletable inside Privacy/History)
  - Generated website HTML files (`filesDir/Websites/`)
- **Encryption in transit**: All Gemini REST/SSE and Live WebSocket traffic uses HTTPS/WSS (`TLS`).
- **Deletion mechanism**: Users can clear conversation history and delete individual generated websites in-app, or clear the API key at any time.

## 4. Permission Justifications (`play` flavor)
- `android.permission.RECORD_AUDIO`: Essential for live voice conversations in Voice Mode. Requested at runtime when opening Voice Mode.
- `android.permission.FOREGROUND_SERVICE` & `android.permission.FOREGROUND_SERVICE_MICROPHONE`: Keeps an active voice session alive with a persistent ongoing notification + Stop action when the user minimizes Voice Mode or switches screens.
- `android.permission.POST_NOTIFICATIONS` (API 33+): Shows the active voice session notification and notifies the user when a Website Forge build finishes while in the background.
- `android.permission.READ_CONTACTS`: Optional runtime permission used only when the user explicitly asks Lia AI to call or compose a message to a contact by name.
- `android.permission.CALL_PHONE`: Optional runtime permission used to initiate a phone call directly when requested; falls back gracefully to `ACTION_DIAL` if denied.

## 5. Pre-Submission Checklist
- [ ] `gradle testPlayDebugUnitTest testDirectDebugUnitTest` passes 100%.
- [ ] Verify `app/build/outputs/bundle/playRelease/app-play-release.aab` builds with `isMinifyEnabled = true` and `isShrinkResources = true`.
- [ ] Confirm `play` merged manifest has ZERO `BIND_ACCESSIBILITY_SERVICE`, `BIND_NOTIFICATION_LISTENER_SERVICE`, `QUERY_ALL_PACKAGES`, `SYSTEM_ALERT_WINDOW`, or `SEND_SMS`.
- [ ] Confirm `keystore.properties` and any `.jks` / `licensing_config.json` files remain git-ignored and untracked.
- [ ] Test TalkBack focus order, Dark/Light themes, and Reduced Motion toggle.
- [ ] Capture phone & tablet screenshots for Play Console Store Listing.
