# Lia AI repair and merge notes

## Source strategy

The original `lia-ai.zip` was used as the project base because it contains the Direct and Play product flavors and their feature-specific source sets. The updated ZIP had removed those flavor source sets and moved flavor-specific classes into `main`, including empty/stub implementations. Those replacements were not copied over the original implementations.

## Preserved from the original project

- Direct and Play product flavors
- Direct Accessibility Service and its XML configuration
- WhatsApp notification listener and WhatsApp agent
- Social Media Agent and screen automation support
- Direct and Play ActionExecutor implementations
- Flavor-specific access-key and navigation implementations
- Flavor-specific tests
- Existing Gemini chat/voice, Website Forge, UI, app actions and other original source files

## Applied changes

- Added launcher-intent package visibility query from the updated manifest.
- Applied the updated message-bubble icon compatibility adjustment.
- Applied the updated 3D orb shader safety fallback.
- Applied the updated splash theme resources.
- Added a GitHub Actions workflow that runs both flavor test tasks and builds both debug APK variants.
- Replaced stale GitHub build instructions with phone-friendly GitHub Actions steps.

## Limitations that need owner configuration or device verification

- The Direct flavor's online access-key service needs `app/src/direct/assets/licensing_config.json` with the real licensing endpoint. That endpoint/backend was not present in either ZIP, so it cannot be invented here.
- Gemini calls need a valid user API key.
- Android Accessibility, notification listener, overlay, microphone and contact/call permissions need real-device permission testing.
- This environment does not have Gradle installed and cannot download build dependencies, so a local Android compile/test could not be run here. GitHub Actions is configured to perform the actual Gradle tests and APK builds; its result must be checked after uploading this project.
