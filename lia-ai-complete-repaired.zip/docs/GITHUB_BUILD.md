# Build Lia AI APKs with GitHub Actions

This repository has two Android product flavors:

- **Direct**: includes the Accessibility Service, notification listener, screen automation and direct-distribution features. Do not distribute this flavor through Google Play.
- **Play**: excludes the direct-only accessibility and notification-listener components and is the flavor intended for Google Play policy review.

## Build from a phone

1. Extract the complete ZIP.
2. Create a GitHub repository and upload the extracted project files and folders to its root. Do not upload the ZIP as a single file.
3. Open the repository's **Actions** tab.
4. Select **Build Lia AI APKs**.
5. Tap **Run workflow** (or push/commit to `main` or `master` to trigger it automatically).
6. Wait until the workflow is green.
7. Open the completed workflow run and download the **Lia-AI-Android-APKs** artifact.
8. Extract that artifact. It contains the Direct and Play debug APKs.

The workflow installs Gradle 9.3.1 and Android SDK platform/build-tools 36 on GitHub's runner. It creates a temporary debug keystore for that build. No local Android Studio or Termux is needed.

## Important notes

- The workflow builds **debug APKs**, not a signed Play Store release. A production release needs your own upload keystore and secure GitHub Actions secrets.
- Debug APKs are for testing. Do not publish them as production releases.
- The Direct flavor's access-key activation requires your own licensing backend. The Direct `AccessKeyManager` reads `app/src/direct/assets/licensing_config.json`, which is intentionally not included because this project ZIP does not contain a licensing endpoint. Add that file with your real endpoint before expecting online key activation to work. Do not put private credentials in source control.
- Gemini access still requires a valid Gemini API key configured in the app.
- Android permissions such as microphone, contacts, Accessibility, overlay and notification access must be granted by the user on the device. Accessibility automation only works for actions supported by the target app and Android version.

## Build tasks

```bash
gradle :app:testDirectDebugUnitTest :app:testPlayDebugUnitTest
gradle :app:assembleDirectDebug :app:assemblePlayDebug
```

Expected APK output directories:

- `app/build/outputs/apk/direct/debug/`
- `app/build/outputs/apk/play/debug/`
