# Lia AI for Android

Lia AI is an Android AI assistant project with Gemini chat/voice, a 3D assistant orb, Website Forge, phone actions and optional Direct-flavor automation features.

## Build APKs using GitHub (phone-friendly)

1. Extract this ZIP.
2. Upload all extracted files and folders to the root of a GitHub repository.
3. Open **Actions** in GitHub.
4. Select **Build Lia AI APKs** and tap **Run workflow**.
5. After the run succeeds, download the **Lia-AI-Android-APKs** artifact from that run and extract it.

The artifact contains the Direct and Play debug APKs. See [docs/GITHUB_BUILD.md](docs/GITHUB_BUILD.md) for details and important setup notes.

## Variants

- `direct`: includes Accessibility Service, notification listener and automation components. It is not the Play Store variant.
- `play`: intended for Google Play policy review and excludes Direct-only automation components.

## Requirements

- Android 8.0 (API 26) or later.
- A valid Gemini API key configured in the app.
- User-granted Android permissions for the features being used.

The Direct flavor's access-key activation additionally requires a licensing endpoint configured in `app/src/direct/assets/licensing_config.json`. See `docs/REPAIR_NOTES.md`.
