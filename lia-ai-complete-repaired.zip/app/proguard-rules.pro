# Keep org.json classes used across Gemini REST/WebSocket/SSE parsing
-keep class org.json.** { *; }
-dontwarn org.json.**

# Keep Forge WebView JavascriptInterface methods
-keepclassmembers class com.Lia.assistant.ui.screens.forge.ForgeJsBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep OkHttp / Kotlin coroutines metadata
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-dontwarn okhttp3.**
-dontwarn okio.**
