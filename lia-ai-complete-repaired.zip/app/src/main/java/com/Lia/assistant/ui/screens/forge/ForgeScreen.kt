package com.Lia.assistant.ui.screens.forge

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.Lia.assistant.forge.ForgeController
import com.Lia.assistant.forge.ForgePhase
import com.Lia.assistant.forge.ForgeStartResult
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaSpacing

@Composable
fun ForgeScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    val colors = LocalNovaColors.current
    val state by ForgeController.state.collectAsState()

    var webGlFailed by remember { mutableStateOf(false) }
    var finalPainted by remember(state.buildId) { mutableStateOf(false) }
    var revealed by remember(state.buildId) { mutableStateOf(false) }
    var idlePrompt by remember { mutableStateOf("") }

    val lowRam = remember(context) {
        (context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.isLowRamDevice == true
    }

    DisposableEffect(Unit) {
        ForgeController.isForgeScreenVisible = true
        onDispose {
            ForgeController.isForgeScreenVisible = false
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // Immersive mode while BUILDING
    LaunchedEffect(state.phase) {
        val window = (view.context as? Activity)?.window ?: return@LaunchedEffect
        val controller = WindowCompat.getInsetsController(window, view)
        if (state.phase == ForgePhase.BUILDING) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // If fallback scene is active on DONE once final page painted, finish reveal directly
    LaunchedEffect(state.phase, finalPainted, webGlFailed, lowRam) {
        if (state.phase == ForgePhase.DONE && finalPainted && (webGlFailed || lowRam)) {
            revealed = true
        }
    }

    val finalHtml = remember(state.buildId, state.phase, state.file) {
        if (state.phase == ForgePhase.DONE) {
            state.file?.takeIf { it.exists() }?.let { runCatching { it.readText() }.getOrNull() }
                ?: ForgeController.partialHtml()
        } else {
            ForgeController.partialHtml()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (state.phase) {
            ForgePhase.IDLE -> {
                ForgeFallbackScene(state = state, modifier = Modifier.fillMaxSize())
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(NovaSpacing.xl),
                    contentAlignment = Alignment.Center
                ) {
                    NovaGlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Website Forge",
                            style = MaterialTheme.typography.headlineMedium,
                            color = colors.textPrimary
                        )
                        Spacer(Modifier.height(NovaSpacing.sm))
                        Text(
                            text = "Describe any website or landing page. Lia will stream a live 3D experience.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textSecondary
                        )
                        Spacer(Modifier.height(NovaSpacing.lg))
                        NovaTextField(
                            value = idlePrompt,
                            onValueChange = { idlePrompt = it },
                            placeholder = "e.g., Specialty coffee shop in Mumbai",
                            singleLine = false,
                            maxLines = 3,
                            testTag = "forge_idle_input"
                        )
                        Spacer(Modifier.height(NovaSpacing.lg))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md)
                        ) {
                            NovaButton(
                                text = "Back",
                                style = NovaButtonStyle.SECONDARY,
                                onClick = onBack,
                                modifier = Modifier.weight(1f)
                            )
                            NovaButton(
                                text = "Ignite Forge",
                                enabled = idlePrompt.isNotBlank(),
                                onClick = {
                                    val res = ForgeController.start(context, idlePrompt)
                                    if (res != ForgeStartResult.Started) {
                                        Toast.makeText(context, res.spokenMessage, Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                testTag = "forge_ignite_button"
                            )
                        }
                    }
                }
            }

            ForgePhase.BUILDING, ForgePhase.DONE -> {
                val showFinalSite = state.phase == ForgePhase.DONE && revealed

                if (finalHtml.isNotBlank()) {
                    GeneratedSiteView(
                        html = finalHtml,
                        isFinal = state.phase == ForgePhase.DONE,
                        isLowRam = lowRam,
                        onFinalPainted = { finalPainted = true },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                if (!showFinalSite) {
                    if (lowRam || webGlFailed) {
                        ForgeFallbackScene(state = state, modifier = Modifier.fillMaxSize())
                    } else {
                        ForgeWebGlScene(
                            state = state,
                            triggerReveal = state.phase == ForgePhase.DONE && finalPainted,
                            onRevealFinished = { revealed = true },
                            onWebGlFailed = { webGlFailed = true },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    ForgeHud(
                        state = state,
                        onCancel = { ForgeController.cancel() },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    ResultToolbar(
                        currentFile = state.file,
                        onBack = onBack,
                        onEdit = { change ->
                            val res = ForgeController.edit(context, change)
                            if (res != ForgeStartResult.Started) {
                                Toast.makeText(context, res.spokenMessage, Toast.LENGTH_LONG).show()
                            }
                        },
                        onRebuild = {
                            val res = ForgeController.retry(context)
                            if (res != ForgeStartResult.Started) {
                                Toast.makeText(context, res.spokenMessage, Toast.LENGTH_LONG).show()
                            }
                        },
                        onOpenSaved = { file -> ForgeController.openSaved(file) },
                        onDeletedCurrent = onBack,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            ForgePhase.FAILED, ForgePhase.CANCELLED -> {
                ForgeFallbackScene(state = state, modifier = Modifier.fillMaxSize())
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(NovaSpacing.xl),
                    contentAlignment = Alignment.Center
                ) {
                    NovaGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = colors.error.copy(alpha = 0.6f)
                    ) {
                        Text(
                            text = if (state.phase == ForgePhase.CANCELLED) "Build Cancelled" else "Forge Paused",
                            style = MaterialTheme.typography.headlineMedium,
                            color = colors.textPrimary
                        )
                        Spacer(Modifier.height(NovaSpacing.sm))
                        Text(
                            text = state.error ?: "The build did not complete.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = colors.textSecondary
                        )
                        Spacer(Modifier.height(NovaSpacing.xl))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            NovaButton(
                                text = "Back",
                                style = NovaButtonStyle.SECONDARY,
                                onClick = {
                                    ForgeController.reset()
                                    onBack()
                                },
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(NovaSpacing.md))
                            NovaButton(
                                text = "Retry",
                                onClick = {
                                    val res = ForgeController.retry(context)
                                    if (res != ForgeStartResult.Started) {
                                        Toast.makeText(context, res.spokenMessage, Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
