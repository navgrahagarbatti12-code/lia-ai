package com.Lia.assistant.ui.fx

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaMotion

@Composable
fun ListeningEdgeGlow(
    state: NovaOrbState,
    amplitude: Float,
    modifier: Modifier = Modifier
) {
    val active = state != NovaOrbState.IDLE
    val targetAlpha by animateFloatAsState(
        targetValue = if (active) (0.52f + amplitude.coerceIn(0f, 1f) * 0.38f) else 0f,
        animationSpec = tween(NovaMotion.NORMAL_MS),
        label = "edge_glow_alpha"
    )
    if (targetAlpha <= 0.01f) return

    val glowColor = when (state) {
        NovaOrbState.SPEAKING -> Color(0xFFFF6FAE)
        NovaOrbState.ERROR -> Color(0xFFFF7A85)
        else -> Color(0xFF8B5CF6)
    }

    val reducedMotion = LocalNovaReducedMotion.current
    val pulseTransition = rememberInfiniteTransition(label = "edge_pulse")
    val pulse by pulseTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "edge_pulse_val"
    )
    val effectiveAlpha = targetAlpha * if (reducedMotion) 1f else pulse

    Canvas(modifier = modifier.fillMaxSize()) {
        val edge = 26.dp.toPx()
        val w = size.width
        val h = size.height
        val c0 = glowColor.copy(alpha = effectiveAlpha)
        val c1 = Color.Transparent

        // Top edge
        drawRect(
            brush = Brush.verticalGradient(listOf(c0, c1), startY = 0f, endY = edge),
            topLeft = Offset.Zero,
            size = androidx.compose.ui.geometry.Size(w, edge)
        )
        // Bottom edge
        drawRect(
            brush = Brush.verticalGradient(listOf(c1, c0), startY = h - edge, endY = h),
            topLeft = Offset(0f, h - edge),
            size = androidx.compose.ui.geometry.Size(w, edge)
        )
        // Left edge
        drawRect(
            brush = Brush.horizontalGradient(listOf(c0, c1), startX = 0f, endX = edge),
            topLeft = Offset.Zero,
            size = androidx.compose.ui.geometry.Size(edge, h)
        )
        // Right edge
        drawRect(
            brush = Brush.horizontalGradient(listOf(c1, c0), startX = w - edge, endX = w),
            topLeft = Offset(w - edge, 0f),
            size = androidx.compose.ui.geometry.Size(edge, h)
        )
    }
}

@Composable
fun ListeningEdgeGlowOverlayHost(
    state: NovaOrbState,
    amplitude: Float
) {
    if (state == NovaOrbState.IDLE) return
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        val view = androidx.compose.ui.platform.LocalView.current
        androidx.compose.runtime.SideEffect {
            val window = (view.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
            window?.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            )
            window?.setDimAmount(0f)
        }
        Box(modifier = Modifier.fillMaxSize()) {
            ListeningEdgeGlow(state = state, amplitude = amplitude)
        }
    }
}
