package com.Lia.assistant

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.Lia.assistant.data.rememberNovaAppState
import com.Lia.assistant.forge.ForgeController
import com.Lia.assistant.license.AccessKeyManager
import com.Lia.assistant.ui.fx.ListeningEdgeGlowOverlayHost
import com.Lia.assistant.ui.navigation.NovaApp
import com.Lia.assistant.ui.screens.splash.LiaSplash3D
import com.Lia.assistant.ui.screens.splash.SplashSession
import com.Lia.assistant.ui.theme.NovaTheme
import com.Lia.assistant.voice.VoiceForegroundService
import com.Lia.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleForgeIntent(intent)

        setContent {
            val appState = rememberNovaAppState()
            val orbState by VoiceSessionManager.state.collectAsState()
            val orbAmplitude by VoiceSessionManager.amplitude.collectAsState()
            var showSplashOverlay by remember { mutableStateOf(!SplashSession.played) }

            val lifecycleOwner = LocalLifecycleOwner.current
            val scope = rememberCoroutineScope()
            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) {
                        scope.launch {
                            AccessKeyManager.liveCheck(this@MainActivity)
                            if (VoiceSessionManager.isActive.value && !AccessKeyManager.isActive(this@MainActivity)) {
                                startService(VoiceForegroundService.stopIntent(this@MainActivity))
                                VoiceSessionManager.stop()
                            }
                        }
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
            }

            NovaTheme(
                mode = appState.themeMode,
                reducedMotion = appState.reducedMotion
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    NovaApp(appState = appState)

                    if (showSplashOverlay) {
                        LiaSplash3D(
                            assistantName = appState.assistantName,
                            onFinished = {
                                SplashSession.played = true
                                showSplashOverlay = false
                            }
                        )
                    }

                    ListeningEdgeGlowOverlayHost(
                        state = orbState,
                        amplitude = orbAmplitude
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleForgeIntent(intent)
    }

    private fun handleForgeIntent(intent: Intent?) {
        if (intent?.getBooleanExtra(ForgeController.EXTRA_OPEN_FORGE, false) == true) {
            intent.removeExtra(ForgeController.EXTRA_OPEN_FORGE)
            ForgeController.requestOpen()
        }
    }
}
