package com.Lia.assistant.action

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

object InstalledAppLabelCache {
    private const val TTL_MS = 15 * 60 * 1000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()

    @Volatile
    private var cachedMap: Map<String, String> = emptyMap()

    @Volatile
    private var lastLoadedAtMs: Long = 0L

    fun prewarm(context: Context) {
        val appCtx = context.applicationContext
        scope.launch {
            get(appCtx)
        }
    }

    suspend fun get(context: Context): Map<String, String> {
        val now = System.currentTimeMillis()
        if (cachedMap.isNotEmpty() && now - lastLoadedAtMs < TTL_MS) {
            return cachedMap
        }
        return mutex.withLock {
            val recheckNow = System.currentTimeMillis()
            if (cachedMap.isNotEmpty() && recheckNow - lastLoadedAtMs < TTL_MS) {
                return@withLock cachedMap
            }
            val built = withContext(Dispatchers.IO) {
                buildMap(context.applicationContext)
            }
            cachedMap = built
            lastLoadedAtMs = System.currentTimeMillis()
            built
        }
    }

    fun invalidate() {
        lastLoadedAtMs = 0L
        cachedMap = emptyMap()
    }

    private fun buildMap(context: Context): Map<String, String> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        val map = LinkedHashMap<String, String>(activities.size)
        for (info in activities) {
            val label = info.loadLabel(pm)?.toString()?.trim()?.lowercase().orEmpty()
            val pkg = info.activityInfo?.packageName?.trim().orEmpty()
            if (label.isNotEmpty() && pkg.isNotEmpty() && !map.containsKey(label)) {
                map[label] = pkg
            }
        }
        return map
    }
}
