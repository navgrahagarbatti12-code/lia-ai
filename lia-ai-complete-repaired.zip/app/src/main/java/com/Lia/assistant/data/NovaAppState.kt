package com.Lia.assistant.data

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.Lia.assistant.ui.fx.NovaOrbStyle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class NovaAppState(context: Context) {
    private val appContext = context.applicationContext
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    var themeMode by mutableStateOf(ThemeMode.DARK)
        private set

    var reducedMotion by mutableStateOf(false)
        private set

    var orbStyle by mutableStateOf(NovaOrbStyle.NOVA)
        private set

    var personality by mutableStateOf(Personality.NORMAL)
        private set

    var assistantName by mutableStateOf(AssistantBrand.NAME)
        private set

    var userName by mutableStateOf("")
        private set

    var language by mutableStateOf(LanguagePreference.AUTO)
        private set

    var voiceName by mutableStateOf(PersonalityRepository.DEFAULT_VOICE_NAME)
        private set

    var responseStyle by mutableStateOf("Balanced")
        private set

    var speechSpeed by mutableFloatStateOf(1.0f)
        private set

    var voiceVolume by mutableFloatStateOf(1.0f)
        private set

    var voiceInputEnabled by mutableStateOf(true)
        private set

    var wakeWordEnabled by mutableStateOf(false)
        private set

    var hasOnboarded by mutableStateOf(false)
        private set

    var conversations by mutableStateOf<List<ConversationRecord>>(emptyList())
        private set

    var isLoaded by mutableStateOf(false)
        private set

    suspend fun loadInitial() {
        val loaded = withContext(Dispatchers.IO) {
            LoadedSnapshot(
                themeMode = ThemeMode.fromStored(
                    NovaPreferences.getString(appContext, NovaPreferences.Keys.THEME_MODE, ThemeMode.DARK.name)
                ),
                reducedMotion = NovaPreferences.getBoolean(appContext, NovaPreferences.Keys.REDUCED_MOTION, false),
                orbStyle = NovaOrbStyle.fromStored(
                    NovaPreferences.getString(appContext, NovaPreferences.Keys.ORB_STYLE, NovaOrbStyle.NOVA.name)
                ),
                personality = PersonalityRepository.getPersonality(appContext),
                assistantName = PersonalityRepository.getAssistantName(appContext),
                userName = NovaPreferences.getString(appContext, NovaPreferences.Keys.USER_NAME, ""),
                language = PersonalityRepository.getLanguage(appContext),
                voiceName = PersonalityRepository.getVoiceName(appContext),
                responseStyle = NovaPreferences.getString(appContext, NovaPreferences.Keys.RESPONSE_STYLE, "Balanced"),
                speechSpeed = NovaPreferences.getFloat(appContext, NovaPreferences.Keys.SPEECH_SPEED, 1.0f),
                voiceVolume = NovaPreferences.getFloat(appContext, NovaPreferences.Keys.VOICE_VOLUME, 1.0f),
                voiceInputEnabled = NovaPreferences.getBoolean(appContext, NovaPreferences.Keys.VOICE_INPUT_ENABLED, true),
                wakeWordEnabled = NovaPreferences.getBoolean(appContext, NovaPreferences.Keys.WAKE_WORD_ENABLED, false),
                hasOnboarded = NovaPreferences.getBoolean(appContext, NovaPreferences.Keys.HAS_ONBOARDED, false),
                conversations = ConversationStore.load(appContext)
            )
        }
        themeMode = loaded.themeMode
        reducedMotion = loaded.reducedMotion
        orbStyle = loaded.orbStyle
        personality = loaded.personality
        assistantName = loaded.assistantName
        userName = loaded.userName
        language = loaded.language
        voiceName = loaded.voiceName
        responseStyle = loaded.responseStyle
        speechSpeed = loaded.speechSpeed
        voiceVolume = loaded.voiceVolume
        voiceInputEnabled = loaded.voiceInputEnabled
        wakeWordEnabled = loaded.wakeWordEnabled
        hasOnboarded = loaded.hasOnboarded
        conversations = loaded.conversations
        isLoaded = true
    }

    fun applyThemeMode(value: ThemeMode) {
        themeMode = value
        ioScope.launch { NovaPreferences.putString(appContext, NovaPreferences.Keys.THEME_MODE, value.name) }
    }

    fun applyReducedMotion(value: Boolean) {
        reducedMotion = value
        ioScope.launch { NovaPreferences.putBoolean(appContext, NovaPreferences.Keys.REDUCED_MOTION, value) }
    }

    fun applyOrbStyle(value: NovaOrbStyle) {
        orbStyle = value
        ioScope.launch { NovaPreferences.putString(appContext, NovaPreferences.Keys.ORB_STYLE, value.name) }
    }

    fun applyPersonality(value: Personality) {
        personality = value
        ioScope.launch { PersonalityRepository.setPersonality(appContext, value) }
    }

    fun applyAssistantName(value: String) {
        val clean = value.trim().ifBlank { AssistantBrand.NAME }
        assistantName = clean
        ioScope.launch { PersonalityRepository.setAssistantName(appContext, clean) }
    }

    fun applyUserName(value: String) {
        val clean = value.trim()
        userName = clean
        ioScope.launch { NovaPreferences.putString(appContext, NovaPreferences.Keys.USER_NAME, clean) }
    }

    fun applyLanguage(value: LanguagePreference) {
        language = value
        ioScope.launch { PersonalityRepository.setLanguage(appContext, value) }
    }

    fun applyVoiceName(value: String) {
        val clean = value.trim().ifBlank { PersonalityRepository.DEFAULT_VOICE_NAME }
        voiceName = clean
        ioScope.launch { PersonalityRepository.setVoiceName(appContext, clean) }
    }

    fun applyResponseStyle(value: String) {
        responseStyle = value
        ioScope.launch { NovaPreferences.putString(appContext, NovaPreferences.Keys.RESPONSE_STYLE, value) }
    }

    fun applySpeechSpeed(value: Float) {
        val clamped = value.coerceIn(0.6f, 1.8f)
        speechSpeed = clamped
        ioScope.launch { NovaPreferences.putFloat(appContext, NovaPreferences.Keys.SPEECH_SPEED, clamped) }
    }

    fun applyVoiceVolume(value: Float) {
        val clamped = value.coerceIn(0f, 1f)
        voiceVolume = clamped
        ioScope.launch { NovaPreferences.putFloat(appContext, NovaPreferences.Keys.VOICE_VOLUME, clamped) }
    }

    fun applyVoiceInputEnabled(value: Boolean) {
        voiceInputEnabled = value
        ioScope.launch { NovaPreferences.putBoolean(appContext, NovaPreferences.Keys.VOICE_INPUT_ENABLED, value) }
    }

    fun applyWakeWordEnabled(value: Boolean) {
        wakeWordEnabled = value
        ioScope.launch { NovaPreferences.putBoolean(appContext, NovaPreferences.Keys.WAKE_WORD_ENABLED, value) }
    }

    fun applyHasOnboarded(value: Boolean) {
        hasOnboarded = value
        ioScope.launch { NovaPreferences.putBoolean(appContext, NovaPreferences.Keys.HAS_ONBOARDED, value) }
    }

    fun applyConversations(value: List<ConversationRecord>) {
        conversations = value
        ioScope.launch { ConversationStore.save(appContext, value) }
    }

    fun upsertConversation(record: ConversationRecord) {
        val updated = listOf(record) + conversations.filterNot { it.id == record.id }
        applyConversations(updated)
    }

    fun deleteConversation(id: String) {
        applyConversations(conversations.filterNot { it.id == id })
    }

    fun clearConversations() {
        applyConversations(emptyList())
    }

    private data class LoadedSnapshot(
        val themeMode: ThemeMode,
        val reducedMotion: Boolean,
        val orbStyle: NovaOrbStyle,
        val personality: Personality,
        val assistantName: String,
        val userName: String,
        val language: LanguagePreference,
        val voiceName: String,
        val responseStyle: String,
        val speechSpeed: Float,
        val voiceVolume: Float,
        val voiceInputEnabled: Boolean,
        val wakeWordEnabled: Boolean,
        val hasOnboarded: Boolean,
        val conversations: List<ConversationRecord>
    )
}

@Composable
fun rememberNovaAppState(): NovaAppState {
    val context = LocalContext.current
    val state = remember { NovaAppState(context) }
    LaunchedEffect(state) {
        if (!state.isLoaded) {
            state.loadInitial()
        }
    }
    return state
}
