package com.Lia.assistant.data

enum class LanguagePreference(
    val displayName: String,
    val description: String
) {
    AUTO("Auto", "Follows whatever you speak"),
    HINDI("Hindi", "Replies in natural Hindi"),
    HINGLISH("Hinglish", "Natural Hindi and English blend"),
    ENGLISH("English", "Replies in clear English");

    companion object {
        fun fromStored(value: String?): LanguagePreference =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: AUTO
    }
}

enum class ThemeMode(val displayName: String) {
    DARK("Dark"),
    LIGHT("Light"),
    SYSTEM("System");

    companion object {
        fun fromStored(value: String?): ThemeMode =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: DARK
    }
}
