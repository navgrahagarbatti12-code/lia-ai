package com.Lia.assistant.voice

import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality

object PersonalityPromptBuilder {
    fun build(
        personality: Personality,
        language: LanguagePreference,
        detectedLanguage: DetectedLanguage = DetectedLanguage.UNKNOWN,
        recap: String? = null,
        assistantName: String = AssistantBrand.NAME
    ): String {
        val name = assistantName.trim().ifBlank { AssistantBrand.NAME }
        val sections = mutableListOf<String>()

        // (a) Base identity
        sections += "You are $name, a persistent personal voice assistant living on the user's phone. " +
            "Keep replies short and conversational, like spoken conversation."

        // (b) Flavor capabilities
        val capabilityInstruction = LiaCapabilityPrompts.toolInstruction(name).trim()
        if (capabilityInstruction.isNotEmpty()) {
            sections += capabilityInstruction
        }

        // (c) Personality instruction
        sections += personality.systemInstruction

        // (d) Language policy
        sections += languagePolicy(language, detectedLanguage)

        // (e) Safety and conversational freshness
        sections += "Safety and boundaries: Never claim to be human or have a physical body. " +
            "Never generate sexually explicit content. If the user asks to stop a topic or change tone, " +
            "comply immediately. Vary your phrasing naturally across turns."

        // (f) Optional reconnect recap
        val cleanRecap = recap?.trim()
        if (!cleanRecap.isNullOrEmpty()) {
            sections += "This is a continuing conversation — do not greet again. Recap:\n$cleanRecap"
        }

        return sections.joinToString(separator = "\n\n")
    }

    internal fun languagePolicy(
        language: LanguagePreference,
        detectedLanguage: DetectedLanguage
    ): String {
        return when (language) {
            LanguagePreference.AUTO -> {
                val recentHint = when (detectedLanguage) {
                    DetectedLanguage.HINDI -> " The user's latest turn is Hindi; reply in natural conversational Hindi."
                    DetectedLanguage.HINGLISH -> " The user's latest turn is Hinglish; reply in natural conversational Hinglish."
                    DetectedLanguage.ENGLISH -> " The user's latest turn is English; reply in natural conversational English."
                    DetectedLanguage.UNKNOWN -> ""
                }
                "Language policy: Match the user's language turn by turn (Hindi, Hinglish, or English) and never translate or repeat back what they just said.$recentHint"
            }
            LanguagePreference.HINDI ->
                "Language policy: Always reply in natural spoken Hindi (Devanagari script when writing text), even if the user mixes in English words."
            LanguagePreference.HINGLISH ->
                "Language policy: Always reply in natural conversational Hinglish (everyday Hindi written in Roman script mixed naturally with English)."
            LanguagePreference.ENGLISH ->
                "Language policy: Always reply in clear, natural conversational English."
        }
    }
}
