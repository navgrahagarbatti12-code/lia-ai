package com.Lia.assistant.forge

import org.json.JSONObject

object SseParser {
    fun isDoneLine(line: String): Boolean {
        val trimmed = line.trim()
        return trimmed == "data: [DONE]" || trimmed == "[DONE]"
    }

    fun extractDataJson(line: String): String? {
        val trimmed = line.trim()
        if (!trimmed.startsWith("data:")) return null
        val payload = trimmed.removePrefix("data:").trim()
        if (payload.isEmpty() || payload == "[DONE]") return null
        return payload
    }

    fun extractText(payloadJson: String): String {
        val root = runCatching { JSONObject(payloadJson) }.getOrNull() ?: return ""
        val parts = root.optJSONArray("candidates")
            ?.optJSONObject(0)
            ?.optJSONObject("content")
            ?.optJSONArray("parts")
            ?: return ""
        return buildString {
            for (i in 0 until parts.length()) {
                val t = parts.optJSONObject(i)?.optString("text", "").orEmpty()
                if (t.isNotEmpty()) append(t)
            }
        }
    }

    fun extractError(payloadJson: String): String? {
        val root = runCatching { JSONObject(payloadJson) }.getOrNull() ?: return null
        val err = root.optJSONObject("error") ?: return null
        val msg = err.optString("message", "").trim()
        return msg.ifEmpty { "Unknown streaming error" }
    }

    fun extractFinishReason(payloadJson: String): String? {
        val root = runCatching { JSONObject(payloadJson) }.getOrNull() ?: return null
        val reason = root.optJSONArray("candidates")
            ?.optJSONObject(0)
            ?.optString("finishReason", "")
            .orEmpty()
            .trim()
        return reason.takeIf { it.isNotEmpty() }
    }
}
