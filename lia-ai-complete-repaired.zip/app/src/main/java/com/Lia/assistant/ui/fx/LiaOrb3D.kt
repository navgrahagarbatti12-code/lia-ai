package com.Lia.assistant.ui.fx

import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion

private const val ORB_AGSL_SHADER = """
uniform float time;
uniform float2 resolution;
uniform float3 coreColor;
uniform float3 rimColor;
uniform float3 haloColor;
uniform float amplitude;
uniform float2 tilt;

float hash21(float2 p) {
    p = fract(p * float2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float noise2(float2 p) {
    float2 i = floor(p);
    float2 f = fract(p);
    float2 u = f * f * (3.0 - 2.0 * f);
    float a = hash21(i);
    float b = hash21(i + float2(1.0, 0.0));
    float c = hash21(i + float2(0.0, 1.0));
    float d = hash21(i + float2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float fbm(float2 p) {
    float v = 0.0;
    float a = 0.5;
    float2 shift = float2(100.0);
    for (int i = 0; i < 4; i++) {
        v += a * noise2(p);
        p = p * 2.03 + shift;
        a *= 0.5;
    }
    return v;
}

half4 main(float2 fragCoord) {
    float minDim = max(min(resolution.x, resolution.y), 1.0);
    float2 uv = (fragCoord - 0.5 * resolution) / (0.5 * minDim);

    float angle = time * 0.35;
    float cs = cos(angle);
    float sn = sin(angle);
    float2 rotUv = float2(uv.x * cs - uv.y * sn, uv.x * sn + uv.y * cs);

    float baseRadius = 0.62 + amplitude * 0.08;
    float wobble = (fbm(rotUv * 3.0 + float2(time * 0.45, -time * 0.32)) - 0.5) * (0.04 + amplitude * 0.07);
    float sphereR = baseRadius + wobble;

    float d = length(uv);
    float halo = exp(-max(d - sphereR, 0.0) * 4.4) * (0.48 + amplitude * 0.35);

    if (d > sphereR) {
        float3 colHalo = mix(haloColor, rimColor, 0.35) * halo;
        return half4(colHalo, clamp(halo, 0.0, 1.0));
    }

    float2 sp = uv / sphereR;
    float z = sqrt(max(0.0, 1.0 - dot(sp, sp)));
    float3 n = normalize(float3(sp.x, sp.y, z));

    float3 lightDir = normalize(float3(-0.35 + tilt.x * 0.65, -0.42 + tilt.y * 0.65, 0.82));
    float diff = max(dot(n, lightDir), 0.0);
    float3 halfVec = normalize(lightDir + float3(0.0, 0.0, 1.0));
    float spec = pow(max(dot(n, halfVec), 0.0001), 34.0);
    float fresnel = pow(max(1.0 - max(n.z, 0.0), 0.0001), 2.8);

    float energy = fbm(rotUv * 3.8 + float2(time * 0.55, time * 0.25));
    float3 interior = mix(haloColor * 0.65, coreColor * (1.0 + amplitude * 0.45), smoothstep(0.25, 0.85, energy));
    float3 lit = interior * (0.42 + 0.72 * diff)
               + rimColor * (fresnel * 1.15)
               + float3(1.0, 0.98, 0.94) * (spec * 0.72);

    float edgeAlpha = smoothstep(sphereR, sphereR - 0.025, d);
    return half4(lit, clamp(max(edgeAlpha, halo), 0.0, 1.0));
}
"""

@Composable
fun LiaOrb3D(
    state: NovaOrbState,
    size: Dp,
    amplitude: Float = 0f,
    style: NovaOrbStyle = NovaOrbStyle.NOVA,
    assistantName: String = AssistantBrand.NAME,
    modifier: Modifier = Modifier
) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        style == NovaOrbStyle.ARCHER ||
        style == NovaOrbStyle.MINIMAL
    ) {
        NovaOrb(
            state = state,
            size = size,
            amplitude = amplitude,
            style = style,
            assistantName = assistantName,
            modifier = modifier
        )
        return
    }

    val reducedMotion = LocalNovaReducedMotion.current
    val palette = orbPaletteFor(state)
    val tilt by rememberDeviceTilt()
    val shader = remember { runCatching { RuntimeShader(ORB_AGSL_SHADER) }.getOrNull() }
    if (shader == null) {
        NovaOrb(
            state = state,
            size = size,
            amplitude = amplitude,
            style = style,
            assistantName = assistantName,
            modifier = modifier
        )
        return
    }
    val shaderBrush = remember(shader) { ShaderBrush(shader) }

    val speedMultiplier = when (state) {
        NovaOrbState.THINKING -> 2.1f
        NovaOrbState.CONNECTING -> 1.5f
        NovaOrbState.SPEAKING -> 1.35f
        NovaOrbState.LISTENING -> 1.05f
        NovaOrbState.ERROR -> 0.4f
        NovaOrbState.IDLE -> 0.7f
    }

    var elapsedTime by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(reducedMotion, speedMultiplier) {
        if (reducedMotion) {
            elapsedTime = 0f
            return@LaunchedEffect
        }
        var lastNanos = 0L
        while (true) {
            withFrameNanos { frameNanos ->
                if (lastNanos != 0L) {
                    val dt = (frameNanos - lastNanos) / 1_000_000_000f
                    elapsedTime += dt.coerceAtMost(0.05f) * speedMultiplier
                }
                lastNanos = frameNanos
            }
        }
    }

    val safeAmp = amplitude.coerceIn(0f, 1f)

    Canvas(
        modifier = modifier
            .size(size)
            .semantics {
                contentDescription = "$assistantName status: ${state.label}"
            }
    ) {
        if (this.size.width <= 1f || this.size.height <= 1f) return@Canvas
        shader.setFloatUniform("time", elapsedTime)
        shader.setFloatUniform("resolution", this.size.width, this.size.height)
        shader.setFloatUniform("coreColor", palette.core.red, palette.core.green, palette.core.blue)
        shader.setFloatUniform("rimColor", palette.rim.red, palette.rim.green, palette.rim.blue)
        shader.setFloatUniform("haloColor", palette.halo.red, palette.halo.green, palette.halo.blue)
        shader.setFloatUniform("amplitude", safeAmp)
        shader.setFloatUniform(
            "tilt",
            if (reducedMotion) 0f else tilt.x,
            if (reducedMotion) 0f else tilt.y
        )
        drawRect(brush = shaderBrush)
    }
}
