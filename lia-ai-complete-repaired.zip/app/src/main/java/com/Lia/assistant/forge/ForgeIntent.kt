package com.Lia.assistant.forge

object ForgeIntent {
    private val SUBJECT_PATTERNS = listOf(
        "website", "web site", "webpage", "web page", "landing page",
        "web app", "portfolio site", "homepage", "home page", "site"
    )

    private val BUILD_VERBS = setOf(
        "build", "create", "make", "design", "generate", "craft", "forge", "develop",
        "bana", "banao", "banado", "banade", "bna", "bnado", "bnao", "taiyar"
    )

    private val QUESTION_STARTERS = listOf(
        "how ", "what ", "why ", "when ", "where ", "who ", "which ",
        "is ", "are ", "can you explain", "tell me ", "explain ",
        "kya ", "kaise ", "kyun ", "kyon ", "kab ", "kahan ", "kaun "
    )

    private val WORD_SPLIT = Regex("[^a-zA-Z0-9]+")

    fun extract(rawText: String): String? {
        val text = rawText.trim()
        if (text.length < 6) return null
        val lower = text.lowercase()

        if (text.endsWith("?")) return null
        if (QUESTION_STARTERS.any { lower.startsWith(it) }) return null

        val hasSubject = SUBJECT_PATTERNS.any { subject ->
            Regex("\\b${Regex.escape(subject)}\\b").containsMatchIn(lower)
        }
        if (!hasSubject) return null

        val words = lower.split(WORD_SPLIT).filter { it.isNotEmpty() }
        val hasBuildVerb = words.any { it in BUILD_VERBS } ||
            lower.contains("bana do") ||
            lower.contains("bana de")
        if (!hasBuildVerb) return null

        return text
    }
}
