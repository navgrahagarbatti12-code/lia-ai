package com.Lia.assistant.ui.navigation

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.fx.NovaOrbStyle
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaShapes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.depthSurface

@Composable
fun LiaBottomNavigation(
    currentRoute: String?,
    orbState: NovaOrbState,
    orbAmplitude: Float,
    orbStyle: NovaOrbStyle,
    assistantName: String,
    onNavigateHome: () -> Unit,
    onNavigateChat: () -> Unit,
    onNavigateVoice: () -> Unit,
    onNavigateHistory: () -> Unit,
    onNavigateSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalNovaColors.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
        contentAlignment = Alignment.BottomCenter
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .depthSurface(shape = NovaShapes.pill, elevation = 14.dp)
                .padding(horizontal = NovaSpacing.md),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            NavTabItem(
                icon = Icons.Rounded.Home,
                label = "Home",
                selected = currentRoute == NovaRoutes.HOME,
                onClick = onNavigateHome,
                testTag = "nav_home"
            )
            NavTabItem(
                icon = Icons.Rounded.ChatBubble,
                label = "Chat",
                selected = currentRoute?.startsWith(NovaRoutes.CHAT) == true,
                onClick = onNavigateChat,
                testTag = "nav_chat"
            )
            Box(modifier = Modifier.size(64.dp))
            NavTabItem(
                icon = Icons.Rounded.History,
                label = "History",
                selected = currentRoute == NovaRoutes.HISTORY,
                onClick = onNavigateHistory,
                testTag = "nav_history"
            )
            NavTabItem(
                icon = Icons.Rounded.Settings,
                label = "Settings",
                selected = currentRoute == NovaRoutes.SETTINGS,
                onClick = onNavigateSettings,
                testTag = "nav_settings"
            )
        }

        // Raised center Talk orb docked above the floating glass bar
        Box(
            modifier = Modifier
                .offset(y = (-14).dp)
                .size(62.dp)
                .depthSurface(
                    shape = CircleShape,
                    elevation = 16.dp,
                    borderColor = colors.accent.copy(alpha = 0.65f)
                )
                .clip(CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = androidx.compose.material3.ripple(bounded = true),
                    onClick = onNavigateVoice
                )
                .semantics { contentDescription = "Talk with $assistantName" }
                .testTag("nav_voice_orb"),
            contentAlignment = Alignment.Center
        ) {
            LiaOrb3D(
                state = if (orbState == NovaOrbState.IDLE) NovaOrbState.SPEAKING else orbState,
                size = 52.dp,
                amplitude = if (orbState == NovaOrbState.IDLE) 0.16f else orbAmplitude,
                style = orbStyle,
                assistantName = assistantName
            )
        }
    }
}

@Composable
private fun NavTabItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val colors = LocalNovaColors.current
    val tint = if (selected) colors.accent else colors.textSecondary
    Column(
        modifier = Modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clip(NovaShapes.small)
            .clickable(onClick = onClick)
            .padding(horizontal = NovaSpacing.xs, vertical = 4.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = tint
        )
    }
}
