package com.Lia.assistant.ui.screens.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.fx.NovaOrbStyle
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

object SplashSession {
    @Volatile
    var played: Boolean = false
}

@Composable
fun LiaSplash3D(
    assistantName: String = AssistantBrand.NAME,
    onFinished: () -> Unit
) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val progress = remember { Animatable(if (reducedMotion) 0.8f else 0f) }
    val dissolveAlpha = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        if (reducedMotion) {
            delay(450)
        } else {
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 1550, easing = FastOutSlowInEasing)
            )
            delay(250)
        }
        dissolveAlpha.animateTo(0f, animationSpec = tween(320))
        SplashSession.played = true
        onFinished()
    }

    val particles = remember {
        List(72) { idx ->
            val angle = (idx * 137.508f) * (PI / 180.0)
            val dist = 0.25f + (idx % 11) * 0.08f
            Triple(cos(angle).toFloat(), sin(angle).toFloat(), dist)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = dissolveAlpha.value }
            .background(
                Brush.verticalGradient(
                    listOf(colors.backgroundGradientTop, colors.background)
                )
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                SplashSession.played = true
                onFinished()
            }
            .semantics { contentDescription = "$assistantName splash intro, tap to skip" },
        contentAlignment = Alignment.Center
    ) {
        if (!reducedMotion) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val maxR = size.maxDimension * 0.55f
                val p = progress.value

                // Streaking stars converging into the pearl center
                for ((idx, pt) in particles.withIndex()) {
                    val radial = (1f - p) * pt.third * maxR
                    val tailRadial = (1f - (p - 0.12f).coerceAtLeast(0f)) * pt.third * maxR
                    val x1 = cx + pt.first * radial
                    val y1 = cy + pt.second * radial
                    val x0 = cx + pt.first * tailRadial
                    val y0 = cy + pt.second * tailRadial
                    val c = if (idx % 3 == 0) colors.accent else if (idx % 3 == 1) colors.lotus else colors.lagoon
                    drawLine(
                        color = c.copy(alpha = (1f - p * 0.6f) * 0.75f),
                        start = Offset(x0, y0),
                        end = Offset(x1, y1),
                        strokeWidth = 2.dp.toPx()
                    )
                }
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(NovaSpacing.xl)
        ) {
            Box(
                modifier = Modifier.graphicsLayer {
                    val s = 0.45f + progress.value * 0.55f
                    scaleX = s
                    scaleY = s
                    alpha = progress.value.coerceIn(0.2f, 1f)
                }
            ) {
                LiaOrb3D(
                    state = NovaOrbState.SPEAKING,
                    size = 164.dp,
                    amplitude = (1f - progress.value) * 0.5f + 0.15f,
                    style = NovaOrbStyle.NOVA,
                    assistantName = assistantName
                )
            }
            Spacer(Modifier.height(NovaSpacing.xl))
            Text(
                text = assistantName,
                style = MaterialTheme.typography.displayLarge,
                color = colors.textPrimary,
                modifier = Modifier.graphicsLayer {
                    alpha = ((progress.value - 0.35f) / 0.45f).coerceIn(0f, 1f)
                }
            )
            Spacer(Modifier.height(NovaSpacing.xs))
            Text(
                text = AssistantBrand.TAGLINE,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                modifier = Modifier.graphicsLayer {
                    alpha = ((progress.value - 0.5f) / 0.45f).coerceIn(0f, 1f)
                }
            )
        }
    }
}
