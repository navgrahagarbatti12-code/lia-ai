package com.Lia.assistant.ui.screens.voice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaVoiceVisualizer
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaShapes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.depthSurface
import com.Lia.assistant.voice.VoiceForegroundService
import com.Lia.assistant.voice.VoiceSessionManager

@Composable
fun VoiceScreen(
    appState: NovaAppState,
    onClose: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current

    val orbState by VoiceSessionManager.state.collectAsState()
    val amplitude by VoiceSessionManager.amplitude.collectAsState()
    val muted by VoiceSessionManager.muted.collectAsState()
    val statusText by VoiceSessionManager.statusText.collectAsState()
    val isActive by VoiceSessionManager.isActive.collectAsState()
    val lastError by VoiceSessionManager.lastError.collectAsState()

    var hasMicPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val hasApiKey = remember(context) { ApiKeyStore.hasKey(context) }

    val requiredPermissions = remember {
        buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
            add(Manifest.permission.READ_CONTACTS)
            add(Manifest.permission.CALL_PHONE)
        }.toTypedArray()
    }

    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val micGranted = result[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        hasMicPerm = micGranted
        if (micGranted && ApiKeyStore.hasKey(context) && !VoiceSessionManager.isActive.value) {
            ContextCompat.startForegroundService(context, VoiceForegroundService.startIntent(context))
        }
    }

    LaunchedEffect(Unit) {
        if (!hasMicPerm) {
            permLauncher.launch(requiredPermissions)
        } else if (hasApiKey && !isActive) {
            ContextCompat.startForegroundService(context, VoiceForegroundService.startIntent(context))
        }
    }

    val effectiveState = when {
        !hasMicPerm || !hasApiKey -> NovaOrbState.ERROR
        else -> orbState
    }

    val effectiveCaption = when {
        !hasMicPerm -> "Microphone permission is needed to hear you."
        !hasApiKey -> "Add your Gemini API key in Settings to start talking."
        !lastError.isNullOrBlank() && orbState == NovaOrbState.ERROR -> lastError!!
        statusText.isNotBlank() -> statusText
        else -> "${appState.assistantName} is ready"
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(NovaSpacing.lg)
    ) {
        val heroOrbSize = (maxWidth * 0.70f).coerceIn(220.dp, 300.dp)

        // Centered Hero Orb + Speaking Ring + Italic Serif Status
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(heroOrbSize + 44.dp),
                contentAlignment = Alignment.Center
            ) {
                if (effectiveState == NovaOrbState.SPEAKING) {
                    NovaVoiceVisualizer(
                        amplitude = amplitude,
                        active = true,
                        barCount = 48,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                LiaOrb3D(
                    state = effectiveState,
                    size = heroOrbSize,
                    amplitude = amplitude,
                    style = appState.orbStyle,
                    assistantName = appState.assistantName
                )
            }

            Spacer(Modifier.height(NovaSpacing.xl))

            Text(
                text = effectiveCaption,
                style = MaterialTheme.typography.headlineMedium.copy(fontStyle = FontStyle.Italic),
                color = if (effectiveState == NovaOrbState.ERROR) colors.error else colors.textPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = NovaSpacing.lg)
            )

            if (!hasMicPerm) {
                Spacer(Modifier.height(NovaSpacing.lg))
                NovaButton(
                    text = "Allow Microphone",
                    onClick = {
                        val openSettings = !ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ).let { it == PackageManager.PERMISSION_GRANTED }
                        permLauncher.launch(requiredPermissions)
                        if (openSettings) {
                            // If user previously denied forever, offer settings fallback via Permissions screen
                        }
                    },
                    testTag = "voice_allow_mic"
                )
                Spacer(Modifier.height(NovaSpacing.sm))
                NovaButton(
                    text = "Open App Settings",
                    style = NovaButtonStyle.TEXT,
                    onClick = {
                        context.startActivity(
                            Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:${context.packageName}")
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                )
            } else if (!hasApiKey) {
                Spacer(Modifier.height(NovaSpacing.lg))
                NovaButton(
                    text = "Open Settings",
                    onClick = onOpenSettings,
                    testTag = "voice_open_settings"
                )
            }
        }

        // Bottom Frosted Control Row: Mute | Stop | Close
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = NovaSpacing.md)
                .depthSurface(shape = NovaShapes.pill, elevation = 12.dp)
                .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(NovaSpacing.lg)
        ) {
            IconButton(
                onClick = { VoiceSessionManager.toggleMute() },
                enabled = isActive,
                modifier = Modifier
                    .size(52.dp)
                    .depthSurface(
                        shape = CircleShape,
                        elevation = 4.dp,
                        backgroundColor = if (muted) colors.warning.copy(alpha = 0.28f) else colors.surfaceRaised
                    )
                    .testTag("voice_mute_button")
            ) {
                Icon(
                    imageVector = if (muted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                    contentDescription = if (muted) "Unmute microphone" else "Mute microphone",
                    tint = if (muted) colors.warning else colors.textPrimary
                )
            }

            IconButton(
                onClick = {
                    context.startService(VoiceForegroundService.stopIntent(context))
                    VoiceSessionManager.stop()
                    onClose()
                },
                modifier = Modifier
                    .size(64.dp)
                    .depthSurface(
                        shape = CircleShape,
                        elevation = 8.dp,
                        backgroundColor = colors.error.copy(alpha = 0.26f),
                        borderColor = colors.error
                    )
                    .testTag("voice_stop_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Stop,
                    contentDescription = "Stop voice session",
                    tint = colors.error,
                    modifier = Modifier.size(30.dp)
                )
            }

            IconButton(
                onClick = onClose,
                modifier = Modifier
                    .size(52.dp)
                    .depthSurface(shape = CircleShape, elevation = 4.dp)
                    .testTag("voice_close_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Minimize voice screen",
                    tint = colors.textPrimary
                )
            }
        }
    }
}
