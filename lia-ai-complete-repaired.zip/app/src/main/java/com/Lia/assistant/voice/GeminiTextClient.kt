package com.Lia.assistant.voice

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class ChatTurn(
    val isUser: Boolean,
    val text: String
)

sealed class ChatReplyResult {
    data class Success(val text: String) : ChatReplyResult()
    data class Error(val message: String) : ChatReplyResult()
}

object GeminiTextClient {
    private const val TAG = "GeminiTextClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

    internal val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var cachedModel: String? = null

    fun invalidateModelCache() {
        cachedModel = null
    }

    internal fun pickBestModel(modelsJson: String): String? {
        val root = runCatching { JSONObject(modelsJson) }.getOrNull() ?: return null
        val models = root.optJSONArray("models") ?: return null
        var firstGenerateContent: String? = null

        for (i in 0 until models.length()) {
            val item = models.optJSONObject(i) ?: continue
            val rawName = item.optString("name", "").trim()
            if (rawName.isEmpty()) continue
            val methods = item.optJSONArray("supportedGenerationMethods") ?: continue
            var supportsGenerate = false
            for (j in 0 until methods.length()) {
                if (methods.optString(j) == "generateContent") {
                    supportsGenerate = true
                    break
                }
            }
            if (!supportsGenerate) continue

            val cleanName = rawName.removePrefix("models/")
            if (firstGenerateContent == null) {
                firstGenerateContent = cleanName
            }
            val lower = cleanName.lowercase()
            if (lower.contains("flash") &&
                !lower.contains("live") &&
                !lower.contains("image") &&
                !lower.contains("tts")
            ) {
                return cleanName
            }
        }
        return firstGenerateContent
    }

    internal suspend fun resolveModel(apiKey: String): String? {
        cachedModel?.let { return it }
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) return null

        return withContext(Dispatchers.IO) {
            cachedModel?.let { return@withContext it }
            val req = Request.Builder()
                .url("$BASE_URL/models?key=$cleanKey")
                .get()
                .build()
            try {
                httpClient.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        val reason = extractGeminiErrorReason(body)
                        Log.w(TAG, "ListModels HTTP ${resp.code}: $reason")
                        return@withContext null
                    }
                    val picked = pickBestModel(body)
                    if (picked != null) {
                        cachedModel = picked
                    }
                    picked
                }
            } catch (e: IOException) {
                Log.w(TAG, "ListModels network failure")
                null
            }
        }
    }

    suspend fun reply(
        apiKey: String,
        systemInstruction: String,
        history: List<ChatTurn>
    ): ChatReplyResult {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return ChatReplyResult.Error("Add your Gemini API key in Settings first.")
        }
        if (history.isEmpty()) {
            return ChatReplyResult.Error("Write a message to start chatting.")
        }

        val model = resolveModel(cleanKey)
            ?: return ChatReplyResult.Error("Couldn't find an available Gemini text model. Check your API key and connection.")

        return withContext(Dispatchers.IO) {
            val contents = JSONArray()
            for (turn in history) {
                val cleanText = turn.text.trim()
                if (cleanText.isEmpty()) continue
                contents.put(
                    JSONObject()
                        .put("role", if (turn.isUser) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", cleanText)))
                )
            }
            if (contents.length() == 0) {
                return@withContext ChatReplyResult.Error("Write a message to start chatting.")
            }

            val payload = JSONObject()
                .put(
                    "systemInstruction",
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", systemInstruction))
                    )
                )
                .put("contents", contents)

            val req = Request.Builder()
                .url("$BASE_URL/models/$model:generateContent")
                .addHeader("x-goog-api-key", cleanKey)
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .build()

            try {
                httpClient.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        val reason = extractGeminiErrorReason(body)
                        Log.w(TAG, "generateContent HTTP ${resp.code}: $reason")
                        return@withContext ChatReplyResult.Error("Gemini error (${resp.code}): $reason")
                    }
                    parseReplyText(body)
                }
            } catch (_: IOException) {
                ChatReplyResult.Error("Couldn't reach Gemini. Check your internet connection.")
            }
        }
    }

    internal fun parseReplyText(jsonStr: String): ChatReplyResult {
        val root = runCatching { JSONObject(jsonStr) }.getOrNull()
            ?: return ChatReplyResult.Error("Invalid response from Gemini.")
        val candidate = root.optJSONArray("candidates")?.optJSONObject(0)
            ?: return ChatReplyResult.Error("Gemini returned no reply.")
        val parts = candidate.optJSONObject("content")?.optJSONArray("parts")
            ?: return ChatReplyResult.Error("Gemini blocked or omitted the reply.")
        val text = buildString {
            for (i in 0 until parts.length()) {
                val partText = parts.optJSONObject(i)?.optString("text", "").orEmpty()
                if (partText.isNotEmpty()) append(partText)
            }
        }.trim()
        return if (text.isEmpty()) {
            ChatReplyResult.Error("Gemini returned an empty reply.")
        } else {
            ChatReplyResult.Success(text)
        }
    }

    internal fun extractGeminiErrorReason(body: String): String {
        val err = runCatching { JSONObject(body).optJSONObject("error") }.getOrNull()
        val msg = err?.optString("message", "").orEmpty().trim()
        return msg.ifEmpty { "Request failed" }
    }

    internal fun clearCachedModelForTesting() {
        cachedModel = null
    }
}
