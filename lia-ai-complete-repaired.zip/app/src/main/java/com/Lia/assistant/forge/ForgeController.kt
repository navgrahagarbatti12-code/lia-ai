package com.Lia.assistant.forge

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.Lia.assistant.MainActivity
import com.Lia.assistant.R
import com.Lia.assistant.data.ApiKeyStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

sealed class ForgeStartResult(val spokenMessage: String) {
    data object Started : ForgeStartResult("Opening Website Forge and building your site now.")
    data object MissingKey : ForgeStartResult("Please add your Gemini API key in Settings first.")
    data object Offline : ForgeStartResult("You are offline. Connect to the internet to build a website.")
    data object Busy : ForgeStartResult("Website Forge is already building a site.")
    data object NothingToEdit : ForgeStartResult("There is no generated website to edit yet.")
}

object ForgeController {
    const val EXTRA_OPEN_FORGE = "extra_open_forge"
    private const val CHANNEL_ID = "lia_forge_ready"
    private const val NOTIFICATION_ID = 2002
    private const val EMIT_THROTTLE_MS = 120L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _state = MutableStateFlow(ForgeUiState())
    val state: StateFlow<ForgeUiState> = _state.asStateFlow()

    private val _pendingOpen = MutableStateFlow(false)
    val pendingOpen: StateFlow<Boolean> = _pendingOpen.asStateFlow()

    @Volatile
    var isForgeScreenVisible: Boolean = false

    @Volatile
    private var activeJob: Job? = null

    @Volatile
    private var latestPartialHtml: String = ""

    @Volatile
    private var lastPrompt: String = ""

    @Volatile
    private var lastIsEdit: Boolean = false

    @Volatile
    private var lastBaseHtmlForEdit: String? = null

    fun requestOpen() {
        _pendingOpen.value = true
    }

    fun consumePendingOpen() {
        _pendingOpen.value = false
    }

    fun partialHtml(): String = latestPartialHtml

    fun start(context: Context, prompt: String): ForgeStartResult {
        val clean = prompt.trim()
        if (clean.isEmpty()) return ForgeStartResult.NothingToEdit
        val appCtx = context.applicationContext
        if (!ApiKeyStore.hasKey(appCtx)) return ForgeStartResult.MissingKey
        if (!isOnline(appCtx)) return ForgeStartResult.Offline
        if (_state.value.phase == ForgePhase.BUILDING && activeJob?.isActive == true) {
            return ForgeStartResult.Busy
        }

        lastPrompt = clean
        lastIsEdit = false
        lastBaseHtmlForEdit = null
        launchBuild(appCtx, clean, isEdit = false, existingHtml = null)
        requestOpen()
        return ForgeStartResult.Started
    }

    fun edit(context: Context, change: String): ForgeStartResult {
        val cleanChange = change.trim()
        if (cleanChange.isEmpty()) return ForgeStartResult.NothingToEdit
        val currentFile = _state.value.file
        val currentHtml = when {
            currentFile != null && currentFile.exists() -> runCatching { currentFile.readText() }.getOrNull()
            latestPartialHtml.isNotBlank() -> latestPartialHtml
            else -> null
        } ?: return ForgeStartResult.NothingToEdit

        val appCtx = context.applicationContext
        if (!ApiKeyStore.hasKey(appCtx)) return ForgeStartResult.MissingKey
        if (!isOnline(appCtx)) return ForgeStartResult.Offline
        if (_state.value.phase == ForgePhase.BUILDING && activeJob?.isActive == true) {
            return ForgeStartResult.Busy
        }

        lastPrompt = cleanChange
        lastIsEdit = true
        lastBaseHtmlForEdit = currentHtml
        launchBuild(appCtx, cleanChange, isEdit = true, existingHtml = currentHtml)
        return ForgeStartResult.Started
    }

    fun retry(context: Context): ForgeStartResult {
        if (lastPrompt.isBlank()) return ForgeStartResult.NothingToEdit
        val appCtx = context.applicationContext
        if (!ApiKeyStore.hasKey(appCtx)) return ForgeStartResult.MissingKey
        if (!isOnline(appCtx)) return ForgeStartResult.Offline
        launchBuild(appCtx, lastPrompt, isEdit = lastIsEdit, existingHtml = lastBaseHtmlForEdit)
        return ForgeStartResult.Started
    }

    fun cancel() {
        activeJob?.cancel()
        activeJob = null
        if (_state.value.phase == ForgePhase.BUILDING) {
            _state.value = _state.value.copy(
                phase = ForgePhase.CANCELLED,
                error = "Build cancelled"
            )
        }
    }

    fun reset() {
        activeJob?.cancel()
        activeJob = null
        latestPartialHtml = ""
        _state.value = ForgeUiState()
    }

    fun openSaved(file: File) {
        if (!file.exists()) return
        val content = runCatching { file.readText() }.getOrNull() ?: return
        latestPartialHtml = content
        val sections = ForgeStageDetector.extractSectionNames(content)
        _state.value = ForgeUiState(
            phase = ForgePhase.DONE,
            prompt = file.nameWithoutExtension,
            stage = ForgeStage.POLISH,
            progress = 1f,
            metrics = ForgeMetrics(
                chars = content.length,
                sections = sections.size,
                elapsedSec = 0f,
                tokensPerSec = 0f
            ),
            sections = sections,
            file = file,
            buildId = UUID.randomUUID().toString()
        )
        requestOpen()
    }

    fun websitesDir(context: Context): File =
        File(context.applicationContext.filesDir, "Websites").apply { mkdirs() }

    fun savedWebsites(context: Context): List<File> =
        websitesDir(context)
            .listFiles { f -> f.isFile && f.extension.equals("html", ignoreCase = true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    fun deleteWebsite(file: File): Boolean {
        val deleted = runCatching { file.delete() }.getOrDefault(false)
        if (_state.value.file?.absolutePath == file.absolutePath) {
            reset()
        }
        return deleted
    }

    private fun launchBuild(
        appCtx: Context,
        prompt: String,
        isEdit: Boolean,
        existingHtml: String?
    ) {
        activeJob?.cancel()
        latestPartialHtml = ""
        val buildId = UUID.randomUUID().toString()
        val startedMs = System.currentTimeMillis()
        val logList = mutableListOf(ForgeStage.SPARK.label)
        var logSeq = 1

        _state.value = ForgeUiState(
            phase = ForgePhase.BUILDING,
            prompt = prompt,
            isEdit = isEdit,
            stage = ForgeStage.SPARK,
            progress = ForgeStage.SPARK.baseProgress,
            metrics = ForgeMetrics(),
            sections = emptyList(),
            log = logList.toList(),
            logSeq = logSeq,
            buildId = buildId
        )

        activeJob = scope.launch {
            try {
                val apiKey = ApiKeyStore.getKey(appCtx)
                val systemPrompt = if (isEdit && existingHtml != null) {
                    ForgeSystemPrompt.forEdit(existingHtml, prompt)
                } else {
                    ForgeSystemPrompt.forNewSite(prompt)
                }

                var lastEmitMs = 0L
                var lastStage = ForgeStage.SPARK
                val seenSections = LinkedHashSet<String>()
                var nextKbMilestone = 10

                suspend fun runAttempt(extraHint: String?): WebsiteForgeClient.StreamOutcome {
                    val effectivePrompt = if (extraHint == null) {
                        prompt
                    } else {
                        "$prompt\n\nIMPORTANT: $extraHint"
                    }
                    return WebsiteForgeClient.streamHtml(
                        apiKey = apiKey,
                        systemInstruction = systemPrompt,
                        userPrompt = effectivePrompt
                    ) { raw ->
                        val cleaned = ForgeHtml.stripFences(raw)
                        latestPartialHtml = cleaned
                        val now = System.currentTimeMillis()
                        if (now - lastEmitMs < EMIT_THROTTLE_MS) return@streamHtml
                        lastEmitMs = now

                        val stage = ForgeStageDetector.detect(cleaned)
                        if (stage.index > lastStage.index) {
                            lastStage = stage
                            logList += stage.label
                            logSeq++
                        }

                        val foundSections = ForgeStageDetector.extractSectionNames(cleaned)
                        for (sec in foundSections) {
                            if (seenSections.add(sec)) {
                                logList += "Laying out $sec"
                                logSeq++
                            }
                        }

                        val kb = cleaned.length / 1024
                        if (kb >= nextKbMilestone) {
                            logList += "${nextKbMilestone} KB streamed"
                            logSeq++
                            nextKbMilestone += 10
                        }

                        val elapsedSec = ((now - startedMs).coerceAtLeast(100L)) / 1000f
                        val approxTokens = cleaned.length / 4f
                        val tps = approxTokens / elapsedSec
                        val progress = (stage.baseProgress + (cleaned.length / 28000f).coerceAtMost(0.12f))
                            .coerceIn(0.08f, 0.98f)

                        _state.value = _state.value.copy(
                            stage = lastStage,
                            progress = progress,
                            metrics = ForgeMetrics(
                                chars = cleaned.length,
                                sections = seenSections.size,
                                elapsedSec = elapsedSec,
                                tokensPerSec = tps
                            ),
                            sections = seenSections.toList(),
                            log = logList.takeLast(8),
                            logSeq = logSeq
                        )
                    }
                }

                var outcome = runAttempt(null)
                if (outcome is WebsiteForgeClient.StreamOutcome.Failed && outcome.retryableOverload) {
                    logList += "Retrying in 4s..."
                    logSeq++
                    _state.value = _state.value.copy(log = logList.takeLast(8), logSeq = logSeq)
                    delay(4000L)
                    outcome = runAttempt(null)
                }

                if (outcome is WebsiteForgeClient.StreamOutcome.Failed) {
                    _state.value = _state.value.copy(
                        phase = ForgePhase.FAILED,
                        error = outcome.userMessage
                    )
                    return@launch
                }

                var completed = outcome as WebsiteForgeClient.StreamOutcome.Completed
                var cleanedHtml = ForgeHtml.stripFences(completed.html)
                var hasClosingHtml = cleanedHtml.contains("</html>", ignoreCase = true)

                if (cleanedHtml.length < 1500 || !hasClosingHtml) {
                    val isTruncatedLarge = cleanedHtml.length >= 14000 && ForgeHtml.looksLikeHtml(cleanedHtml)
                    if (!isTruncatedLarge) {
                        logList += "Retrying for full page..."
                        logSeq++
                        _state.value = _state.value.copy(log = logList.takeLast(8), logSeq = logSeq)
                        val retryOutcome = runAttempt("write completely original markup, copy and code; finish the whole page")
                        if (retryOutcome is WebsiteForgeClient.StreamOutcome.Completed) {
                            completed = retryOutcome
                            cleanedHtml = ForgeHtml.stripFences(completed.html)
                            hasClosingHtml = cleanedHtml.contains("</html>", ignoreCase = true)
                        }
                    }
                }

                if (!ForgeHtml.looksLikeHtml(cleanedHtml)) {
                    _state.value = _state.value.copy(
                        phase = ForgePhase.FAILED,
                        error = "Gemini stopped before finishing"
                    )
                    return@launch
                }

                val finalRawHtml = if (hasClosingHtml) {
                    cleanedHtml
                } else if (cleanedHtml.length >= 14000) {
                    ForgeHtml.repairTruncated(cleanedHtml)
                } else {
                    _state.value = _state.value.copy(
                        phase = ForgePhase.FAILED,
                        error = "Gemini stopped before finishing"
                    )
                    return@launch
                }

                val finalHtml = ForgeHtml.withSafetyNet(finalRawHtml)
                latestPartialHtml = finalHtml

                val outFile = File(websitesDir(appCtx), "website_${System.currentTimeMillis()}.html")
                outFile.writeText(finalHtml, Charsets.UTF_8)

                val finalSections = ForgeStageDetector.extractSectionNames(finalHtml)
                val totalElapsed = ((System.currentTimeMillis() - startedMs).coerceAtLeast(100L)) / 1000f
                _state.value = _state.value.copy(
                    phase = ForgePhase.DONE,
                    stage = ForgeStage.POLISH,
                    progress = 1f,
                    metrics = ForgeMetrics(
                        chars = finalHtml.length,
                        sections = finalSections.size,
                        elapsedSec = totalElapsed,
                        tokensPerSec = (finalHtml.length / 4f) / totalElapsed
                    ),
                    sections = finalSections,
                    file = outFile,
                    error = null
                )

                if (!isForgeScreenVisible) {
                    postReadyNotification(appCtx)
                }
            } catch (_: CancellationException) {
                // Already handled by cancel()
            } catch (t: Throwable) {
                _state.value = _state.value.copy(
                    phase = ForgePhase.FAILED,
                    error = t.message ?: "Website generation failed"
                )
            }
        }
    }

    private fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun postReadyNotification(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Website Forge", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_FORGE, true)
        }
        val pi = PendingIntent.getActivity(
            context,
            20,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Your website is ready")
            .setContentText("Tap to reveal and preview your generated site")
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        nm.notify(NOTIFICATION_ID, notification)
    }
}
