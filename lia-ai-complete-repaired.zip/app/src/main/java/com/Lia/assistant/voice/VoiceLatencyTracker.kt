package com.Lia.assistant.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VoiceLatencySnapshot(
    val speechEndMs: Long = 0L,
    val firstAudioMs: Long = 0L,
    val turnCompleteMs: Long = 0L,
    val toolStartMs: Long = 0L,
    val toolEndMs: Long = 0L,
    val firstAudioLatencyMs: Long? = null,
    val turnDurationMs: Long? = null,
    val toolExecutionMs: Long? = null
)

object VoiceLatencyTracker {
    private val lock = Any()
    private var nowMs: () -> Long = { System.nanoTime() / 1_000_000L }

    private var speechEndMs: Long = 0L
    private var firstAudioMs: Long = 0L
    private var turnCompleteMs: Long = 0L
    private var toolStartMs: Long = 0L
    private var toolEndMs: Long = 0L
    private var lastMonotonicMark: Long = 0L

    private val _snapshot = MutableStateFlow(VoiceLatencySnapshot())
    val snapshot: StateFlow<VoiceLatencySnapshot> = _snapshot.asStateFlow()

    private val _reconnectCount = MutableStateFlow(0)
    val reconnectCount: StateFlow<Int> = _reconnectCount.asStateFlow()

    internal fun setClockForTesting(clock: () -> Long) {
        synchronized(lock) {
            nowMs = clock
            resetTurnLocked()
            _reconnectCount.value = 0
        }
    }

    fun startNewTurn() {
        synchronized(lock) {
            resetTurnLocked()
        }
    }

    fun markSpeechEnd(timestampMs: Long = nowMs()) {
        synchronized(lock) {
            if (timestampMs < lastMonotonicMark) return
            if (speechEndMs != 0L && timestampMs < speechEndMs) return
            speechEndMs = timestampMs
            firstAudioMs = 0L
            turnCompleteMs = 0L
            lastMonotonicMark = timestampMs
            emitLocked()
        }
    }

    fun markFirstAudioByte(timestampMs: Long = nowMs()) {
        synchronized(lock) {
            if (speechEndMs == 0L) return
            if (firstAudioMs != 0L) return
            if (timestampMs < speechEndMs || timestampMs < lastMonotonicMark) return
            firstAudioMs = timestampMs
            lastMonotonicMark = timestampMs
            emitLocked()
        }
    }

    fun markTurnComplete(timestampMs: Long = nowMs()) {
        synchronized(lock) {
            if (speechEndMs == 0L) return
            val minAnchor = maxOf(speechEndMs, firstAudioMs, lastMonotonicMark)
            if (timestampMs < minAnchor) return
            turnCompleteMs = timestampMs
            lastMonotonicMark = timestampMs
            emitLocked()
        }
    }

    fun markToolStart(timestampMs: Long = nowMs()) {
        synchronized(lock) {
            if (timestampMs < lastMonotonicMark) return
            toolStartMs = timestampMs
            toolEndMs = 0L
            lastMonotonicMark = timestampMs
            emitLocked()
        }
    }

    fun markToolEnd(timestampMs: Long = nowMs()) {
        synchronized(lock) {
            if (toolStartMs == 0L) return
            if (timestampMs < toolStartMs || timestampMs < lastMonotonicMark) return
            toolEndMs = timestampMs
            lastMonotonicMark = timestampMs
            emitLocked()
        }
    }

    fun incrementReconnectCount() {
        _reconnectCount.value = _reconnectCount.value + 1
    }

    fun resetReconnectCount() {
        _reconnectCount.value = 0
    }

    fun reset() {
        synchronized(lock) {
            resetTurnLocked()
            _reconnectCount.value = 0
        }
    }

    private fun resetTurnLocked() {
        speechEndMs = 0L
        firstAudioMs = 0L
        turnCompleteMs = 0L
        toolStartMs = 0L
        toolEndMs = 0L
        lastMonotonicMark = 0L
        _snapshot.value = VoiceLatencySnapshot()
    }

    private fun emitLocked() {
        _snapshot.value = VoiceLatencySnapshot(
            speechEndMs = speechEndMs,
            firstAudioMs = firstAudioMs,
            turnCompleteMs = turnCompleteMs,
            toolStartMs = toolStartMs,
            toolEndMs = toolEndMs,
            firstAudioLatencyMs = if (speechEndMs > 0L && firstAudioMs >= speechEndMs) {
                firstAudioMs - speechEndMs
            } else {
                null
            },
            turnDurationMs = if (speechEndMs > 0L && turnCompleteMs >= speechEndMs) {
                turnCompleteMs - speechEndMs
            } else {
                null
            },
            toolExecutionMs = if (toolStartMs > 0L && toolEndMs >= toolStartMs) {
                toolEndMs - toolStartMs
            } else {
                null
            }
        )
    }
}
