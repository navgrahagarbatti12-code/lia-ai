package com.Lia.assistant.forge

import java.io.File

enum class ForgePhase {
    IDLE,
    BUILDING,
    DONE,
    FAILED,
    CANCELLED
}

enum class ForgeStage(
    val index: Int,
    val label: String,
    val baseProgress: Float
) {
    SPARK(0, "Igniting Forge", 0.12f),
    STRUCTURE(1, "Weaving Structure", 0.28f),
    STYLING(2, "Sculpting Glass & Style", 0.48f),
    MOTION(3, "Choreographing Motion", 0.68f),
    VISUALS(4, "Rendering 3D & Visuals", 0.84f),
    POLISH(5, "Final Polish", 0.96f)
}

data class ForgeMetrics(
    val chars: Int = 0,
    val sections: Int = 0,
    val elapsedSec: Float = 0f,
    val tokensPerSec: Float = 0f
)

data class ForgeUiState(
    val phase: ForgePhase = ForgePhase.IDLE,
    val prompt: String = "",
    val isEdit: Boolean = false,
    val stage: ForgeStage = ForgeStage.SPARK,
    val progress: Float = 0f,
    val metrics: ForgeMetrics = ForgeMetrics(),
    val sections: List<String> = emptyList(),
    val log: List<String> = emptyList(),
    val logSeq: Int = 0,
    val buildId: String = "",
    val file: File? = null,
    val error: String? = null
)
