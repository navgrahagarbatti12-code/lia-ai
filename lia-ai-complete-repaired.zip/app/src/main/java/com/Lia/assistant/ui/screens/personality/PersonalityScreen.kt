package com.Lia.assistant.ui.screens.personality

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.data.Personality
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.voice.VoiceSessionManager

@Composable
fun PersonalityScreen(
    appState: NovaAppState,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        NovaTopBar(
            title = "Personality",
            subtitle = "Changes take effect immediately",
            onBack = onBack
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(NovaSpacing.lg),
            horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md),
            modifier = Modifier.weight(1f)
        ) {
            items(Personality.entries, key = { it.name }) { persona ->
                val selected = appState.personality == persona
                val liftScale by animateFloatAsState(
                    targetValue = if (!reducedMotion && selected) 1.04f else 1f,
                    animationSpec = tween(NovaMotion.NORMAL_MS),
                    label = "persona_lift"
                )
                val cardAlpha by animateFloatAsState(
                    targetValue = if (selected) 1f else 0.72f,
                    animationSpec = tween(NovaMotion.NORMAL_MS),
                    label = "persona_alpha"
                )

                NovaGlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            scaleX = liftScale
                            scaleY = liftScale
                            alpha = cardAlpha
                        },
                    elevation = if (selected) 14.dp else 4.dp,
                    borderColor = if (selected) colors.accent else colors.surfaceBorder,
                    onClick = {
                        appState.applyPersonality(persona)
                        VoiceSessionManager.refreshInstructions(context)
                    }
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                if (selected) colors.accent.copy(alpha = 0.24f)
                                else colors.surfaceRaised
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = persona.icon,
                            contentDescription = null,
                            tint = if (selected) colors.accent else colors.textSecondary
                        )
                    }
                    Spacer(Modifier.height(NovaSpacing.sm))
                    Text(
                        text = persona.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        color = if (selected) colors.accent else colors.textPrimary,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = persona.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
