package com.Lia.assistant.forge

import android.util.Log
import com.Lia.assistant.voice.GeminiTextClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object WebsiteForgeClient {
    private const val TAG = "WebsiteForgeClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

    private val streamClient by lazy {
        GeminiTextClient.httpClient.newBuilder()
            .readTimeout(180, TimeUnit.SECONDS)
            .build()
    }

    sealed class StreamOutcome {
        data class Completed(
            val html: String,
            val finishReason: String?
        ) : StreamOutcome()

        data class Failed(
            val userMessage: String,
            val retryableOverload: Boolean = false
        ) : StreamOutcome()
    }

    internal fun mapFriendlyError(code: Int, rawReason: String?): Pair<String, Boolean> {
        val reason = rawReason.orEmpty()
        val lower = reason.lowercase()
        return when {
            code == 503 || lower.contains("unavailable") || lower.contains("overloaded") ->
                "Gemini is momentarily busy. Retrying..." to true
            code == 429 || lower.contains("quota") || lower.contains("rate") ->
                "Rate limit reached. Wait a few seconds and tap Retry." to false
            code == 401 || code == 403 || lower.contains("api key") ->
                "Gemini API key was rejected. Check Settings." to false
            code >= 500 ->
                "Gemini server error ($code). Please retry." to false
            else ->
                (reason.ifBlank { "Generation failed ($code)." }) to false
        }
    }

    suspend fun streamHtml(
        apiKey: String,
        systemInstruction: String,
        userPrompt: String,
        onPartialUpdate: (accumulatedRaw: String) -> Unit
    ): StreamOutcome {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            return StreamOutcome.Failed("Please add your Gemini API key in Settings.")
        }

        val model = GeminiTextClient.resolveModel(cleanKey)
            ?: return StreamOutcome.Failed("Could not resolve a Gemini model. Check your API key and network.")

        val genConfig = JSONObject()
            .put("temperature", 0.7)
        if (model.contains("2.5")) {
            genConfig.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        }

        val payload = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            )
            .put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
                )
            )
            .put("generationConfig", genConfig)

        val request = Request.Builder()
            .url("$BASE_URL/models/$model:streamGenerateContent?alt=sse")
            .addHeader("x-goog-api-key", cleanKey)
            .post(payload.toString().toRequestBody(JSON_MEDIA))
            .build()

        val call = streamClient.newCall(request)
        val completionHandle = currentCoroutineContext().job.invokeOnCompletion { cause ->
            if (cause is CancellationException) {
                call.cancel()
            }
        }

        return withContext(Dispatchers.IO) {
            try {
                call.execute().use { response ->
                    if (!response.isSuccessful) {
                        val errBody = response.body?.string().orEmpty()
                        val rawReason = GeminiTextClient.extractGeminiErrorReason(errBody)
                        Log.w(TAG, "SSE HTTP ${response.code}: $rawReason")
                        val (friendly, retryable) = mapFriendlyError(response.code, rawReason)
                        return@withContext StreamOutcome.Failed(friendly, retryable)
                    }

                    val source = response.body?.source()
                        ?: return@withContext StreamOutcome.Failed("Empty response stream from Gemini.")

                    val acc = StringBuilder(16384)
                    var lastFinishReason: String? = null

                    while (!source.exhausted()) {
                        val line = source.readUtf8Line() ?: break
                        if (SseParser.isDoneLine(line)) break
                        val dataJson = SseParser.extractDataJson(line) ?: continue

                        SseParser.extractError(dataJson)?.let { streamErr ->
                            val (friendly, retryable) = mapFriendlyError(503, streamErr)
                            return@withContext StreamOutcome.Failed(friendly, retryable)
                        }

                        SseParser.extractFinishReason(dataJson)?.let { reason ->
                            lastFinishReason = reason
                            if (reason != "STOP") {
                                Log.w(TAG, "Stream finishReason=$reason")
                            }
                        }

                        val chunkText = SseParser.extractText(dataJson)
                        if (chunkText.isNotEmpty()) {
                            acc.append(chunkText)
                            onPartialUpdate(acc.toString())
                        }
                    }

                    StreamOutcome.Completed(
                        html = acc.toString(),
                        finishReason = lastFinishReason
                    )
                }
            } catch (e: CancellationException) {
                call.cancel()
                throw e
            } catch (_: IOException) {
                StreamOutcome.Failed("Couldn't reach Gemini. Check your connection and try again.")
            } finally {
                completionHandle.dispose()
            }
        }
    }
}
