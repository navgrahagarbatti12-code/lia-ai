package com.Lia.assistant.ui.fx

enum class NovaOrbStyle(
    val displayName: String,
    val description: String
) {
    NOVA("Nova", "Balanced glowing pearl with smooth orbital aura"),
    AURORA("Aurora", "Flowing northern-lights ribbons around the core"),
    PLASMA("Plasma", "High-energy swirling core with vivid particles"),
    GLASS("Glass", "Frosted crystal sphere with sharp specular rim"),
    ENERGY("Energy", "Dense orbital swarm crackling with motion"),
    MINIMAL("Minimal", "Pure calm pearl with gentle breathing"),
    ARCHER("Archer", "400-point golden-spiral particle sphere");

    companion object {
        fun fromStored(value: String?): NovaOrbStyle =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: NOVA
    }
}
