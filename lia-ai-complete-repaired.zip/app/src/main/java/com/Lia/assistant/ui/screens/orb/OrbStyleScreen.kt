package com.Lia.assistant.ui.screens.orb

import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrb
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.fx.NovaOrbStyle
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import kotlin.math.abs

@Composable
fun OrbStyleScreen(
    appState: NovaAppState,
    onBack: () -> Unit
) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    var previewState by remember { mutableStateOf(NovaOrbState.IDLE) }

    val styles = NovaOrbStyle.entries
    val initialIndex = styles.indexOf(appState.orbStyle).coerceAtLeast(0)
    val rowState = rememberLazyListState(initialFirstVisibleItemIndex = initialIndex)
    val fling = rememberSnapFlingBehavior(lazyListState = rowState)

    val previewAmp = when (previewState) {
        NovaOrbState.SPEAKING -> 0.65f
        NovaOrbState.LISTENING -> 0.3f
        else -> 0.08f
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        NovaTopBar(
            title = "Orb Style",
            subtitle = "Choose ${appState.assistantName}'s 3D form",
            onBack = onBack
        )

        Spacer(Modifier.height(NovaSpacing.md))

        // Live preview area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp),
            contentAlignment = Alignment.Center
        ) {
            LiaOrb3D(
                state = previewState,
                size = 200.dp,
                amplitude = previewAmp,
                style = appState.orbStyle,
                assistantName = appState.assistantName
            )
        }

        // State preview chips: Idle / Listening / Speaking
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(NovaSpacing.sm, Alignment.CenterHorizontally)
        ) {
            listOf(NovaOrbState.IDLE, NovaOrbState.LISTENING, NovaOrbState.SPEAKING).forEach { st ->
                val selected = previewState == st
                FilterChip(
                    selected = selected,
                    onClick = { previewState = st },
                    label = { Text(st.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = colors.accent.copy(alpha = 0.25f),
                        selectedLabelColor = colors.accent,
                        labelColor = colors.textSecondary
                    )
                )
            }
        }

        Spacer(Modifier.height(NovaSpacing.lg))

        // Snapping 3D coverflow carousel (+-35 deg rotationY)
        LazyRow(
            state = rowState,
            flingBehavior = fling,
            contentPadding = PaddingValues(horizontal = 72.dp),
            horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md),
            modifier = Modifier.fillMaxWidth()
        ) {
            itemsIndexed(styles, key = { _, s -> s.name }) { idx, style ->
                val coverflow by remember(rowState, idx, reducedMotion) {
                    derivedStateOf {
                        if (reducedMotion) 0f
                        else {
                            val info = rowState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx }
                                ?: return@derivedStateOf 0f
                            val vpCenter = rowState.layoutInfo.viewportEndOffset / 2f
                            val itemCenter = info.offset + info.size / 2f
                            ((itemCenter - vpCenter) / vpCenter.coerceAtLeast(1f)).coerceIn(-1f, 1f)
                        }
                    }
                }

                val isSelected = appState.orbStyle == style
                val scale = if (reducedMotion) 1f else (1f - abs(coverflow) * 0.14f).coerceIn(0.84f, 1.05f)

                NovaGlassCard(
                    modifier = Modifier
                        .width(210.dp)
                        .graphicsLayer {
                            rotationY = if (reducedMotion) 0f else -coverflow * 35f
                            scaleX = scale
                            scaleY = scale
                            cameraDistance = 14f * density
                        },
                    elevation = if (isSelected) 14.dp else 6.dp,
                    borderColor = if (isSelected) colors.accent else colors.surfaceBorder,
                    onClick = { appState.applyOrbStyle(style) }
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        NovaOrb(
                            state = previewState,
                            size = 86.dp,
                            amplitude = previewAmp * 0.6f,
                            style = style,
                            assistantName = appState.assistantName
                        )
                        Spacer(Modifier.height(NovaSpacing.sm))
                        Text(
                            text = style.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (isSelected) colors.accent else colors.textPrimary
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = style.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }
            }
        }
    }
}
