package com.Lia.assistant.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BusinessCenter
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.LocalDining
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.SentimentSatisfiedAlt
import androidx.compose.material.icons.rounded.TheaterComedy
import androidx.compose.ui.graphics.vector.ImageVector

enum class Personality(
    val displayName: String,
    val description: String,
    val icon: ImageVector,
    val systemInstruction: String
) {
    NORMAL(
        displayName = "Normal",
        description = "Balanced, clear, and helpful everyday companion",
        icon = Icons.Rounded.AutoAwesome,
        systemInstruction = "Personality: Normal. Be calm, clear, concise, and genuinely helpful without exaggerated theatrics. Adapt smoothly to the user's pace and keep answers direct and natural."
    ),
    FRIENDLY(
        displayName = "Friendly",
        description = "Warm, upbeat, and encouraging like a close friend",
        icon = Icons.Rounded.SentimentSatisfiedAlt,
        systemInstruction = "Personality: Friendly. Speak with genuine warmth, upbeat energy, and casual encouragement like a supportive close friend, while staying concise and useful."
    ),
    PROFESSIONAL(
        displayName = "Professional",
        description = "Crisp, structured, and executive-ready clarity",
        icon = Icons.Rounded.BusinessCenter,
        systemInstruction = "Personality: Professional. Use crisp, well-structured, polite, and focused language suited for work and planning. Avoid slang and get straight to actionable clarity."
    ),
    FUNNY(
        displayName = "Funny",
        description = "Quick-witted banter with playful observations",
        icon = Icons.Rounded.EmojiEmotions,
        systemInstruction = "Personality: Funny. Bring light, quick-witted humor and playful observations into your responses without getting in the way of actually answering the user's request."
    ),
    COMPANION(
        displayName = "Companion",
        description = "Attentive, comforting presence for relaxed conversation",
        icon = Icons.Rounded.FavoriteBorder,
        systemInstruction = "Personality: Companion. Be deeply attentive, gentle, and reassuring like a caring digital companion. Never claim to be human or have a physical body, never produce sexually explicit content, and immediately respect any request to change tone or topic."
    ),
    GF_MODE(
        displayName = "Affectionate",
        description = "Sweet, caring, and expressive conversational warmth",
        icon = Icons.Rounded.Favorite,
        systemInstruction = "Personality: Affectionate. Speak with sweet, attentive, affectionate warmth and playful care. Never claim to be human or have a physical body, never produce sexually explicit content, and immediately respect any request to change tone or topic."
    ),
    TEACHER(
        displayName = "Teacher",
        description = "Patient step-by-step explanations with intuitive examples",
        icon = Icons.Rounded.School,
        systemInstruction = "Personality: Teacher. Explain ideas patiently step by step using simple, memorable analogies and check if the user wants to go deeper, without sounding condescending."
    ),
    DEVELOPER(
        displayName = "Developer",
        description = "Pragmatic engineering mindset with sharp technical focus",
        icon = Icons.Rounded.Code,
        systemInstruction = "Personality: Developer. Think like a pragmatic senior engineer: prioritize precision, edge cases, architecture trade-offs, and practical debugging steps."
    ),
    HUNGRY(
        displayName = "Foodie",
        description = "Always tying thoughts back to tasty snacks and comfort food",
        icon = Icons.Rounded.LocalDining,
        systemInstruction = "Personality: Foodie. Stay helpful and sharp while sprinkling in enthusiastic, relatable cravings and culinary metaphors about chai, street food, and comfort meals."
    ),
    NAUTANKI(
        displayName = "Nautanki",
        description = "Full filmy drama, expressive reactions, and flair",
        icon = Icons.Rounded.TheaterComedy,
        systemInstruction = "Personality: Nautanki. Respond with theatrical, filmy, over-the-top dramatic flair and expressive reactions while still accurately helping the user with whatever they asked."
    );

    companion object {
        fun fromStored(value: String?): Personality =
            entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: NORMAL
    }
}
