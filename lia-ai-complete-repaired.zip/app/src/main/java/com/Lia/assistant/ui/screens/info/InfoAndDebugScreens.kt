package com.Lia.assistant.ui.screens.info

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.Lia.assistant.BuildConfig
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.voice.EchoGuard
import com.Lia.assistant.voice.VoiceLatencyTracker
import com.Lia.assistant.voice.VoiceSessionManager

@Composable
fun PrivacyScreen(
    appState: NovaAppState,
    onBack: () -> Unit
) {
    val colors = LocalNovaColors.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        NovaTopBar(
            title = "Privacy",
            subtitle = "How your data stays yours",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(NovaSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md)
        ) {
            NovaGlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("On-Device First", style = MaterialTheme.typography.titleLarge, color = colors.textPrimary)
                Spacer(Modifier.height(NovaSpacing.sm))
                Text(
                    text = "• Your Gemini API key is stored privately in app SharedPreferences and sent only directly to Google Gemini endpoints.\n" +
                        "• Voice audio streams directly to Gemini Live only while Voice Mode is active.\n" +
                        "• Chat transcripts and generated websites stay locally inside your app storage until you delete them.\n" +
                        "• Prompts, API keys, audio buffers, and generated HTML are never written to system logs.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = colors.textSecondary
                )
            }
            NovaGlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Saved Items", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Spacer(Modifier.height(NovaSpacing.xs))
                Text(
                    text = "${appState.conversations.size} typed conversations stored locally.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
                Spacer(Modifier.height(NovaSpacing.md))
                NovaButton(
                    text = "Delete All Conversations",
                    style = NovaButtonStyle.SECONDARY,
                    tintOverride = colors.error,
                    onClick = { appState.clearConversations() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun AboutScreen(
    appState: NovaAppState,
    onBack: () -> Unit,
    onOpenDebug: () -> Unit
) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current

    val oflText = rememberOflLicenseText(context)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        NovaTopBar(
            title = "About ${appState.assistantName}",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(NovaSpacing.lg),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md)
        ) {
            LiaOrb3D(
                state = NovaOrbState.IDLE,
                size = 120.dp,
                style = appState.orbStyle,
                assistantName = appState.assistantName
            )
            Text(
                text = appState.assistantName,
                style = MaterialTheme.typography.displayMedium,
                color = colors.textPrimary
            )
            Text(
                text = "Version ${BuildConfig.VERSION_NAME} (${BuildConfig.FLAVOR})",
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary
            )

            NovaGlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Capabilities", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Spacer(Modifier.height(NovaSpacing.xs))
                Text(
                    text = "Real-time Gemini Live voice in Hindi, Hinglish, and English, 10 adaptive personalities, typed chat, and the live 3D Website Forge.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
                Spacer(Modifier.height(NovaSpacing.md))
                NovaButton(
                    text = "Open Voice Pipeline Debugger",
                    style = NovaButtonStyle.SECONDARY,
                    onClick = onOpenDebug,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (oflText.isNotBlank()) {
                NovaGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Typography License", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                    Spacer(Modifier.height(NovaSpacing.xs))
                    Text(
                        text = oflText.take(600),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun rememberOflLicenseText(context: android.content.Context): String =
    androidx.compose.runtime.remember(context) {
        runCatching {
            context.assets.open("OFL_FONT_LICENSE.txt").bufferedReader().use { it.readText() }
        }.getOrDefault("")
    }

@Composable
fun DebugScreen(
    appState: NovaAppState,
    onBack: () -> Unit
) {
    val colors = LocalNovaColors.current
    val orbState by VoiceSessionManager.state.collectAsState()
    val isActive by VoiceSessionManager.isActive.collectAsState()
    val muted by VoiceSessionManager.muted.collectAsState()
    val vadActive by VoiceSessionManager.vadActive.collectAsState()
    val detectedLang by VoiceSessionManager.detectedLanguage.collectAsState()
    val latency by VoiceLatencyTracker.snapshot.collectAsState()
    val reconnects by VoiceLatencyTracker.reconnectCount.collectAsState()
    val lastError by VoiceSessionManager.lastError.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        NovaTopBar(
            title = "Voice Pipeline Debugger",
            subtitle = "Flavor: ${BuildConfig.FLAVOR}",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(NovaSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md)
        ) {
            NovaGlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Session State", style = MaterialTheme.typography.titleMedium, color = colors.accent)
                Spacer(Modifier.height(NovaSpacing.sm))
                DebugRow("Connection State", if (isActive) orbState.label else "Disconnected")
                DebugRow("Selected Personality", appState.personality.displayName)
                DebugRow("Configured Language", appState.language.displayName)
                DebugRow("Detected Language", detectedLang.name)
                DebugRow("VAD Speech Active", if (vadActive) "Active" else "Silent")
                DebugRow("Mic State", if (muted) "User Muted" else if (EchoGuard.isMicMuted()) "EchoGuard Muted" else "Open")
                DebugRow("Reconnect Count", reconnects.toString())
                if (!lastError.isNullOrBlank()) {
                    DebugRow("Last Error", lastError!!)
                }
            }

            NovaGlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Per-Turn Latency", style = MaterialTheme.typography.titleMedium, color = colors.lagoon)
                Spacer(Modifier.height(NovaSpacing.sm))
                DebugRow("First Audio Byte", latency.firstAudioLatencyMs?.let { "$it ms" } ?: "—")
                DebugRow("Turn Duration", latency.turnDurationMs?.let { "$it ms" } ?: "—")
                DebugRow("Tool Execution", latency.toolExecutionMs?.let { "$it ms" } ?: "—")
            }

            NovaButton(
                text = "Reset Latency Snapshot",
                style = NovaButtonStyle.SECONDARY,
                onClick = { VoiceLatencyTracker.reset() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun DebugRow(label: String, value: String) {
    val colors = LocalNovaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
        Text(text = value, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
    }
}
