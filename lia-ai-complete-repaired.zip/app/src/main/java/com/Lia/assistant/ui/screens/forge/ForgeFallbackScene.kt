package com.Lia.assistant.ui.screens.forge

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.Lia.assistant.forge.ForgePhase
import com.Lia.assistant.forge.ForgeUiState
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ForgeFallbackScene(
    state: ForgeUiState,
    modifier: Modifier = Modifier
) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val transition = rememberInfiniteTransition(label = "forge_fallback")
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(7200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "fallback_spin"
    )
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "fallback_pulse"
    )

    val effectiveSpin = if (reducedMotion) 0f else spin
    val effectivePulse = if (reducedMotion) 0.5f else (0.5f + 0.5f * sin(pulse))
    val isFailed = state.phase == ForgePhase.FAILED || state.phase == ForgePhase.CANCELLED

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .semantics {
                contentDescription = "Website Forge build reactor at ${(state.progress * 100).toInt()}%"
            }
    ) {
        val cx = size.width / 2f
        val cy = size.height * 0.44f
        val baseR = minOf(size.width, size.height) * 0.22f

        val coreColor = if (isFailed) colors.error else colors.accent
        val ringColor = if (isFailed) colors.textTertiary else colors.lagoon

        // Backdrop radial aura
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    coreColor.copy(alpha = 0.26f + effectivePulse * 0.14f),
                    colors.lotus.copy(alpha = 0.12f),
                    Color.Transparent
                ),
                center = Offset(cx, cy),
                radius = baseR * 2.6f
            ),
            radius = baseR * 2.6f,
            center = Offset(cx, cy)
        )

        // Floor perspective grid rings
        for (i in 1..4) {
            val r = baseR * (0.7f + i * 0.48f)
            drawCircle(
                color = colors.surfaceBorder.copy(alpha = 0.35f / i),
                radius = r,
                center = Offset(cx, cy),
                style = Stroke(width = 1.2.dp.toPx())
            )
        }

        // Progress arc around reactor
        val progressRadius = baseR * 1.38f
        drawArc(
            color = ringColor.copy(alpha = 0.25f),
            startAngle = 0f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = Offset(cx - progressRadius, cy - progressRadius),
            size = Size(progressRadius * 2f, progressRadius * 2f),
            style = Stroke(width = 4.dp.toPx())
        )
        drawArc(
            color = coreColor,
            startAngle = -90f + effectiveSpin * 0.25f,
            sweepAngle = (state.progress.coerceIn(0.05f, 1f)) * 360f,
            useCenter = false,
            topLeft = Offset(cx - progressRadius, cy - progressRadius),
            size = Size(progressRadius * 2f, progressRadius * 2f),
            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
        )

        // Orbiting slab nodes representing generated sections
        val slabCount = (state.sections.size + 1).coerceIn(1, 10)
        for (i in 0 until slabCount) {
            val a = Math.toRadians((effectiveSpin + i * (360f / slabCount)).toDouble())
            val rx = cx + (cos(a) * baseR * 1.65f).toFloat()
            val ry = cy + (sin(a) * baseR * 0.92f).toFloat()
            drawRoundRect(
                color = colors.surfaceGlass,
                topLeft = Offset(rx - 14.dp.toPx(), ry - 9.dp.toPx()),
                size = Size(28.dp.toPx(), 18.dp.toPx()),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx())
            )
            drawRoundRect(
                color = ringColor.copy(alpha = 0.7f),
                topLeft = Offset(rx - 14.dp.toPx(), ry - 9.dp.toPx()),
                size = Size(28.dp.toPx(), 18.dp.toPx()),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        // Core sphere
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.85f), coreColor, colors.lotus.copy(alpha = 0.65f)),
                center = Offset(cx - baseR * 0.16f, cy - baseR * 0.16f),
                radius = baseR * 0.9f
            ),
            radius = baseR * (0.58f + effectivePulse * 0.05f),
            center = Offset(cx, cy)
        )
    }
}
