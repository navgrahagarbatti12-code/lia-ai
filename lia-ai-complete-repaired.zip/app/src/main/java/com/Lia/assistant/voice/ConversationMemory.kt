package com.Lia.assistant.voice

object ConversationMemory {
    enum class Role {
        USER,
        ASSISTANT
    }

    data class Turn(
        val role: Role,
        val text: String
    )

    private const val MAX_TURNS = 12
    private const val MAX_RECAP_CHARS = 1600

    private val lock = Any()
    private val history = ArrayDeque<Turn>(MAX_TURNS)

    fun addUserTurn(text: String) {
        addTurn(Role.USER, text)
    }

    fun addAssistantTurn(text: String) {
        addTurn(Role.ASSISTANT, text)
    }

    fun addTurn(role: Role, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        synchronized(lock) {
            if (history.size >= MAX_TURNS) {
                history.removeFirst()
            }
            history.addLast(Turn(role, clean))
        }
    }

    fun turns(): List<Turn> = synchronized(lock) { history.toList() }

    fun recap(): String? {
        val snapshot = turns()
        if (snapshot.isEmpty()) return null
        val full = snapshot.joinToString(separator = "\n") { turn ->
            val prefix = if (turn.role == Role.USER) "User" else "You"
            "$prefix: ${turn.text}"
        }
        return if (full.length <= MAX_RECAP_CHARS) {
            full
        } else {
            full.takeLast(MAX_RECAP_CHARS)
        }
    }

    fun clear() {
        synchronized(lock) {
            history.clear()
        }
    }
}
