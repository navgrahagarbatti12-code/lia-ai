package com.Lia.assistant.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.Lia.assistant.data.ThemeMode

val LocalNovaColors = staticCompositionLocalOf { DarkNovaColors }
val LocalNovaReducedMotion = staticCompositionLocalOf { false }
val LocalNovaIsDark = staticCompositionLocalOf { true }

@Composable
fun NovaTheme(
    mode: ThemeMode = ThemeMode.DARK,
    reducedMotion: Boolean = false,
    content: @Composable () -> Unit
) {
    val isDark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val novaColors = if (isDark) DarkNovaColors else LightNovaColors

    val materialScheme = if (isDark) {
        darkColorScheme(
            primary = novaColors.accent,
            onPrimary = novaColors.onAccent,
            secondary = novaColors.accentSecondary,
            onSecondary = novaColors.onAccent,
            background = novaColors.background,
            onBackground = novaColors.textPrimary,
            surface = novaColors.surface,
            onSurface = novaColors.textPrimary,
            surfaceVariant = novaColors.surfaceRaised,
            onSurfaceVariant = novaColors.textSecondary,
            outline = novaColors.surfaceBorder,
            error = novaColors.error,
            onError = novaColors.onAccent
        )
    } else {
        lightColorScheme(
            primary = novaColors.accent,
            onPrimary = novaColors.onAccent,
            secondary = novaColors.accentSecondary,
            onSecondary = novaColors.onAccent,
            background = novaColors.background,
            onBackground = novaColors.textPrimary,
            surface = novaColors.surface,
            onSurface = novaColors.textPrimary,
            surfaceVariant = novaColors.surfaceRaised,
            onSurfaceVariant = novaColors.textSecondary,
            outline = novaColors.surfaceBorder,
            error = novaColors.error,
            onError = novaColors.onAccent
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            @Suppress("DEPRECATION")
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            @Suppress("DEPRECATION")
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !isDark
            controller.isAppearanceLightNavigationBars = !isDark
        }
    }

    CompositionLocalProvider(
        LocalNovaColors provides novaColors,
        LocalNovaReducedMotion provides reducedMotion,
        LocalNovaIsDark provides isDark
    ) {
        MaterialTheme(
            colorScheme = materialScheme,
            typography = NovaTypography,
            content = content
        )
    }
}
