package com.Lia.assistant.voice

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object EchoGuard {
    const val ECHO_TAIL_MS = 450L
    const val WATCHDOG_MS = 60_000L

    private val lock = Any()
    private var scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var activePlaybackCount = 0

    @Volatile
    private var micMuted = false

    private var tailJob: Job? = null
    private var watchdogJob: Job? = null

    internal fun setScopeForTesting(testScope: CoroutineScope) {
        synchronized(lock) {
            tailJob?.cancel()
            watchdogJob?.cancel()
            tailJob = null
            watchdogJob = null
            activePlaybackCount = 0
            micMuted = false
            scope = testScope
        }
    }

    fun notifyPlaybackStarted() {
        synchronized(lock) {
            tailJob?.cancel()
            tailJob = null
            activePlaybackCount++
            micMuted = true

            watchdogJob?.cancel()
            watchdogJob = scope.launch {
                delay(WATCHDOG_MS)
                synchronized(lock) {
                    activePlaybackCount = 0
                    micMuted = false
                    tailJob?.cancel()
                    tailJob = null
                    watchdogJob = null
                }
            }
        }
    }

    fun notifyPlaybackStopped() {
        synchronized(lock) {
            if (activePlaybackCount > 0) {
                activePlaybackCount--
            }
            if (activePlaybackCount == 0) {
                tailJob?.cancel()
                tailJob = scope.launch {
                    delay(ECHO_TAIL_MS)
                    synchronized(lock) {
                        if (activePlaybackCount == 0) {
                            micMuted = false
                            watchdogJob?.cancel()
                            watchdogJob = null
                        }
                        tailJob = null
                    }
                }
            }
        }
    }

    fun isMicMuted(): Boolean = micMuted

    fun reset() {
        synchronized(lock) {
            tailJob?.cancel()
            watchdogJob?.cancel()
            tailJob = null
            watchdogJob = null
            activePlaybackCount = 0
            micMuted = false
        }
    }
}
