package com.Lia.assistant.voice

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import kotlin.math.max
import kotlin.math.sqrt

class LiveAudioIO(
    private val onMicChunk: (ByteArray) -> Unit,
    private val onMicAmplitude: (Float) -> Unit
) {
    private val micLock = Any()
    private val trackLock = Any()

    @Volatile
    private var capturing = false
    private var captureThread: Thread? = null
    private var audioRecord: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null

    private var audioTrack: AudioTrack? = null

    @Volatile
    private var playbackVolume: Float = 1.0f

    @SuppressLint("MissingPermission")
    fun startMic(): Boolean {
        synchronized(micLock) {
            if (capturing) return true
            val minBuf = AudioRecord.getMinBufferSize(
                MIC_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuf == AudioRecord.ERROR || minBuf == AudioRecord.ERROR_BAD_VALUE) {
                return false
            }
            val bufferSize = max(minBuf, 4096)
            val record = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    MIC_SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize
                )
            } catch (_: Throwable) {
                return false
            }
            if (record.state != AudioRecord.STATE_INITIALIZED) {
                runCatching { record.release() }
                return false
            }

            val sessionId = record.audioSessionId
            try {
                if (AcousticEchoCanceler.isAvailable()) {
                    aec = AcousticEchoCanceler.create(sessionId)?.apply { enabled = true }
                }
            } catch (_: Throwable) {
            }
            try {
                if (NoiseSuppressor.isAvailable()) {
                    ns = NoiseSuppressor.create(sessionId)?.apply { enabled = true }
                }
            } catch (_: Throwable) {
            }
            try {
                if (AutomaticGainControl.isAvailable()) {
                    agc = AutomaticGainControl.create(sessionId)?.apply { enabled = true }
                }
            } catch (_: Throwable) {
            }

            audioRecord = record
            capturing = true
            try {
                record.startRecording()
            } catch (_: Throwable) {
                capturing = false
                releaseMicLocked()
                return false
            }

            captureThread = Thread({
                val chunk = ByteArray(MIC_CHUNK_BYTES)
                while (capturing) {
                    val read = try {
                        record.read(chunk, 0, chunk.size)
                    } catch (_: Throwable) {
                        -1
                    }
                    if (read > 0) {
                        val copy = if (read == chunk.size) chunk.copyOf() else chunk.copyOf(read)
                        onMicAmplitude(rms(copy))
                        onMicChunk(copy)
                    } else if (read < 0) {
                        break
                    }
                }
            }, "LiaMicCapture").apply {
                priority = Thread.MAX_PRIORITY
                start()
            }
            return true
        }
    }

    fun playChunk(bytes: ByteArray): Float {
        if (bytes.isEmpty()) return 0f
        val level = rms(bytes)
        val track = ensureTrack() ?: return level
        var offset = 0
        while (offset < bytes.size) {
            val written = try {
                track.write(bytes, offset, bytes.size - offset)
            } catch (_: Throwable) {
                break
            }
            if (written <= 0) break
            offset += written
        }
        return level
    }

    fun flushPlayback() {
        synchronized(trackLock) {
            val track = audioTrack ?: return
            runCatching {
                track.pause()
                track.flush()
                track.play()
            }
        }
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        playbackVolume = clamped
        synchronized(trackLock) {
            runCatching { audioTrack?.setVolume(clamped) }
        }
    }

    fun release() {
        synchronized(micLock) {
            releaseMicLocked()
        }
        synchronized(trackLock) {
            audioTrack?.let { track ->
                runCatching { track.pause() }
                runCatching { track.flush() }
                runCatching { track.stop() }
                runCatching { track.release() }
            }
            audioTrack = null
        }
    }

    private fun releaseMicLocked() {
        capturing = false
        val thread = captureThread
        captureThread = null
        audioRecord?.let { record ->
            runCatching { record.stop() }
            runCatching { record.release() }
        }
        audioRecord = null
        runCatching { thread?.join(250) }
        runCatching { aec?.release() }
        aec = null
        runCatching { ns?.release() }
        ns = null
        runCatching { agc?.release() }
        agc = null
    }

    private fun ensureTrack(): AudioTrack? {
        synchronized(trackLock) {
            audioTrack?.let { return it }
            val minBuf = AudioTrack.getMinBufferSize(
                SPEAKER_SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuf == AudioTrack.ERROR || minBuf == AudioTrack.ERROR_BAD_VALUE) {
                return null
            }
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(SPEAKER_SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .build()
            val track = try {
                AudioTrack(
                    attributes,
                    format,
                    minBuf * 4,
                    AudioTrack.MODE_STREAM,
                    android.media.AudioManager.AUDIO_SESSION_ID_GENERATE
                )
            } catch (_: Throwable) {
                return null
            }
            if (track.state != AudioTrack.STATE_INITIALIZED) {
                runCatching { track.release() }
                return null
            }
            runCatching { track.setVolume(playbackVolume) }
            runCatching { track.play() }
            audioTrack = track
            return track
        }
    }

    companion object {
        const val MIC_SAMPLE_RATE = 16_000
        const val SPEAKER_SAMPLE_RATE = 24_000
        const val MIC_CHUNK_BYTES = 2048

        fun rms(pcmBytes: ByteArray): Float {
            val sampleCount = pcmBytes.size / 2
            if (sampleCount <= 0) return 0f
            var sumSq = 0.0
            var i = 0
            while (i + 1 < pcmBytes.size) {
                val lo = pcmBytes[i].toInt() and 0xFF
                val hi = pcmBytes[i + 1].toInt()
                val sample = (hi shl 8) or lo
                val d = sample.toDouble()
                sumSq += d * d
                i += 2
            }
            val rms = sqrt(sumSq / sampleCount.toDouble()) / 32768.0
            return rms.toFloat().coerceIn(0f, 1f)
        }
    }
}
