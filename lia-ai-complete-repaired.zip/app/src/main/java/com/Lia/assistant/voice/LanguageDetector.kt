package com.Lia.assistant.voice

enum class DetectedLanguage {
    HINDI,
    HINGLISH,
    ENGLISH,
    UNKNOWN
}

object LanguageDetector {
    private val SPLIT_REGEX = Regex("[^a-zA-Z']+")

    private val HINGLISH_MARKERS = setOf(
        "hai", "hain", "ho", "hoon", "hun", "kya", "kyun", "kyon", "kaise", "kaisa", "kaisi",
        "nahi", "nahin", "haan", "haa", "mujhe", "mujhko", "tumhe", "tumko", "aap", "aapka",
        "aapki", "aapke", "mera", "meri", "mere", "tera", "teri", "tere", "humara", "hamara",
        "yaar", "bhai", "dost", "accha", "achha", "achcha", "theek", "thik", "matlab", "karna",
        "karo", "kar", "karke", "raha", "rahi", "rahe", "chahiye", "chaahiye", "batao", "bata",
        "suno", "sun", "dekho", "dekh", "abhi", "phir", "fir", "lekin", "magar", "bahut", "bohot",
        "thoda", "thodi", "thode", "kuch", "kuchh", "sab", "wala", "wali", "wale", "banao",
        "banado", "bana", "kholo", "khol", "bolo", "bol", "samjho", "samajh", "chalo", "kahan",
        "kab", "kaun", "kitna", "kitni", "kisko", "kisne", "yeh", "woh", "toh", "bhi", "aur",
        "tha", "thi", "ek", "ka", "ki", "ke", "ko", "mein", "hoga", "hogi", "honge", "sakta", "sakti", "sakte", "khana",
        "paani", "paisa", "paise", "ghar", "kaam", "baat", "din", "raat", "subah", "shaam",
        "namaste", "shukriya", "dhanyawad", "arre", "arey", "chalega", "badiya", "badhiya",
        "mast", "jaldi", "pehle", "baad", "waise", "kyunki", "isliye", "agar"
    )

    fun detect(text: String): DetectedLanguage {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return DetectedLanguage.UNKNOWN

        for (ch in trimmed) {
            if (ch in '\u0900'..'\u097F') {
                return DetectedLanguage.HINDI
            }
        }

        val words = trimmed.lowercase()
            .split(SPLIT_REGEX)
            .filter { it.isNotEmpty() }

        if (words.isEmpty()) return DetectedLanguage.UNKNOWN

        val hits = words.count { it in HINGLISH_MARKERS }
        return if (words.size <= 4) {
            if (hits >= 1) DetectedLanguage.HINGLISH else DetectedLanguage.ENGLISH
        } else {
            val ratio = hits.toDouble() / words.size.toDouble()
            if (hits >= 2 || ratio >= 0.15) DetectedLanguage.HINGLISH else DetectedLanguage.ENGLISH
        }
    }
}
