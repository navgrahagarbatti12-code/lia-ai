package com.Lia.assistant.ui.screens.settings

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.Contrast
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MotionPhotosOff
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.data.ThemeMode
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaConfirmDialog
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaPickerDialog
import com.Lia.assistant.ui.components.NovaSectionHeader
import com.Lia.assistant.ui.components.NovaSettingsRow
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.navigation.AccessibilitySettingsRows
import com.Lia.assistant.ui.theme.LocalBottomBarInset
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.voice.GeminiTextClient
import com.Lia.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun SettingsScreen(
    appState: NovaAppState,
    onOpenProfile: () -> Unit,
    onOpenPersonality: () -> Unit,
    onOpenOrbStyle: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenDebug: () -> Unit,
    onOpenAccessibilityDisclosure: () -> Unit
) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val bottomInset = LocalBottomBarInset.current
    val scope = rememberCoroutineScope()

    var apiKeyText by remember { mutableStateOf(ApiKeyStore.getKey(context)) }
    var showApiKey by remember { mutableStateOf(false) }
    var apiTestStatus by remember { mutableStateOf<String?>(null) }
    var testingKey by remember { mutableStateOf(false) }

    var showNameDialog by remember { mutableStateOf(false) }
    var draftAssistantName by remember { mutableStateOf(appState.assistantName) }
    var showLangPicker by remember { mutableStateOf(false) }
    var showThemePicker by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(bottom = bottomInset)
    ) {
        Text(
            text = "Settings",
            style = MaterialTheme.typography.headlineLarge,
            color = colors.textPrimary,
            modifier = Modifier.padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm)
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md)
        ) {
            // Card 0: Profile Top Card
            NovaGlassCard(
                modifier = Modifier.fillMaxWidth(),
                elevation = 10.dp,
                onClick = onOpenProfile
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(CircleShape)
                                .background(colors.accent.copy(alpha = 0.2f))
                        )
                        LiaOrb3D(
                            state = NovaOrbState.IDLE,
                            size = 48.dp,
                            style = appState.orbStyle,
                            assistantName = appState.assistantName
                        )
                    }
                    Spacer(Modifier.width(NovaSpacing.md))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = appState.userName.ifBlank { "Your Profile" },
                            style = MaterialTheme.typography.titleLarge,
                            color = colors.textPrimary
                        )
                        Text(
                            text = "Assistant: ${appState.assistantName} • Voice: ${appState.voiceName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                    Icon(
                        imageVector = Icons.Rounded.Person,
                        contentDescription = null,
                        tint = colors.accent
                    )
                }
            }

            // Card 1: Gemini API Key
            NovaGlassCard(modifier = Modifier.fillMaxWidth(), elevation = 8.dp) {
                NovaSectionHeader("Gemini Connection")
                NovaTextField(
                    value = apiKeyText,
                    onValueChange = {
                        apiKeyText = it
                        apiTestStatus = null
                    },
                    placeholder = "Paste Gemini API key (AIza...)",
                    leadingIcon = Icons.Rounded.Key,
                    visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingContent = {
                        IconButton(
                            onClick = { showApiKey = !showApiKey },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = if (showApiKey) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                contentDescription = if (showApiKey) "Hide key" else "Show key",
                                tint = colors.textSecondary
                            )
                        }
                    },
                    testTag = "settings_api_key_input"
                )
                apiTestStatus?.let { st ->
                    Spacer(Modifier.height(NovaSpacing.xs))
                    Text(text = st, style = MaterialTheme.typography.bodySmall, color = colors.lagoon)
                }
                Spacer(Modifier.height(NovaSpacing.md))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(NovaSpacing.sm)
                ) {
                    NovaButton(
                        text = "Save Key",
                        onClick = {
                            ApiKeyStore.saveKey(context, apiKeyText)
                            apiTestStatus = if (apiKeyText.isBlank()) "Key cleared" else "Saved locally on device"
                            Toast.makeText(context, apiTestStatus, Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        testTag = "settings_save_key_button"
                    )
                    NovaButton(
                        text = if (testingKey) "Testing..." else "Test Key",
                        style = NovaButtonStyle.SECONDARY,
                        enabled = !testingKey && apiKeyText.isNotBlank(),
                        onClick = {
                            testingKey = true
                            ApiKeyStore.saveKey(context, apiKeyText)
                            scope.launch {
                                GeminiTextClient.invalidateModelCache()
                                val model = GeminiTextClient.resolveModel(apiKeyText)
                                testingKey = false
                                apiTestStatus = if (model != null) {
                                    "Connected • Model: $model"
                                } else {
                                    "Could not verify key or network"
                                }
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Card 2: Companion & Brain
            NovaGlassCard(modifier = Modifier.fillMaxWidth(), elevation = 6.dp) {
                NovaSectionHeader("Companion & Brain")
                NovaSettingsRow(
                    icon = Icons.Rounded.Edit,
                    title = "Assistant Name",
                    subtitle = "Updates prompts and greetings everywhere",
                    value = appState.assistantName,
                    onClick = {
                        draftAssistantName = appState.assistantName
                        showNameDialog = true
                    }
                )
                NovaSettingsRow(
                    icon = Icons.Rounded.Psychology,
                    title = "Personality",
                    subtitle = appState.personality.description,
                    value = appState.personality.displayName,
                    iconTint = colors.lotus,
                    onClick = onOpenPersonality
                )
                NovaSettingsRow(
                    icon = Icons.Rounded.Language,
                    title = "Language",
                    subtitle = appState.language.description,
                    value = appState.language.displayName,
                    iconTint = colors.lagoon,
                    onClick = { showLangPicker = true }
                )
            }

            // Card 3: Voice & Audio
            NovaGlassCard(modifier = Modifier.fillMaxWidth(), elevation = 4.dp) {
                NovaSectionHeader("Voice & Audio")
                NovaSettingsRow(
                    icon = Icons.Rounded.GraphicEq,
                    title = "Voice & Identity",
                    value = appState.voiceName,
                    onClick = onOpenProfile
                )
                Spacer(Modifier.height(NovaSpacing.xs))
                Text(
                    text = "Speech Speed • ${String.format(Locale.US, "%.2fx", appState.speechSpeed)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                Slider(
                    value = appState.speechSpeed,
                    onValueChange = { appState.applySpeechSpeed(it) },
                    valueRange = 0.7f..1.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = colors.accent,
                        activeTrackColor = colors.accent
                    )
                )
                Text(
                    text = "Voice Volume • ${(appState.voiceVolume * 100).toInt()}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
                Slider(
                    value = appState.voiceVolume,
                    onValueChange = { appState.applyVoiceVolume(it) },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = colors.lagoon,
                        activeTrackColor = colors.lagoon
                    )
                )
            }

            // Card 4: Appearance & 3D
            NovaGlassCard(modifier = Modifier.fillMaxWidth(), elevation = 3.dp) {
                NovaSectionHeader("Appearance & 3D")
                NovaSettingsRow(
                    icon = Icons.Rounded.AutoAwesome,
                    title = "Orb Style",
                    subtitle = appState.orbStyle.description,
                    value = appState.orbStyle.displayName,
                    onClick = onOpenOrbStyle
                )
                NovaSettingsRow(
                    icon = Icons.Rounded.Contrast,
                    title = "Theme",
                    value = appState.themeMode.displayName,
                    onClick = { showThemePicker = true }
                )
                NovaSettingsRow(
                    icon = Icons.Rounded.MotionPhotosOff,
                    title = "Reduced Motion",
                    subtitle = "Disables parallax and continuous shader motion",
                    checked = appState.reducedMotion,
                    onCheckedChange = { appState.applyReducedMotion(it) }
                )
            }

            // Card 5: System, Flavor Capabilities & Diagnostics
            NovaGlassCard(modifier = Modifier.fillMaxWidth(), elevation = 2.dp) {
                NovaSectionHeader("System & Diagnostics")
                AccessibilitySettingsRows(onOpenDisclosure = onOpenAccessibilityDisclosure)
                NovaSettingsRow(
                    icon = Icons.Rounded.Security,
                    title = "Permissions",
                    subtitle = "Microphone, notifications, contacts, calls",
                    iconTint = colors.lagoon,
                    onClick = onOpenPermissions
                )
                NovaSettingsRow(
                    icon = Icons.Rounded.Lock,
                    title = "Privacy & History",
                    subtitle = "On-device storage and chat clearing",
                    onClick = onOpenPrivacy
                )
                NovaSettingsRow(
                    icon = Icons.Rounded.BugReport,
                    title = "Voice Pipeline Debugger",
                    subtitle = "Live connection, VAD, language & latency telemetry",
                    iconTint = colors.lotus,
                    onClick = onOpenDebug
                )
                NovaSettingsRow(
                    icon = Icons.Rounded.Info,
                    title = "About ${appState.assistantName}",
                    onClick = onOpenAbout
                )
            }

            NovaButton(
                text = "Clear Chat History",
                style = NovaButtonStyle.TEXT,
                tintOverride = colors.error,
                onClick = { showClearConfirm = true },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(NovaSpacing.lg))
        }
    }

    if (showNameDialog) {
        AlertDialog(
            onDismissRequest = { showNameDialog = false },
            containerColor = colors.surfaceRaised,
            titleContentColor = colors.textPrimary,
            title = { Text("Rename Assistant", style = MaterialTheme.typography.titleLarge) },
            text = {
                NovaTextField(
                    value = draftAssistantName,
                    onValueChange = { draftAssistantName = it },
                    placeholder = "Assistant name (e.g., Lia)"
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        appState.applyAssistantName(draftAssistantName)
                        VoiceSessionManager.refreshInstructions(context)
                        showNameDialog = false
                    }
                ) {
                    Text("Save", color = colors.accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNameDialog = false }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            }
        )
    }

    if (showLangPicker) {
        NovaPickerDialog(
            title = "Language Preference",
            options = LanguagePreference.entries,
            selected = appState.language,
            labelOf = { it.displayName },
            descriptionOf = { it.description },
            onSelect = {
                appState.applyLanguage(it)
                VoiceSessionManager.refreshInstructions(context)
            },
            onDismiss = { showLangPicker = false }
        )
    }

    if (showThemePicker) {
        NovaPickerDialog(
            title = "Theme",
            options = ThemeMode.entries,
            selected = appState.themeMode,
            labelOf = { it.displayName },
            onSelect = { appState.applyThemeMode(it) },
            onDismiss = { showThemePicker = false }
        )
    }

    if (showClearConfirm) {
        NovaConfirmDialog(
            title = "Clear Chat History?",
            message = "This removes all saved typed conversations from this device.",
            confirmLabel = "Clear All",
            isDestructive = true,
            onConfirm = {
                appState.clearConversations()
                showClearConfirm = false
            },
            onDismiss = { showClearConfirm = false }
        )
    }
}
