package com.Lia.assistant.ui.fx

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

internal data class OrbPalette(
    val core: Color,
    val rim: Color,
    val halo: Color
)

@Composable
internal fun orbPaletteFor(state: NovaOrbState): OrbPalette {
    val colors = LocalNovaColors.current
    return when (state) {
        NovaOrbState.IDLE -> OrbPalette(
            core = Color(0xFF9F7AEA),
            rim = colors.lotus,
            halo = Color(0xFF3E2475)
        )
        NovaOrbState.LISTENING -> OrbPalette(
            core = colors.lagoon,
            rim = Color(0xFF8FF7ED),
            halo = Color(0xFF135C63)
        )
        NovaOrbState.THINKING -> OrbPalette(
            core = Color(0xFFA855F7),
            rim = colors.lagoon,
            halo = Color(0xFF4C1D95)
        )
        NovaOrbState.SPEAKING -> OrbPalette(
            core = colors.accent,
            rim = colors.lotus,
            halo = colors.accentSecondary
        )
        NovaOrbState.CONNECTING -> OrbPalette(
            core = colors.warning,
            rim = Color(0xFFFFDF9E),
            halo = Color(0xFF7C4A03)
        )
        NovaOrbState.ERROR -> OrbPalette(
            core = colors.error,
            rim = Color(0xFFFFB4BC),
            halo = Color(0xFF5C1018)
        )
    }
}

private data class ArcherPoint(
    val x: Float,
    val y: Float,
    val z: Float
)

@Composable
fun NovaOrb(
    state: NovaOrbState,
    size: Dp,
    amplitude: Float = 0f,
    style: NovaOrbStyle = NovaOrbStyle.NOVA,
    assistantName: String = AssistantBrand.NAME,
    modifier: Modifier = Modifier
) {
    val reducedMotion = LocalNovaReducedMotion.current
    val palette = orbPaletteFor(state)
    val transition = rememberInfiniteTransition(label = "nova_orb")

    val breathPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(4200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "breath"
    )

    val rotDurationMs = when (state) {
        NovaOrbState.THINKING -> 2600
        NovaOrbState.CONNECTING -> 1100
        else -> 9000
    }
    val rotationDeg by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(rotDurationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val ringPulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "listen_rings"
    )

    val archerPoints = remember {
        val count = 400
        val goldenAngle = PI * (3.0 - sqrt(5.0))
        List(count) { i ->
            val y = 1.0 - (i.toDouble() / (count - 1)) * 2.0
            val r = sqrt(1.0 - y * y)
            val theta = goldenAngle * i
            ArcherPoint(
                x = (cos(theta) * r).toFloat(),
                y = y.toFloat(),
                z = (sin(theta) * r).toFloat()
            )
        }
    }

    val safeAmp = amplitude.coerceIn(0f, 1f)
    val effectiveBreath = if (reducedMotion) 1f else 1f + 0.035f * sin(breathPhase)
    val effectiveRot = if (reducedMotion) 0f else rotationDeg
    val effectiveRing = if (reducedMotion) 0.4f else ringPulse

    Canvas(
        modifier = modifier
            .size(size)
            .semantics {
                contentDescription = "$assistantName status: ${state.label}"
            }
    ) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val baseRadius = (minOf(this.size.width, this.size.height) * 0.34f) *
            effectiveBreath * (1f + safeAmp * 0.14f)

        // Outer radial glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    palette.core.copy(alpha = 0.42f + safeAmp * 0.25f),
                    palette.halo.copy(alpha = 0.18f),
                    Color.Transparent
                ),
                center = Offset(cx, cy),
                radius = baseRadius * 1.95f
            ),
            radius = baseRadius * 1.95f,
            center = Offset(cx, cy)
        )

        if (style == NovaOrbStyle.ARCHER) {
            val yaw = Math.toRadians(effectiveRot.toDouble())
            val cosY = cos(yaw).toFloat()
            val sinY = sin(yaw).toFloat()
            for (i in archerPoints.indices) {
                val p = archerPoints[i]
                val rx = p.x * cosY - p.z * sinY
                val rz = p.x * sinY + p.z * cosY
                val depth = ((rz + 1f) * 0.5f).coerceIn(0f, 1f)
                val jitter = if (safeAmp > 0.02f && !reducedMotion) {
                    1f + safeAmp * 0.18f * sin(i * 0.37f + breathPhase)
                } else 1f
                val px = cx + rx * baseRadius * 1.05f * jitter
                val py = cy + p.y * baseRadius * 1.05f * jitter
                val dotRadius = (1.1.dp.toPx() + depth * 1.8.dp.toPx())
                val dotColor = if (depth > 0.55f) palette.rim else palette.core
                drawCircle(
                    color = dotColor.copy(alpha = 0.2f + depth * 0.78f),
                    radius = dotRadius,
                    center = Offset(px, py)
                )
            }
            return@Canvas
        }

        // Listening expanding rings
        if (state == NovaOrbState.LISTENING) {
            for (ringIdx in 0..1) {
                val phase = (effectiveRing + ringIdx * 0.5f) % 1f
                val r = baseRadius * (1.05f + phase * 0.65f)
                val alpha = (1f - phase) * 0.45f
                drawCircle(
                    color = palette.rim.copy(alpha = alpha),
                    radius = r,
                    center = Offset(cx, cy),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }

        // Error pulse ring
        if (state == NovaOrbState.ERROR) {
            val pulseAlpha = 0.35f + 0.35f * (1f - effectiveRing)
            drawCircle(
                color = palette.core.copy(alpha = pulseAlpha),
                radius = baseRadius * 1.24f,
                center = Offset(cx, cy),
                style = Stroke(width = 2.5.dp.toPx())
            )
        }

        // Connecting rotating 100-degree arc
        if (state == NovaOrbState.CONNECTING) {
            val arcRadius = baseRadius * 1.28f
            drawArc(
                color = palette.rim,
                startAngle = effectiveRot,
                sweepAngle = 100f,
                useCenter = false,
                topLeft = Offset(cx - arcRadius, cy - arcRadius),
                size = Size(arcRadius * 2f, arcRadius * 2f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        // Radial-gradient core
        val coreHighlight = if (style == NovaOrbStyle.GLASS) {
            Color.White.copy(alpha = 0.92f)
        } else {
            Color.White.copy(alpha = 0.78f)
        }
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    coreHighlight,
                    palette.core,
                    palette.rim.copy(alpha = if (style == NovaOrbStyle.AURORA) 0.9f else 0.75f),
                    palette.halo.copy(alpha = 0.35f)
                ),
                center = Offset(cx - baseRadius * 0.24f, cy - baseRadius * 0.26f),
                radius = baseRadius * 1.3f
            ),
            radius = baseRadius,
            center = Offset(cx, cy)
        )

        // Glass specular highlight arc
        if (style == NovaOrbStyle.GLASS) {
            val specRadius = baseRadius * 0.76f
            drawArc(
                color = Color.White.copy(alpha = 0.75f),
                startAngle = 210f,
                sweepAngle = 72f,
                useCenter = false,
                topLeft = Offset(cx - specRadius, cy - specRadius),
                size = Size(specRadius * 2f, specRadius * 2f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        // Orbiting particles
        val particleCount = when {
            style == NovaOrbStyle.MINIMAL || state == NovaOrbState.ERROR -> 0
            style == NovaOrbStyle.ENERGY -> 8
            style == NovaOrbStyle.PLASMA -> 6
            style == NovaOrbStyle.GLASS -> 3
            else -> 5
        }
        for (i in 0 until particleCount) {
            val angleDeg = effectiveRot + i * (360f / particleCount)
            val rad = Math.toRadians(angleDeg.toDouble())
            val orbitR = baseRadius * (1.22f + (i % 2) * 0.14f)
            val px = cx + (cos(rad) * orbitR).toFloat()
            val py = cy + (sin(rad) * orbitR * 0.86).toFloat()
            drawCircle(
                color = if (i % 2 == 0) palette.rim else Color.White.copy(alpha = 0.85f),
                radius = (2.4f + (i % 3) * 0.8f).dp.toPx(),
                center = Offset(px, py)
            )
        }
    }
}
