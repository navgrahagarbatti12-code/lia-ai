package com.Lia.assistant.voice

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.Base64
import java.util.concurrent.TimeUnit

class GeminiLiveClient(
    private val apiKey: String,
    private val listener: Listener
) {
    interface Listener {
        fun onSetupComplete()
        fun onAudioChunk(bytes: ByteArray)
        fun onInputTranscript(text: String)
        fun onOutputTranscript(text: String)
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onTurnComplete()
        fun onInterrupted()
        fun onError(message: String)
        fun onClosed()
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .connectTimeout(20, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val deduplicator = ToolCallDeduplicator()

    @Volatile
    private var webSocket: WebSocket? = null

    @Volatile
    private var closedByClient = false

    fun connect(systemInstruction: String, voiceName: String = "Aoede") {
        val cleanKey = apiKey.trim()
        if (cleanKey.isEmpty()) {
            listener.onError("Missing Gemini API key.")
            return
        }

        closedByClient = false
        deduplicator.clear()

        val request = Request.Builder()
            .url("$WS_URL_BASE?key=$cleanKey")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val setupPayload = buildSetupPayload(systemInstruction, voiceName)
                webSocket.send(setupPayload.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleIncomingFrame(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                handleIncomingFrame(bytes.utf8())
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                this@GeminiLiveClient.webSocket = null
                listener.onClosed()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                this@GeminiLiveClient.webSocket = null
                if (!closedByClient) {
                    val codeInfo = response?.code?.let { " (HTTP $it)" }.orEmpty()
                    listener.onError((t.message ?: "Voice connection error") + codeInfo)
                }
            }
        })
    }

    fun sendAudio(pcmBytes: ByteArray) {
        val ws = webSocket ?: return
        if (pcmBytes.isEmpty()) return
        val encoded = Base64.getEncoder().encodeToString(pcmBytes)
        val payload = JSONObject().put(
            "realtimeInput",
            JSONObject().put(
                "audio",
                JSONObject()
                    .put("mimeType", "audio/pcm;rate=16000")
                    .put("data", encoded)
            )
        )
        ws.send(payload.toString())
    }

    fun sendToolResponse(id: String, name: String, resultJson: JSONObject) {
        val ws = webSocket ?: return
        val fnResponse = JSONObject()
            .put("id", id)
            .put("name", name)
            .put("response", resultJson)
        val payload = JSONObject().put(
            "toolResponse",
            JSONObject().put(
                "functionResponses",
                JSONArray().put(fnResponse)
            )
        )
        ws.send(payload.toString())
    }

    fun disconnect() {
        closedByClient = true
        val ws = webSocket
        webSocket = null
        ws?.close(1000, "Client disconnect")
    }

    internal fun buildSetupPayload(systemInstruction: String, voiceName: String): JSONObject {
        val speechConfig = JSONObject().put(
            "voiceConfig",
            JSONObject().put(
                "prebuiltVoiceConfig",
                JSONObject().put("voiceName", voiceName.ifBlank { "Aoede" })
            )
        )
        val generationConfig = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put("speechConfig", speechConfig)

        val sysInstructionObj = JSONObject().put(
            "parts",
            JSONArray().put(JSONObject().put("text", systemInstruction))
        )

        val setup = JSONObject()
            .put("model", MODEL)
            .put("generationConfig", generationConfig)
            .put("systemInstruction", sysInstructionObj)
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())

        val declarations = LiaToolCatalog.declarations()
        if (declarations.length() > 0) {
            setup.put(
                "tools",
                JSONArray().put(JSONObject().put("functionDeclarations", declarations))
            )
        }

        return JSONObject().put("setup", setup)
    }

    internal fun handleIncomingFrame(rawText: String) {
        val root = runCatching { JSONObject(rawText) }.getOrNull() ?: return

        // Silently ignore session lifecycle housekeeping frames.
        if (root.has("sessionResumptionUpdate") || root.has("goAway")) {
            return
        }

        if (root.has("setupComplete")) {
            listener.onSetupComplete()
        }

        root.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) {
                val call = calls.optJSONObject(i) ?: continue
                val id = call.optString("id", "")
                val name = call.optString("name", "")
                val args = call.optJSONObject("args") ?: JSONObject()
                if (name.isNotEmpty() && deduplicator.shouldProcess(id)) {
                    listener.onToolCall(id, name, args)
                }
            }
        }

        root.optJSONObject("serverContent")?.let { content ->
            content.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val part = parts.optJSONObject(i) ?: continue
                    val inlineData = part.optJSONObject("inlineData") ?: continue
                    val mimeType = inlineData.optString("mimeType", "")
                    val b64 = inlineData.optString("data", "")
                    if (mimeType.startsWith("audio/pcm", ignoreCase = true) && b64.isNotEmpty()) {
                        val decoded = runCatching { Base64.getDecoder().decode(b64) }.getOrNull()
                        if (decoded != null && decoded.isNotEmpty()) {
                            listener.onAudioChunk(decoded)
                        }
                    }
                }
            }

            content.optJSONObject("inputTranscription")?.optString("text")?.let { text ->
                if (text.isNotBlank()) {
                    listener.onInputTranscript(text)
                }
            }

            content.optJSONObject("outputTranscription")?.optString("text")?.let { text ->
                if (text.isNotBlank()) {
                    listener.onOutputTranscript(text)
                }
            }

            if (content.optBoolean("interrupted", false)) {
                listener.onInterrupted()
            }

            if (content.optBoolean("turnComplete", false)) {
                listener.onTurnComplete()
            }
        }
    }

    companion object {
        const val MODEL = "models/gemini-3.1-flash-live-preview"
        private const val WS_URL_BASE =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
    }
}
