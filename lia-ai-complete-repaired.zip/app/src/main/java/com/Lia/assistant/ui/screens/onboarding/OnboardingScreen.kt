package com.Lia.assistant.ui.screens.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.fx.NovaOrbStyle
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import kotlinx.coroutines.launch

private data class OnboardingPageData(
    val title: String,
    val body: String,
    val orbState: NovaOrbState,
    val orbStyle: NovaOrbStyle
)

@Composable
fun OnboardingScreen(
    appState: NovaAppState,
    onComplete: () -> Unit
) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val name = appState.assistantName
    val pagerState = rememberPagerState(pageCount = { 4 })
    val scope = rememberCoroutineScope()

    val pages = listOf(
        OnboardingPageData(
            title = "Meet $name",
            body = "A real-time Gemini voice companion designed like a pearl of light in the night.",
            orbState = NovaOrbState.IDLE,
            orbStyle = NovaOrbStyle.NOVA
        ),
        OnboardingPageData(
            title = "Hindi, Hinglish & English",
            body = "Speak naturally in Hindi, Hinglish, or English—switch mid-sentence with 10 lively personalities.",
            orbState = NovaOrbState.LISTENING,
            orbStyle = NovaOrbStyle.AURORA
        ),
        OnboardingPageData(
            title = "3D Website Forge",
            body = "Say \"ek cafe ki website banao\" and watch a live 3D website materialize before your eyes.",
            orbState = NovaOrbState.SPEAKING,
            orbStyle = NovaOrbStyle.ARCHER
        ),
        OnboardingPageData(
            title = "Private & On Your Terms",
            body = "Your Gemini API key stays strictly on this device, and you can customize or pause anytime.",
            orbState = NovaOrbState.THINKING,
            orbStyle = NovaOrbStyle.GLASS
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(NovaSpacing.xl)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            NovaButton(
                text = "Skip",
                style = NovaButtonStyle.TEXT,
                onClick = {
                    appState.applyHasOnboarded(true)
                    onComplete()
                },
                testTag = "onboarding_skip"
            )
        }

        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) { pageIndex ->
            val page = pages[pageIndex]
            val pageOffset = (pagerState.currentPage - pageIndex) + pagerState.currentPageOffsetFraction
            val parallaxPx = if (reducedMotion) 0f else pageOffset * 90f

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = NovaSpacing.md),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Different 3D orb pose per page
                Box(
                    modifier = Modifier.graphicsLayer {
                        translationX = if (reducedMotion) 0f else -pageOffset * 36f
                        when (pageIndex) {
                            1 -> translationY = -12f
                            2 -> scaleX = 1.06f
                            3 -> rotationZ = if (reducedMotion) 0f else 8f
                        }
                    },
                    contentAlignment = Alignment.Center
                ) {
                    LiaOrb3D(
                        state = page.orbState,
                        size = 200.dp,
                        amplitude = if (pageIndex == 2) 0.55f else 0.18f,
                        style = page.orbStyle,
                        assistantName = name
                    )
                }

                Spacer(Modifier.height(NovaSpacing.xxl))

                Column(
                    modifier = Modifier.graphicsLayer {
                        translationX = parallaxPx * 0.6f
                    },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = page.title,
                        style = MaterialTheme.typography.displayMedium,
                        color = colors.textPrimary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(NovaSpacing.md))
                    Text(
                        text = page.body,
                        style = MaterialTheme.typography.bodyLarge,
                        color = colors.textSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Page indicator dots
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = NovaSpacing.lg),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(pages.size) { idx ->
                val active = pagerState.currentPage == idx
                Box(
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .size(width = if (active) 22.dp else 8.dp, height = 8.dp)
                        .clip(CircleShape)
                        .background(if (active) colors.accent else colors.surfaceBorder)
                )
            }
        }

        val isLast = pagerState.currentPage == pages.lastIndex
        NovaButton(
            text = if (isLast) "Start Talking with $name" else "Continue",
            onClick = {
                if (isLast) {
                    appState.applyHasOnboarded(true)
                    onComplete()
                } else {
                    scope.launch {
                        pagerState.animateScrollToPage(pagerState.currentPage + 1)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            testTag = "onboarding_primary"
        )
    }
}
