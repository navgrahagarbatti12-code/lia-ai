package com.Lia.assistant.voice

import org.json.JSONArray
import org.json.JSONObject

fun functionDecl(
    name: String,
    description: String,
    params: Map<String, String> = emptyMap(),
    required: List<String> = emptyList()
): JSONObject {
    val properties = JSONObject()
    for ((paramName, paramDesc) in params) {
        properties.put(
            paramName,
            JSONObject()
                .put("type", "STRING")
                .put("description", paramDesc)
        )
    }

    val parameters = JSONObject()
        .put("type", "OBJECT")
        .put("properties", properties)

    if (required.isNotEmpty()) {
        parameters.put("required", JSONArray(required))
    }

    return JSONObject()
        .put("name", name)
        .put("description", description)
        .put("parameters", parameters)
}
