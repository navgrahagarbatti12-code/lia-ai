package com.Lia.assistant.voice

class ToolCallDeduplicator(private val maxSize: Int = 256) {
    private val lock = Any()
    private val seenIds = LinkedHashSet<String>()

    /**
     * Returns true if [callId] has not been seen yet (and records it),
     * or false if [callId] is a duplicate.
     */
    fun shouldProcess(callId: String): Boolean {
        val clean = callId.trim()
        if (clean.isEmpty()) return true
        synchronized(lock) {
            if (seenIds.contains(clean)) return false
            if (seenIds.size >= maxSize) {
                val iterator = seenIds.iterator()
                if (iterator.hasNext()) {
                    iterator.next()
                    iterator.remove()
                }
            }
            seenIds.add(clean)
            return true
        }
    }

    fun clear() {
        synchronized(lock) {
            seenIds.clear()
        }
    }
}
