package com.Lia.assistant.forge

import androidx.core.content.FileProvider

class ForgeFileProvider : FileProvider()
