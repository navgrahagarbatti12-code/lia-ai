package com.Lia.assistant.action

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import kotlin.math.abs

object AppLauncher {
    private val WORD_SPLIT = Regex("\\s+")

    sealed class LaunchResult {
        data class Launched(val packageName: String) : LaunchResult()
        data class NotFound(val query: String) : LaunchResult()
        data class Failed(val reason: String) : LaunchResult()
    }

    fun findApp(query: String, labelToPackage: Map<String, String>): String? {
        val normalizedQuery = query.trim().lowercase()
        if (normalizedQuery.isEmpty() || labelToPackage.isEmpty()) return null

        // 1. Exact label match first
        labelToPackage[normalizedQuery]?.let { return it }

        // 2. Prefix / word-prefix match (only keys >= 3 chars, never loose substring matching)
        val queryWords = normalizedQuery.split(WORD_SPLIT).filter { it.isNotEmpty() }
        val candidates = labelToPackage.entries.filter { (key, _) ->
            if (key.length < 3) return@filter false
            if (key.startsWith(normalizedQuery) || normalizedQuery.startsWith(key)) {
                return@filter true
            }
            val keyWords = key.split(WORD_SPLIT).filter { it.isNotEmpty() }
            queryWords.isNotEmpty() && queryWords.all { qw ->
                keyWords.any { kw -> kw.startsWith(qw) }
            }
        }

        if (candidates.isEmpty()) return null

        return candidates.minWithOrNull(
            compareBy<Map.Entry<String, String>> { abs(it.key.length - normalizedQuery.length) }
                .thenBy { it.key }
        )?.value
    }

    suspend fun findAndLaunch(context: Context, appName: String): LaunchResult {
        val map = InstalledAppLabelCache.get(context)
        val pkg = findApp(appName, map) ?: return LaunchResult.NotFound(appName)
        return launch(context, pkg)
    }

    fun launch(context: Context, packageName: String): LaunchResult {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return LaunchResult.NotFound(packageName)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            LaunchResult.Launched(packageName)
        } catch (e: ActivityNotFoundException) {
            LaunchResult.Failed("Activity not found")
        } catch (e: SecurityException) {
            LaunchResult.Failed("Permission denied to launch app")
        }
    }
}
