package com.Lia.assistant.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class NovaColorScheme(
    val background: Color,
    val backgroundGradientTop: Color,
    val surface: Color,
    val surfaceGlass: Color,
    val surfaceBorder: Color,
    val surfaceRaised: Color,
    val accent: Color,
    val accentSecondary: Color,
    val accentGlow: Color,
    val onAccent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val userBubble: Color,
    val assistantBubble: Color,
    val depthShadow: Color,
    val rimLight: Color,
    val lagoon: Color,
    val lotus: Color
)

val DarkNovaColors = NovaColorScheme(
    background = Color(0xFF06050E),
    backgroundGradientTop = Color(0xFF15113A),
    surface = Color(0xFF17143A),
    surfaceGlass = Color(0xBF17143A),
    surfaceBorder = Color(0x38EEE9FF),
    surfaceRaised = Color(0xFF221E4D),
    accent = Color(0xFFFFB547),
    accentSecondary = Color(0xFFFF8A3D),
    accentGlow = Color(0x55FFB547),
    onAccent = Color(0xFF1B1000),
    textPrimary = Color(0xFFEEE9FF),
    textSecondary = Color(0xFFA7A0CC),
    textTertiary = Color(0xFF726B99),
    success = Color(0xFF3FE0D0),
    warning = Color(0xFFFFB547),
    error = Color(0xFFFF7A85),
    userBubble = Color(0xFF2D2246),
    assistantBubble = Color(0xCC17143A),
    depthShadow = Color(0x9904030B),
    rimLight = Color(0x52FFF5E0),
    lagoon = Color(0xFF3FE0D0),
    lotus = Color(0xFFFF6FAE)
)

val LightNovaColors = NovaColorScheme(
    background = Color(0xFFF3F0FB),
    backgroundGradientTop = Color(0xFFE3DBF8),
    surface = Color(0xFFFFFFFF),
    surfaceGlass = Color(0xDEFFFFFF),
    surfaceBorder = Color(0x2815112E),
    surfaceRaised = Color(0xFFFAF7FF),
    accent = Color(0xFFB86A00),
    accentSecondary = Color(0xFFD97706),
    accentGlow = Color(0x33B86A00),
    onAccent = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF15112E),
    textSecondary = Color(0xFF4B4470),
    textTertiary = Color(0xFF746C99),
    success = Color(0xFF0D8F82),
    warning = Color(0xFFB86A00),
    error = Color(0xFFC62839),
    userBubble = Color(0xFFFFF1DA),
    assistantBubble = Color(0xEBFFFFFF),
    depthShadow = Color(0x2915112E),
    rimLight = Color(0xDDFFFFFF),
    lagoon = Color(0xFF14B8A6),
    lotus = Color(0xFFE0488B)
)

object NovaSpacing {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
    val xxxl = 48.dp
}

object NovaShapes {
    val small = RoundedCornerShape(12.dp)
    val medium = RoundedCornerShape(20.dp)
    val large = RoundedCornerShape(28.dp)
    val pill = RoundedCornerShape(50)
}

object NovaMotion {
    const val FAST_MS = 150
    const val NORMAL_MS = 300
    const val SLOW_MS = 500
}
