package com.Lia.assistant.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaShapes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.depthSurface
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class NovaButtonStyle {
    PRIMARY,
    SECONDARY,
    TEXT
}

@Composable
fun NovaGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = NovaShapes.medium,
    elevation: Dp = 8.dp,
    borderColor: Color? = null,
    backgroundColor: Color? = null,
    onClick: (() -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(NovaSpacing.lg),
    content: @Composable ColumnScope.() -> Unit
) {
    val reducedMotion = LocalNovaReducedMotion.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (!reducedMotion && pressed && onClick != null) 0.96f else 1f,
        animationSpec = tween(NovaMotion.FAST_MS),
        label = "card_press_scale"
    )

    val cardMod = modifier
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .depthSurface(
            shape = shape,
            elevation = elevation,
            backgroundColor = backgroundColor,
            borderColor = borderColor
        )
        .let { base ->
            if (onClick != null) {
                base.clickable(
                    interactionSource = interaction,
                    indication = androidx.compose.material3.ripple(),
                    onClick = onClick
                )
            } else {
                base
            }
        }
        .padding(contentPadding)

    Column(modifier = cardMod, content = content)
}

@Composable
fun NovaButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: NovaButtonStyle = NovaButtonStyle.PRIMARY,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    tintOverride: Color? = null,
    testTag: String? = null
) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (!reducedMotion && pressed && enabled) 0.96f else 1f,
        animationSpec = tween(NovaMotion.FAST_MS),
        label = "button_press_scale"
    )

    val taggedMod = if (testTag != null) modifier.testTag(testTag) else modifier

    val wrappedClick = {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        onClick()
    }

    when (style) {
        NovaButtonStyle.PRIMARY -> {
            val container = tintOverride ?: colors.accent
            Button(
                onClick = wrappedClick,
                enabled = enabled,
                interactionSource = interaction,
                shape = NovaShapes.pill,
                colors = ButtonDefaults.buttonColors(
                    containerColor = container,
                    contentColor = colors.onAccent,
                    disabledContainerColor = container.copy(alpha = 0.35f),
                    disabledContentColor = colors.onAccent.copy(alpha = 0.5f)
                ),
                contentPadding = PaddingValues(horizontal = NovaSpacing.xl, vertical = NovaSpacing.md),
                modifier = taggedMod
                    .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    }
            ) {
                if (icon != null) {
                    Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(NovaSpacing.sm))
                }
                Text(
                    text = text,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        NovaButtonStyle.SECONDARY -> {
            Box(
                modifier = taggedMod
                    .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    }
                    .depthSurface(
                        shape = NovaShapes.pill,
                        elevation = 6.dp,
                        backgroundColor = colors.surfaceRaised.copy(alpha = 0.85f),
                        borderColor = tintOverride?.copy(alpha = 0.55f) ?: colors.surfaceBorder
                    )
                    .clickable(
                        enabled = enabled,
                        interactionSource = interaction,
                        indication = androidx.compose.material3.ripple(),
                        onClick = wrappedClick
                    )
                    .padding(horizontal = NovaSpacing.xl, vertical = NovaSpacing.md),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (icon != null) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = tintOverride ?: colors.textPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(NovaSpacing.sm))
                    }
                    Text(
                        text = text,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (enabled) (tintOverride ?: colors.textPrimary) else colors.textTertiary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        NovaButtonStyle.TEXT -> {
            TextButton(
                onClick = wrappedClick,
                enabled = enabled,
                interactionSource = interaction,
                modifier = taggedMod
                    .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    }
            ) {
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = tintOverride ?: colors.accent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(NovaSpacing.xs))
                }
                Text(
                    text = text,
                    style = MaterialTheme.typography.labelLarge,
                    color = tintOverride ?: colors.accent
                )
            }
        }
    }
}

@Composable
fun NovaTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    label: String? = null,
    singleLine: Boolean = true,
    maxLines: Int = if (singleLine) 1 else 4,
    leadingIcon: ImageVector? = null,
    trailingContent: (@Composable () -> Unit)? = null,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    testTag: String? = null
) {
    val colors = LocalNovaColors.current
    val mod = if (testTag != null) modifier.testTag(testTag) else modifier

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = mod.fillMaxWidth(),
        singleLine = singleLine,
        maxLines = maxLines,
        label = label?.let { { Text(it, style = MaterialTheme.typography.bodySmall) } },
        placeholder = {
            Text(
                text = placeholder,
                style = MaterialTheme.typography.bodyLarge,
                color = colors.textTertiary
            )
        },
        leadingIcon = leadingIcon?.let {
            { Icon(imageVector = it, contentDescription = null, tint = colors.textSecondary) }
        },
        trailingIcon = trailingContent,
        visualTransformation = visualTransformation,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        shape = NovaShapes.medium,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = colors.textPrimary,
            unfocusedTextColor = colors.textPrimary,
            focusedContainerColor = colors.surfaceGlass,
            unfocusedContainerColor = colors.surfaceGlass,
            focusedBorderColor = colors.accent,
            unfocusedBorderColor = colors.surfaceBorder,
            cursorColor = colors.accent
        ),
        textStyle = MaterialTheme.typography.bodyLarge
    )
}

@Composable
fun NovaTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    actions: @Composable () -> Unit = {}
) {
    val colors = LocalNovaColors.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(48.dp)
                    .depthSurface(shape = CircleShape, elevation = 4.dp)
                    .testTag("top_bar_back")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = colors.textPrimary
                )
            }
            Spacer(Modifier.width(NovaSpacing.md))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        actions()
    }
}

@Composable
fun NovaSectionHeader(
    title: String,
    modifier: Modifier = Modifier
) {
    val colors = LocalNovaColors.current
    Text(
        text = title.uppercase(),
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
        color = colors.accent,
        modifier = modifier.padding(horizontal = NovaSpacing.xs, vertical = NovaSpacing.xs)
    )
}

@Composable
fun NovaSettingsRow(
    icon: ImageVector,
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    value: String? = null,
    checked: Boolean? = null,
    onCheckedChange: ((Boolean) -> Unit)? = null,
    iconTint: Color? = null,
    onClick: (() -> Unit)? = null
) {
    val colors = LocalNovaColors.current
    val resolvedTint = iconTint ?: colors.accent
    val rowClick = onClick ?: if (checked != null && onCheckedChange != null) {
        { onCheckedChange(!checked) }
    } else null

    Row(
        modifier = modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 56.dp)
            .clip(NovaShapes.small)
            .let { base ->
                if (rowClick != null) base.clickable(onClick = rowClick) else base
            }
            .padding(horizontal = NovaSpacing.sm, vertical = NovaSpacing.sm),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(resolvedTint.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = resolvedTint,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(Modifier.width(NovaSpacing.md))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (!value.isNullOrBlank()) {
            Spacer(Modifier.width(NovaSpacing.sm))
            Text(
                text = value,
                style = MaterialTheme.typography.labelLarge,
                color = colors.accent,
                maxLines = 1
            )
        }
        if (checked != null && onCheckedChange != null) {
            Spacer(Modifier.width(NovaSpacing.sm))
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = colors.onAccent,
                    checkedTrackColor = colors.accent,
                    uncheckedThumbColor = colors.textSecondary,
                    uncheckedTrackColor = colors.surfaceRaised
                )
            )
        } else if (rowClick != null) {
            Spacer(Modifier.width(NovaSpacing.xs))
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = null,
                tint = colors.textTertiary
            )
        }
    }
}

@Composable
fun NovaEmptyState(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    val colors = LocalNovaColors.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(NovaSpacing.xl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .depthSurface(shape = CircleShape, elevation = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = colors.accent,
                modifier = Modifier.size(32.dp)
            )
        }
        Spacer(Modifier.height(NovaSpacing.lg))
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            color = colors.textPrimary
        )
        Spacer(Modifier.height(NovaSpacing.sm))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyLarge,
            color = colors.textSecondary
        )
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(NovaSpacing.xl))
            NovaButton(text = actionLabel, onClick = onAction)
        }
    }
}

@Composable
fun NovaVoiceVisualizer(
    amplitude: Float,
    active: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 48
) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val transition = rememberInfiniteTransition(label = "voice_ring")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_phase"
    )
    val effectivePhase = if (reducedMotion) 0f else phase
    val amp = if (active) amplitude.coerceIn(0.05f, 1f) else 0f

    Canvas(
        modifier = modifier.semantics {
            contentDescription = if (active) "Voice activity ring" else "Voice ring idle"
        }
    ) {
        if (!active && reducedMotion) return@Canvas
        val cx = size.width / 2f
        val cy = size.height / 2f
        val baseRadius = (minOf(size.width, size.height) / 2f) * 0.84f
        val maxBarLen = (minOf(size.width, size.height) / 2f) * 0.14f

        for (i in 0 until barCount) {
            val angle = (2.0 * PI * i / barCount).toFloat()
            val wave = 0.45f + 0.55f * sin(angle * 4f + effectivePhase)
            val barLen = if (active) {
                (4.dp.toPx() + maxBarLen * amp * wave)
            } else {
                2.dp.toPx()
            }
            val r0 = baseRadius
            val r1 = baseRadius + barLen
            val cosA = cos(angle)
            val sinA = sin(angle)
            val barColor = if (i % 2 == 0) colors.accent else colors.lotus
            drawLine(
                color = barColor.copy(alpha = if (active) 0.85f else 0.25f),
                start = Offset(cx + cosA * r0, cy + sinA * r0),
                end = Offset(cx + cosA * r1, cy + sinA * r1),
                strokeWidth = 2.5.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun NovaTypingDots(modifier: Modifier = Modifier) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val transition = rememberInfiniteTransition(label = "typing_dots")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "dot_cycle"
    )

    Row(
        modifier = modifier.semantics { contentDescription = "Typing" },
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0..2) {
            val alpha = if (reducedMotion) {
                0.7f
            } else {
                val dist = kotlin.math.abs(progress - i.toFloat()).coerceAtMost(1f)
                0.35f + (1f - dist) * 0.65f
            }
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(colors.accent.copy(alpha = alpha))
            )
        }
    }
}

@Composable
fun NovaConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    isDestructive: Boolean = false
) {
    val colors = LocalNovaColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surfaceRaised,
        titleContentColor = colors.textPrimary,
        textContentColor = colors.textSecondary,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = { Text(message, style = MaterialTheme.typography.bodyLarge) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(
                    text = confirmLabel,
                    color = if (isDestructive) colors.error else colors.accent,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = colors.textSecondary, style = MaterialTheme.typography.labelLarge)
            }
        }
    )
}

@Composable
fun <T> NovaPickerDialog(
    title: String,
    options: List<T>,
    selected: T,
    labelOf: (T) -> String,
    descriptionOf: (T) -> String? = { null },
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = LocalNovaColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surfaceRaised,
        titleContentColor = colors.textPrimary,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(NovaSpacing.xs)) {
                options.forEach { option ->
                    val isSelected = option == selected
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 48.dp)
                            .clip(NovaShapes.small)
                            .background(
                                if (isSelected) colors.accent.copy(alpha = 0.16f)
                                else Color.Transparent
                            )
                            .clickable {
                                onSelect(option)
                                onDismiss()
                            }
                            .padding(horizontal = NovaSpacing.md, vertical = NovaSpacing.sm),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = labelOf(option),
                                style = MaterialTheme.typography.titleMedium,
                                color = if (isSelected) colors.accent else colors.textPrimary
                            )
                            descriptionOf(option)?.let { desc ->
                                Text(
                                    text = desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.textSecondary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = colors.accent)
            }
        }
    )
}
