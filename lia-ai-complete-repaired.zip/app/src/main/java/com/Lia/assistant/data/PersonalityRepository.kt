package com.Lia.assistant.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.Lia.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.assistantSettingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "assistant_settings"
)

object PersonalityRepository {
    private val KEY_PERSONALITY = stringPreferencesKey("personality")
    private val KEY_LANGUAGE = stringPreferencesKey("language")
    private val KEY_ASSISTANT_NAME = stringPreferencesKey("assistant_name")
    private val KEY_VOICE_NAME = stringPreferencesKey("voice_name")

    const val DEFAULT_VOICE_NAME = "Aoede"

    internal fun personalityFrom(prefs: Preferences, context: Context): Personality {
        val raw = prefs[KEY_PERSONALITY]
            ?: NovaPreferences.getString(context, NovaPreferences.Keys.PERSONALITY, Personality.NORMAL.name)
        return Personality.fromStored(raw)
    }

    internal fun languageFrom(prefs: Preferences, context: Context): LanguagePreference {
        val raw = prefs[KEY_LANGUAGE]
            ?: NovaPreferences.getString(context, NovaPreferences.Keys.LANGUAGE, LanguagePreference.AUTO.name)
        return LanguagePreference.fromStored(raw)
    }

    internal fun assistantNameFrom(prefs: Preferences, context: Context): String {
        val raw = prefs[KEY_ASSISTANT_NAME]
            ?: NovaPreferences.getString(context, NovaPreferences.Keys.ASSISTANT_NAME, AssistantBrand.NAME)
        return raw.trim().ifBlank { AssistantBrand.NAME }
    }

    internal fun voiceNameFrom(prefs: Preferences, context: Context): String {
        val raw = prefs[KEY_VOICE_NAME]
            ?: NovaPreferences.getString(context, NovaPreferences.Keys.VOICE_NAME, DEFAULT_VOICE_NAME)
        return raw.trim().ifBlank { DEFAULT_VOICE_NAME }
    }

    fun personalityFlow(context: Context): Flow<Personality> =
        context.applicationContext.assistantSettingsDataStore.data.map { prefs ->
            personalityFrom(prefs, context)
        }

    fun languageFlow(context: Context): Flow<LanguagePreference> =
        context.applicationContext.assistantSettingsDataStore.data.map { prefs ->
            languageFrom(prefs, context)
        }

    fun assistantNameFlow(context: Context): Flow<String> =
        context.applicationContext.assistantSettingsDataStore.data.map { prefs ->
            assistantNameFrom(prefs, context)
        }

    fun voiceNameFlow(context: Context): Flow<String> =
        context.applicationContext.assistantSettingsDataStore.data.map { prefs ->
            voiceNameFrom(prefs, context)
        }

    suspend fun getPersonality(context: Context): Personality =
        personalityFlow(context).first()

    suspend fun getLanguage(context: Context): LanguagePreference =
        languageFlow(context).first()

    suspend fun getAssistantName(context: Context): String =
        assistantNameFlow(context).first()

    suspend fun getVoiceName(context: Context): String =
        voiceNameFlow(context).first()

    suspend fun setPersonality(context: Context, personality: Personality) {
        val appCtx = context.applicationContext
        appCtx.assistantSettingsDataStore.edit { it[KEY_PERSONALITY] = personality.name }
        NovaPreferences.putString(appCtx, NovaPreferences.Keys.PERSONALITY, personality.name)
        VoiceSessionManager.refreshInstructions(appCtx)
    }

    suspend fun setLanguage(context: Context, language: LanguagePreference) {
        val appCtx = context.applicationContext
        appCtx.assistantSettingsDataStore.edit { it[KEY_LANGUAGE] = language.name }
        NovaPreferences.putString(appCtx, NovaPreferences.Keys.LANGUAGE, language.name)
        VoiceSessionManager.refreshInstructions(appCtx)
    }

    suspend fun setAssistantName(context: Context, name: String) {
        val clean = name.trim().ifBlank { AssistantBrand.NAME }
        val appCtx = context.applicationContext
        appCtx.assistantSettingsDataStore.edit { it[KEY_ASSISTANT_NAME] = clean }
        NovaPreferences.putString(appCtx, NovaPreferences.Keys.ASSISTANT_NAME, clean)
        VoiceSessionManager.refreshInstructions(appCtx)
    }

    suspend fun setVoiceName(context: Context, voiceName: String) {
        val clean = voiceName.trim().ifBlank { DEFAULT_VOICE_NAME }
        val appCtx = context.applicationContext
        appCtx.assistantSettingsDataStore.edit { it[KEY_VOICE_NAME] = clean }
        NovaPreferences.putString(appCtx, NovaPreferences.Keys.VOICE_NAME, clean)
        VoiceSessionManager.refreshInstructions(appCtx)
    }
}
