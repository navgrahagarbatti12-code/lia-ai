package com.Lia.assistant.data

import android.content.Context
import android.content.SharedPreferences

object ApiKeyStore {
    private const val PREFS_NAME = "nova_prefs"
    private const val KEY_GEMINI_API = "gemini_api_key"

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getKey(context: Context): String =
        prefs(context).getString(KEY_GEMINI_API, "")?.trim().orEmpty()

    fun saveKey(context: Context, key: String) {
        val trimmed = key.trim()
        prefs(context).edit().putString(KEY_GEMINI_API, trimmed).apply()
    }

    fun hasKey(context: Context): Boolean = getKey(context).isNotBlank()
}
