package com.Lia.assistant.ui.screens.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.ChatTurnRecord
import com.Lia.assistant.data.ConversationRecord
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.forge.ForgeController
import com.Lia.assistant.forge.ForgeIntent
import com.Lia.assistant.forge.ForgeStartResult
import com.Lia.assistant.ui.components.ChatMessage
import com.Lia.assistant.ui.components.NovaEmptyState
import com.Lia.assistant.ui.components.NovaMessageBubble
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.theme.LocalBottomBarInset
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaShapes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.depthSurface
import com.Lia.assistant.voice.ChatPromptBuilder
import com.Lia.assistant.voice.ChatReplyResult
import com.Lia.assistant.voice.ChatTurn
import com.Lia.assistant.voice.GeminiTextClient
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

@Composable
fun ChatScreen(
    appState: NovaAppState,
    initialConversationId: String? = null,
    onBack: () -> Unit,
    onOpenForge: () -> Unit
) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val bottomInset = LocalBottomBarInset.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val conversationId = remember(initialConversationId) {
        initialConversationId ?: UUID.randomUUID().toString()
    }
    val messages = remember(conversationId) {
        mutableStateListOf<ChatMessage>().apply {
            val existing = appState.conversations.firstOrNull { it.id == conversationId }
            existing?.turns?.forEachIndexed { idx, turn ->
                add(
                    ChatMessage(
                        id = "${conversationId}_$idx",
                        text = turn.text,
                        isUser = turn.isUser
                    )
                )
            }
        }
    }

    var inputText by remember { mutableStateOf("") }
    var isTyping by remember { mutableStateOf(false) }

    val ttsRef = remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(context) {
        var tts: TextToSpeech? = null
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
            }
        }
        ttsRef.value = tts
        onDispose {
            ttsRef.value?.stop()
            ttsRef.value?.shutdown()
            ttsRef.value = null
        }
    }

    LaunchedEffect(messages.size, isTyping) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    fun persistConversation() {
        val turns = messages.filter { !it.isError && it.text.isNotBlank() }.map {
            ChatTurnRecord(isUser = it.isUser, text = it.text)
        }
        if (turns.isEmpty()) return
        val firstUser = turns.firstOrNull { it.isUser }?.text ?: "Chat"
        val title = firstUser.take(42)
        val preview = turns.last().text.take(90)
        appState.upsertConversation(
            ConversationRecord(
                id = conversationId,
                title = title,
                preview = preview,
                updatedAtMs = System.currentTimeMillis(),
                turns = turns
            )
        )
    }

    fun sendMessage(overrideText: String? = null) {
        val trimmed = (overrideText ?: inputText).trim()
        if (trimmed.isEmpty() || isTyping) return
        if (overrideText == null) inputText = ""

        messages += ChatMessage(
            id = UUID.randomUUID().toString(),
            text = trimmed,
            isUser = true
        )

        val forgePrompt = ForgeIntent.extract(trimmed)
        if (forgePrompt != null) {
            val startRes = ForgeController.start(context, forgePrompt)
            val replyText = if (startRes == ForgeStartResult.Started) {
                "Opening the Forge to build that for you..."
            } else {
                startRes.spokenMessage
            }
            messages += ChatMessage(
                id = UUID.randomUUID().toString(),
                text = replyText,
                isUser = false,
                isForgePreview = startRes == ForgeStartResult.Started
            )
            persistConversation()
            if (startRes == ForgeStartResult.Started) {
                onOpenForge()
            }
            return
        }

        val replyId = UUID.randomUUID().toString()
        messages += ChatMessage(
            id = replyId,
            text = "",
            isUser = false,
            isStreaming = true
        )
        isTyping = true

        scope.launch {
            val history = messages
                .filter { it.id != replyId && !it.isError && it.text.isNotBlank() }
                .map { ChatTurn(isUser = it.isUser, text = it.text) }

            val sysPrompt = ChatPromptBuilder.build(
                personality = appState.personality,
                language = appState.language,
                assistantName = appState.assistantName
            )

            when (val res = GeminiTextClient.reply(ApiKeyStore.getKey(context), sysPrompt, history)) {
                is ChatReplyResult.Success -> {
                    if (reducedMotion) {
                        val idx = messages.indexOfFirst { it.id == replyId }
                        if (idx >= 0) {
                            messages[idx] = messages[idx].copy(
                                text = res.text,
                                isStreaming = false
                            )
                        }
                    } else {
                        val words = res.text.split(" ")
                        val builder = StringBuilder()
                        for ((wIdx, word) in words.withIndex()) {
                            if (wIdx > 0) builder.append(' ')
                            builder.append(word)
                            val idx = messages.indexOfFirst { it.id == replyId }
                            if (idx >= 0) {
                                messages[idx] = messages[idx].copy(
                                    text = builder.toString(),
                                    isStreaming = wIdx < words.lastIndex
                                )
                            }
                            delay(20L)
                        }
                    }
                    persistConversation()
                }
                is ChatReplyResult.Error -> {
                    val idx = messages.indexOfFirst { it.id == replyId }
                    if (idx >= 0) {
                        messages[idx] = messages[idx].copy(
                            text = res.message,
                            isStreaming = false,
                            isError = true
                        )
                    }
                }
            }
            isTyping = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .padding(bottom = bottomInset)
    ) {
        // Calm 3D Chat Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(48.dp)
                    .depthSurface(shape = CircleShape, elevation = 4.dp)
                    .testTag("chat_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = colors.textPrimary
                )
            }
            Spacer(Modifier.width(NovaSpacing.md))
            LiaOrb3D(
                state = if (isTyping) NovaOrbState.THINKING else NovaOrbState.IDLE,
                size = 40.dp,
                amplitude = if (isTyping) 0.45f else 0f,
                style = appState.orbStyle,
                assistantName = appState.assistantName
            )
            Spacer(Modifier.width(NovaSpacing.md))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = appState.assistantName,
                    style = MaterialTheme.typography.titleLarge,
                    color = colors.textPrimary
                )
                Text(
                    text = if (isTyping) "Typing..." else "Here to help",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isTyping) colors.accent else colors.textSecondary
                )
            }
        }

        // Message List
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                NovaEmptyState(
                    icon = Icons.Rounded.AutoAwesome,
                    title = "Chat with ${appState.assistantName}",
                    subtitle = "Type in English, Hindi, or Hinglish — or say \"ek cafe ki website banao\" to open the 3D Forge.",
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        horizontal = NovaSpacing.lg,
                        vertical = NovaSpacing.md
                    ),
                    verticalArrangement = Arrangement.spacedBy(NovaSpacing.md)
                ) {
                    itemsIndexed(messages, key = { _, item -> item.id }) { index, msg ->
                        NovaMessageBubble(
                            message = msg,
                            onCopy = { text ->
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText(appState.assistantName, text))
                                Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                            },
                            onSpeak = { text ->
                                ttsRef.value?.speak(text, TextToSpeech.QUEUE_FLUSH, null, msg.id)
                            },
                            onRetry = if (!msg.isUser && index > 0) {
                                {
                                    val prevUser = messages.subList(0, index)
                                        .lastOrNull { it.isUser }?.text
                                    if (!prevUser.isNullOrBlank()) {
                                        messages.removeAt(index)
                                        sendMessage(prevUser)
                                    }
                                }
                            } else null,
                            onOpenForge = if (msg.isForgePreview) onOpenForge else null
                        )
                    }
                }
            }
        }

        // Floating Glass Input Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm)
                .depthSurface(shape = NovaShapes.pill, elevation = 10.dp)
                .padding(horizontal = NovaSpacing.sm, vertical = NovaSpacing.xs),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) {
                NovaTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = "Message ${appState.assistantName}...",
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { sendMessage() }),
                    testTag = "chat_input"
                )
            }
            Spacer(Modifier.width(NovaSpacing.sm))
            IconButton(
                onClick = { sendMessage() },
                enabled = inputText.isNotBlank() && !isTyping,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .graphicsLayer {
                        val s = if (inputText.isNotBlank() && !isTyping) 1f else 0.9f
                        scaleX = s
                        scaleY = s
                    }
                    .depthSurface(
                        shape = CircleShape,
                        elevation = 6.dp,
                        backgroundColor = if (inputText.isNotBlank() && !isTyping) {
                            colors.accent
                        } else {
                            colors.surfaceRaised
                        }
                    )
                    .testTag("chat_send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.Send,
                    contentDescription = "Send message",
                    tint = if (inputText.isNotBlank() && !isTyping) colors.onAccent else colors.textTertiary
                )
            }
        }
        Spacer(Modifier.height(NovaSpacing.xs))
    }
}
