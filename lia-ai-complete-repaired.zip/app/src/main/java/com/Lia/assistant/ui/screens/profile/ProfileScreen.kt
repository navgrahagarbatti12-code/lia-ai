package com.Lia.assistant.ui.screens.profile

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.license.AccessKeySection
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaPickerDialog
import com.Lia.assistant.ui.components.NovaSettingsRow
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.voice.VoiceSessionManager

@Composable
fun ProfileScreen(
    appState: NovaAppState,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    var userNameInput by remember(appState.userName) { mutableStateOf(appState.userName) }
    var assistantNameInput by remember(appState.assistantName) { mutableStateOf(appState.assistantName) }
    var showVoicePicker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        NovaTopBar(
            title = "Profile",
            subtitle = "Identity, voice & license",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(NovaSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LiaOrb3D(
                    state = NovaOrbState.IDLE,
                    size = 96.dp,
                    style = appState.orbStyle,
                    assistantName = appState.assistantName
                )
            }

            NovaGlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Personalization",
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary
                )
                Spacer(Modifier.height(NovaSpacing.md))
                NovaTextField(
                    value = userNameInput,
                    onValueChange = { userNameInput = it },
                    label = "Your Name",
                    placeholder = "Used in greetings",
                    leadingIcon = Icons.Rounded.Person,
                    testTag = "profile_user_name"
                )
                Spacer(Modifier.height(NovaSpacing.md))
                NovaTextField(
                    value = assistantNameInput,
                    onValueChange = { assistantNameInput = it },
                    label = "Assistant Name",
                    placeholder = "Default: Lia",
                    leadingIcon = Icons.Rounded.AutoAwesome,
                    testTag = "profile_assistant_name"
                )
                Spacer(Modifier.height(NovaSpacing.md))
                NovaButton(
                    text = "Save Profile",
                    onClick = {
                        appState.applyUserName(userNameInput)
                        appState.applyAssistantName(assistantNameInput)
                        VoiceSessionManager.refreshInstructions(context)
                        Toast.makeText(context, "Profile updated", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            NovaGlassCard(modifier = Modifier.fillMaxWidth()) {
                NovaSettingsRow(
                    icon = Icons.Rounded.RecordVoiceOver,
                    title = "Gemini Live Voice",
                    subtitle = "Choose the voice timbre for live conversations",
                    value = appState.voiceName,
                    onClick = { showVoicePicker = true }
                )
            }

            AccessKeySection()
        }
    }

    if (showVoicePicker) {
        NovaPickerDialog(
            title = "Select Voice",
            options = VoiceSessionManager.AVAILABLE_VOICES,
            selected = appState.voiceName,
            labelOf = { it },
            onSelect = {
                appState.applyVoiceName(it)
                VoiceSessionManager.refreshInstructions(context)
            },
            onDismiss = { showVoicePicker = false }
        )
    }
}
