package com.Lia.assistant.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.depthSurface

data class ChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    val isForgePreview: Boolean = false
)

@Composable
fun NovaMessageBubble(
    message: ChatMessage,
    modifier: Modifier = Modifier,
    onCopy: ((String) -> Unit)? = null,
    onRetry: (() -> Unit)? = null,
    onSpeak: ((String) -> Unit)? = null,
    onOpenForge: (() -> Unit)? = null
) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    var appeared by remember(message.id) { mutableStateOf(reducedMotion) }
    LaunchedEffect(message.id) {
        appeared = true
    }

    val translateY by animateFloatAsState(
        targetValue = if (appeared) 0f else 18f,
        animationSpec = tween(NovaMotion.NORMAL_MS),
        label = "bubble_rise"
    )
    val shadowDp by animateDpAsState(
        targetValue = if (appeared) 4.dp else 10.dp,
        animationSpec = tween(NovaMotion.NORMAL_MS),
        label = "bubble_shadow"
    )

    val bubbleShape = if (message.isUser) {
        RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 6.dp)
    } else {
        RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 6.dp, bottomEnd = 20.dp)
    }

    val bg = when {
        message.isError -> colors.error.copy(alpha = 0.16f)
        message.isUser -> colors.userBubble
        else -> colors.assistantBubble
    }
    val border = when {
        message.isError -> colors.error.copy(alpha = 0.6f)
        message.isUser -> colors.accent.copy(alpha = 0.4f)
        else -> colors.surfaceBorder
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer { translationY = translateY },
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .depthSurface(
                    shape = bubbleShape,
                    elevation = shadowDp,
                    backgroundColor = bg,
                    borderColor = border
                )
                .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.md)
        ) {
            if (message.isStreaming && message.text.isBlank()) {
                NovaTypingDots()
            } else {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (message.isError) colors.error else colors.textPrimary
                )
            }

            if (message.isForgePreview && onOpenForge != null) {
                Spacer(Modifier.height(NovaSpacing.sm))
                NovaButton(
                    text = "Open Website Forge",
                    onClick = onOpenForge,
                    style = NovaButtonStyle.SECONDARY,
                    icon = Icons.Rounded.AutoFixHigh
                )
            }

            if (!message.isUser && !message.isStreaming && message.text.isNotBlank()) {
                Spacer(Modifier.height(NovaSpacing.xs))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ) {
                    if (onCopy != null) {
                        IconButton(
                            onClick = { onCopy(message.text) },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ContentCopy,
                                contentDescription = "Copy reply",
                                tint = colors.textSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    if (onSpeak != null) {
                        IconButton(
                            onClick = { onSpeak(message.text) },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.VolumeUp,
                                contentDescription = "Speak reply",
                                tint = colors.textSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    if (onRetry != null) {
                        Spacer(Modifier.width(NovaSpacing.xs))
                        IconButton(
                            onClick = onRetry,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Retry reply",
                                tint = colors.textSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
