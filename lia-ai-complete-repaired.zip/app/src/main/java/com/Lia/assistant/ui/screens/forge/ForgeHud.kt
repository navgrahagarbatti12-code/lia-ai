package com.Lia.assistant.ui.screens.forge

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.Lia.assistant.forge.ForgeStage
import com.Lia.assistant.forge.ForgeUiState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaShapes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.depthSurface
import java.util.Locale

@Composable
fun ForgeHud(
    state: ForgeUiState,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(state.stage) {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(NovaSpacing.lg)
    ) {
        // Floating top prompt chip
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .depthSurface(shape = NovaShapes.pill, elevation = 10.dp)
                .padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.AutoFixHigh,
                contentDescription = null,
                tint = colors.accent,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(NovaSpacing.sm))
            Text(
                text = state.prompt.ifBlank { "Building website" },
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Bottom floating glass status card
        NovaGlassCard(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            elevation = 14.dp
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (state.isEdit) "UPDATING DESIGN" else "FORGING WEBSITE",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.lagoon
                    )
                    Spacer(Modifier.height(2.dp))
                    if (reducedMotion) {
                        Text(
                            text = state.stage.label,
                            style = MaterialTheme.typography.titleLarge,
                            color = colors.textPrimary,
                            modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }
                        )
                    } else {
                        AnimatedContent(
                            targetState = state.stage.label,
                            transitionSpec = {
                                (fadeIn() + slideInVertically { it / 2 }) togetherWith
                                    (fadeOut() + slideOutVertically { -it / 2 })
                            },
                            label = "forge_stage_label"
                        ) { label ->
                            Text(
                                text = label,
                                style = MaterialTheme.typography.titleLarge,
                                color = colors.textPrimary,
                                modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }
                            )
                        }
                    }
                }
                Text(
                    text = "${(state.progress * 100).toInt().coerceIn(0, 100)}%",
                    style = MaterialTheme.typography.displayMedium,
                    color = colors.accent
                )
            }

            Spacer(Modifier.height(NovaSpacing.md))

            // Six-segment stage track
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(NovaSpacing.xs)
            ) {
                ForgeStage.entries.forEach { st ->
                    val filled = st.index <= state.stage.index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(6.dp)
                            .clip(CircleShape)
                            .background(if (filled) colors.accent else colors.surfaceBorder)
                    )
                }
            }

            Spacer(Modifier.height(NovaSpacing.md))

            // Stats row (KB, sections, tokens/s, elapsed)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                HudStat("SIZE", String.format(Locale.US, "%.1f KB", state.metrics.chars / 1024f))
                HudStat("SECTIONS", "${state.metrics.sections}")
                HudStat("SPEED", "${state.metrics.tokensPerSec.toInt()} tok/s")
                HudStat("ELAPSED", String.format(Locale.US, "%.1fs", state.metrics.elapsedSec))
            }

            Spacer(Modifier.height(NovaSpacing.md))

            NovaButton(
                text = "Cancel Build",
                onClick = onCancel,
                style = NovaButtonStyle.SECONDARY,
                icon = Icons.Rounded.Close,
                tintOverride = colors.error,
                modifier = Modifier.fillMaxWidth(),
                testTag = "forge_cancel_button"
            )
        }
    }
}

@Composable
private fun HudStat(label: String, value: String) {
    val colors = LocalNovaColors.current
    Column(horizontalAlignment = Alignment.Start) {
        Text(text = label, style = MaterialTheme.typography.labelMedium, color = colors.textTertiary)
        Text(text = value, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
    }
}
