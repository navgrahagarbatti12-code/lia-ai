package com.Lia.assistant.action

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

object ContactResolver {
    data class ContactCandidate(
        val displayName: String,
        val phoneNumber: String
    )

    sealed class LookupResult {
        data class Found(val displayName: String, val phoneNumber: String) : LookupResult()
        data object NoPermission : LookupResult()
        data object NotFound : LookupResult()
    }

    fun looksLikePhoneNumber(query: String): Boolean {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return false
        var digitCount = 0
        for (ch in trimmed) {
            when {
                ch.isDigit() -> digitCount++
                ch in charArrayOf(' ', '+', '-', '(', ')', '.') -> Unit
                else -> return false
            }
        }
        return digitCount >= 5
    }

    internal fun rankBestCandidate(
        query: String,
        candidates: List<ContactCandidate>
    ): ContactCandidate? {
        val q = query.trim().lowercase()
        if (q.isEmpty() || candidates.isEmpty()) return null
        return candidates.minWithOrNull(
            compareBy<ContactCandidate> { rankScore(q, it.displayName.trim().lowercase()) }
                .thenBy { it.displayName.length }
                .thenBy { it.displayName.lowercase() }
        )
    }

    private fun rankScore(q: String, name: String): Int = when {
        name == q -> 0
        name.startsWith(q) -> 1
        name.contains(q) -> 2
        else -> 3
    }

    fun lookup(context: Context, query: String): LookupResult {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return LookupResult.NotFound

        if (looksLikePhoneNumber(trimmed)) {
            return LookupResult.Found(displayName = trimmed, phoneNumber = trimmed)
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return LookupResult.NoPermission
        }

        val candidates = ArrayList<ContactCandidate>(5)
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$trimmed%")

        runCatching {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext() && candidates.size < 5) {
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx).orEmpty().trim() else ""
                    val num = if (numIdx >= 0) cursor.getString(numIdx).orEmpty().trim() else ""
                    if (name.isNotEmpty() && num.isNotEmpty()) {
                        candidates += ContactCandidate(name, num)
                    }
                }
            }
        }

        val best = rankBestCandidate(trimmed, candidates) ?: return LookupResult.NotFound
        return LookupResult.Found(best.displayName, best.phoneNumber)
    }
}
