package com.Lia.assistant.ui.fx

enum class NovaOrbState(val label: String) {
    IDLE("Idle"),
    LISTENING("Listening"),
    THINKING("Thinking"),
    SPEAKING("Speaking"),
    CONNECTING("Connecting"),
    ERROR("Error")
}
