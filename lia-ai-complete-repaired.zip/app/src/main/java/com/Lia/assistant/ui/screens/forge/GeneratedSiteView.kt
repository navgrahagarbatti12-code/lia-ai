package com.Lia.assistant.ui.screens.forge

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.Lia.assistant.ui.theme.LocalNovaColors
import kotlinx.coroutines.delay

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GeneratedSiteView(
    html: String,
    isFinal: Boolean,
    isLowRam: Boolean,
    onFinalPainted: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val onPaintedCb by rememberUpdatedState(onFinalPainted)

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var lastLoadedLength by remember { mutableIntStateOf(0) }
    var lastLoadTimeMs by remember { mutableLongStateOf(0L) }
    var finalLoaded by remember { mutableStateOf(false) }
    var paintedFired by remember { mutableStateOf(false) }

    DisposableEffect(lifecycleOwner, webViewRef) {
        val observer = LifecycleEventObserver { _, event ->
            val wv = webViewRef ?: return@LifecycleEventObserver
            when (event) {
                Lifecycle.Event.ON_RESUME -> wv.onResume()
                Lifecycle.Event.ON_PAUSE -> wv.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.destroy()
            webViewRef = null
        }
    }

    LaunchedEffect(html, isFinal, webViewRef) {
        val wv = webViewRef ?: return@LaunchedEffect
        if (html.isBlank()) return@LaunchedEffect

        if (isFinal && !finalLoaded) {
            finalLoaded = true
            paintedFired = false
            lastLoadedLength = html.length
            lastLoadTimeMs = System.currentTimeMillis()
            wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null)
            // Safety cap: wait max 2.5 s before revealing even if external fonts/images lag
            delay(2500L)
            if (!paintedFired) {
                paintedFired = true
                onPaintedCb()
            }
            return@LaunchedEffect
        }

        if (!isFinal && !isLowRam) {
            finalLoaded = false
            val now = System.currentTimeMillis()
            if (html.length - lastLoadedLength >= 4096 && now - lastLoadTimeMs >= 1500L) {
                lastLoadedLength = html.length
                lastLoadTimeMs = now
                wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null)
            }
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(colors.background.toArgb())
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    allowFileAccess = false
                    allowContentAccess = false
                    mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    setGeolocationEnabled(false)
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView,
                        request: WebResourceRequest
                    ): Boolean {
                        val url = request.url?.toString().orEmpty()
                        if (url.startsWith("https://localhost/")) return false
                        if (url.startsWith("http://") || url.startsWith("https://")) {
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                )
                            }
                        }
                        return true
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        if (isFinal && !paintedFired) {
                            view?.postVisualStateCallback(
                                1L,
                                object : WebView.VisualStateCallback() {
                                    override fun onComplete(requestId: Long) {
                                        if (!paintedFired) {
                                            paintedFired = true
                                            onPaintedCb()
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
                webViewRef = this
            }
        }
    )
}
