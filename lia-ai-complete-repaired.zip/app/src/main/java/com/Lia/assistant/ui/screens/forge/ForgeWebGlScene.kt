package com.Lia.assistant.ui.screens.forge

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.content.Context
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.webkit.WebViewAssetLoader
import com.Lia.assistant.forge.ForgePhase
import com.Lia.assistant.forge.ForgeUiState
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

private class ForgeJsBridge(
    private val onReadyCallback: () -> Unit,
    private val onRevealFinishedCallback: () -> Unit,
    private val onWebGlFailedCallback: (String) -> Unit
) {
    @JavascriptInterface
    fun onReady() {
        onReadyCallback()
    }

    @JavascriptInterface
    fun onRevealFinished() {
        onRevealFinishedCallback()
    }

    @JavascriptInterface
    fun onWebGLFailed(reason: String) {
        onWebGlFailedCallback(reason)
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ForgeWebGlScene(
    state: ForgeUiState,
    triggerReveal: Boolean,
    onRevealFinished: () -> Unit,
    onWebGlFailed: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val onRevealCb by rememberUpdatedState(onRevealFinished)
    val onFailCb by rememberUpdatedState(onWebGlFailed)
    val latestState by rememberUpdatedState(state)

    var sceneReady by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var lastPushedKey by remember { mutableStateOf("") }
    var lastRevealTriggered by remember { mutableStateOf(false) }
    var lastFailedTriggered by remember { mutableStateOf(false) }

    val lowRam = remember(context) {
        (context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.isLowRamDevice == true
    }

    val themeJson = remember(colors, reducedMotion, lowRam) {
        JSONObject()
            .put("background", colors.background.toHexString())
            .put("backgroundGradientTop", colors.backgroundGradientTop.toHexString())
            .put("accent", colors.accent.toHexString())
            .put("accentSecondary", colors.accentSecondary.toHexString())
            .put("lagoon", colors.lagoon.toHexString())
            .put("lotus", colors.lotus.toHexString())
            .put("textPrimary", colors.textPrimary.toHexString())
            .put("surfaceBorder", colors.surfaceBorder.toHexString())
            .put("rimLight", colors.rimLight.toHexString())
            .put("reducedMotion", reducedMotion)
            .put("lowRam", lowRam)
            .toString()
    }

    DisposableEffect(lifecycleOwner, webViewRef) {
        val observer = LifecycleEventObserver { _, event ->
            val wv = webViewRef ?: return@LifecycleEventObserver
            when (event) {
                Lifecycle.Event.ON_RESUME -> wv.onResume()
                Lifecycle.Event.ON_PAUSE -> wv.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.let { wv ->
                wv.evaluateJavascript("window.Forge && window.Forge.dispose && window.Forge.dispose();", null)
                wv.removeJavascriptInterface("ForgeBridge")
                wv.destroy()
            }
            webViewRef = null
        }
    }

    // Push state diffs every 60 ms once ready
    LaunchedEffect(sceneReady, webViewRef) {
        val wv = webViewRef ?: return@LaunchedEffect
        if (!sceneReady) return@LaunchedEffect
        while (true) {
            val s = latestState
            val key = "${s.stage.index}|${(s.progress * 200).toInt()}|${s.sections.size}|${s.logSeq}|${s.phase}"
            if (key != lastPushedKey) {
                lastPushedKey = key
                val payload = JSONObject()
                    .put("stage", s.stage.index)
                    .put("progress", s.progress.toDouble())
                    .put("tokensPerSec", s.metrics.tokensPerSec.toDouble())
                    .put("sections", JSONArray(s.sections))
                    .put("log", JSONArray(s.log.takeLast(4)))
                    .put("logSeq", s.logSeq)
                    .toString()
                wv.evaluateJavascript("window.Forge && window.Forge.update(${JSONObject.quote(payload)});", null)
            }
            if (s.phase == ForgePhase.FAILED && !lastFailedTriggered) {
                lastFailedTriggered = true
                wv.evaluateJavascript(
                    "window.Forge && window.Forge.fail(${JSONObject.quote(s.error ?: "Failed")});",
                    null
                )
            }
            delay(60L)
        }
    }

    LaunchedEffect(sceneReady, triggerReveal, webViewRef) {
        val wv = webViewRef ?: return@LaunchedEffect
        if (sceneReady && triggerReveal && !lastRevealTriggered) {
            lastRevealTriggered = true
            wv.evaluateJavascript("window.Forge && window.Forge.reveal();", null)
        }
    }

    LaunchedEffect(sceneReady, reducedMotion, webViewRef) {
        val wv = webViewRef ?: return@LaunchedEffect
        if (sceneReady) {
            wv.evaluateJavascript("window.Forge && window.Forge.setReducedMotion($reducedMotion);", null)
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val assetLoader = WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
                .build()

            WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(colors.background.toArgb())
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = false
                    allowFileAccess = false
                    allowContentAccess = false
                    mediaPlaybackRequiresUserGesture = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    setGeolocationEnabled(false)
                }

                val bridge = ForgeJsBridge(
                    onReadyCallback = { post { sceneReady = true } },
                    onRevealFinishedCallback = { post { onRevealCb() } },
                    onWebGlFailedCallback = { post { onFailCb() } }
                )
                addJavascriptInterface(bridge, "ForgeBridge")

                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView,
                        request: WebResourceRequest
                    ): WebResourceResponse? {
                        return assetLoader.shouldInterceptRequest(request.url)
                    }

                    override fun shouldOverrideUrlLoading(
                        view: WebView,
                        request: WebResourceRequest
                    ): Boolean = true

                    override fun onPageFinished(view: WebView?, url: String?) {
                        view?.evaluateJavascript(
                            "window.Forge && window.Forge.init(${JSONObject.quote(themeJson)});",
                            null
                        )
                    }
                }

                loadUrl("https://appassets.androidplatform.net/assets/forge/forge.html")
                webViewRef = this
            }
        }
    )
}

private fun Color.toHexString(): String {
    val r = (red * 255f).toInt().coerceIn(0, 255)
    val g = (green * 255f).toInt().coerceIn(0, 255)
    val b = (blue * 255f).toInt().coerceIn(0, 255)
    return String.format("#%02X%02X%02X", r, g, b)
}
