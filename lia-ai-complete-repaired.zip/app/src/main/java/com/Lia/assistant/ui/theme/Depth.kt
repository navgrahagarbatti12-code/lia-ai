package com.Lia.assistant.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val LocalBottomBarInset = compositionLocalOf { 0.dp }

private data class StarSpec(
    val xFraction: Float,
    val yFraction: Float,
    val radiusDp: Float,
    val alpha: Float,
    val parallaxDepth: Float
)

private val STAR_FIELD = List(42) { idx ->
    val seed1 = ((idx * 73 + 19) % 100) / 100f
    val seed2 = ((idx * 41 + 37) % 100) / 100f
    val r = 0.8f + (idx % 3) * 0.55f
    val a = 0.14f + (idx % 5) * 0.08f
    val depth = 0.4f + (idx % 4) * 0.35f
    StarSpec(seed1, seed2, r, a, depth)
}

fun Modifier.nightSky(
    tiltX: Float = 0f,
    tiltY: Float = 0f,
    ambientGlowColor: Color? = null
): Modifier = composed {
    val colors = LocalNovaColors.current
    val isDark = LocalNovaIsDark.current
    val reducedMotion = LocalNovaReducedMotion.current
    val pxShiftX = if (reducedMotion) 0f else tiltX.coerceIn(-1f, 1f)
    val pxShiftY = if (reducedMotion) 0f else tiltY.coerceIn(-1f, 1f)

    drawBehind {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(colors.backgroundGradientTop, colors.background)
            )
        )

        val glow = ambientGlowColor ?: colors.accentGlow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    glow.copy(alpha = if (isDark) 0.24f else 0.16f),
                    Color.Transparent
                ),
                center = Offset(
                    x = size.width * (0.5f + pxShiftX * 0.03f),
                    y = size.height * (0.34f + pxShiftY * 0.03f)
                ),
                radius = size.maxDimension * 0.58f
            ),
            radius = size.maxDimension * 0.58f,
            center = Offset(
                x = size.width * (0.5f + pxShiftX * 0.03f),
                y = size.height * (0.34f + pxShiftY * 0.03f)
            )
        )

        if (isDark) {
            val maxParallaxPx = 8.dp.toPx()
            for (star in STAR_FIELD) {
                val cx = star.xFraction * size.width + pxShiftX * maxParallaxPx * star.parallaxDepth
                val cy = star.yFraction * size.height + pxShiftY * maxParallaxPx * star.parallaxDepth
                drawCircle(
                    color = colors.textPrimary.copy(alpha = star.alpha),
                    radius = star.radiusDp.dp.toPx(),
                    center = Offset(cx, cy)
                )
            }
        }
    }
}

fun Modifier.depthSurface(
    shape: Shape = NovaShapes.medium,
    elevation: Dp = 8.dp,
    backgroundColor: Color? = null,
    borderColor: Color? = null
): Modifier = composed {
    val colors = LocalNovaColors.current
    val fill = backgroundColor ?: colors.surfaceGlass
    val border = borderColor ?: colors.surfaceBorder

    this
        .shadow(
            elevation = elevation,
            shape = shape,
            ambientColor = colors.depthShadow,
            spotColor = colors.depthShadow
        )
        .clip(shape)
        .background(
            brush = Brush.verticalGradient(
                colors = listOf(
                    colors.rimLight.copy(alpha = 0.08f),
                    Color.Transparent
                )
            )
        )
        .background(fill)
        .border(
            width = 1.dp,
            brush = Brush.verticalGradient(
                colors = listOf(colors.rimLight.copy(alpha = 0.45f), border)
            ),
            shape = shape
        )
}
