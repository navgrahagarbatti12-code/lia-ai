package com.Lia.assistant.action

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object CommIntents {
    fun placeCall(context: Context, phoneNumber: String): String {
        val clean = phoneNumber.trim()
        if (clean.isEmpty()) return "invalid_number"
        val hasCallPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val action = if (hasCallPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.parse("tel:${Uri.encode(clean)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching {
            context.startActivity(intent)
            if (hasCallPerm) "calling" else "dialer_opened_no_permission"
        }.getOrElse {
            "call_failed"
        }
    }

    fun openSmsComposer(context: Context, phoneNumber: String, message: String): Boolean {
        val clean = phoneNumber.trim()
        if (clean.isEmpty()) return false
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(clean)}")).apply {
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching {
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    fun openWhatsAppComposer(context: Context, phoneNumber: String, message: String): Boolean {
        val digits = phoneNumber.filter { it.isDigit() }
        if (digits.isEmpty()) return false
        val encodedText = URLEncoder.encode(message, StandardCharsets.UTF_8.name())
        val uri = Uri.parse("https://wa.me/$digits?text=$encodedText")
        val waPackage = findInstalledWhatsAppPackage(context)
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            if (waPackage != null) setPackage(waPackage)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching {
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    private fun findInstalledWhatsAppPackage(context: Context): String? {
        val pm = context.packageManager
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            val installed = runCatching { pm.getPackageInfo(pkg, 0) }.isSuccess
            if (installed) return pkg
        }
        return null
    }
}
