package com.Lia.assistant.forge

object ForgeStageDetector {
    private val SECTION_ATTR_REGEX = Regex(
        """<(?:section|header|footer|main)[^>]*(?:aria-label|data-section|id)\s*=\s*["']([^"']+)["']""",
        RegexOption.IGNORE_CASE
    )
    private val HEADING_REGEX = Regex("""<h[12][^>]*>([^<]{2,48})</h[12]>""", RegexOption.IGNORE_CASE)
    private val TAG_STRIP = Regex("<[^>]+>")

    fun detect(partialHtml: String): ForgeStage {
        val lower = partialHtml.lowercase()
        val bodyIdx = lower.indexOf("<body")
        if (bodyIdx < 0) {
            return if (lower.contains("<style") || lower.contains("tailwindcss")) {
                ForgeStage.SPARK
            } else {
                ForgeStage.SPARK
            }
        }

        val bodyPart = lower.substring(bodyIdx)
        val hasStructure = bodyPart.contains("<header") || bodyPart.contains("<section") || bodyPart.contains("<main")
        val hasStyling = lower.contains("<style") || bodyPart.contains("class=")
        val hasMotion = lower.contains("gsap") ||
            lower.contains("@keyframes") ||
            lower.contains("transition") ||
            lower.contains("scrolltrigger")
        val hasVisuals = bodyPart.contains("<canvas") ||
            lower.contains("three.") ||
            lower.contains("new three") ||
            bodyPart.contains("<svg") ||
            bodyPart.contains("<img")
        val hasPolish = lower.contains("</html>") ||
            (hasVisuals && hasMotion && bodyPart.length > 9000 && lower.contains("</footer>"))

        return when {
            hasPolish -> ForgeStage.POLISH
            hasVisuals && hasStructure -> ForgeStage.VISUALS
            hasMotion && hasStructure -> ForgeStage.MOTION
            hasStyling && hasStructure -> ForgeStage.STYLING
            hasStructure -> ForgeStage.STRUCTURE
            else -> ForgeStage.SPARK
        }
    }

    fun extractSectionNames(partialHtml: String): List<String> {
        val names = LinkedHashSet<String>()
        SECTION_ATTR_REGEX.findAll(partialHtml).forEach { m ->
            val raw = m.groupValues[1].trim()
                .replace('-', ' ')
                .replace('_', ' ')
            if (raw.length in 2..36) {
                names += raw.split(' ').filter { it.isNotEmpty() }.joinToString(" ") { w ->
                    w.replaceFirstChar { c -> c.uppercase() }
                }
            }
        }
        if (names.isEmpty()) {
            HEADING_REGEX.findAll(partialHtml).forEach { m ->
                val clean = m.groupValues[1].replace(TAG_STRIP, "").trim()
                if (clean.length in 2..36) {
                    names += clean
                }
            }
        }
        return names.toList()
    }
}
