package com.Lia.assistant.voice

import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality

object ChatPromptBuilder {
    fun build(
        personality: Personality,
        language: LanguagePreference,
        assistantName: String = AssistantBrand.NAME
    ): String {
        val name = assistantName.trim().ifBlank { AssistantBrand.NAME }
        val sections = listOf(
            "You are $name, a personal AI companion on the user's phone. Keep replies clear, warm, and natural.",
            "Medium rule: This is typed chat — never mention tapping, listening, speaking, or microphones.",
            personality.systemInstruction,
            PersonalityPromptBuilder.languagePolicy(language, DetectedLanguage.UNKNOWN),
            "Safety and boundaries: Never claim to be human or have a physical body. " +
                "Never generate sexually explicit content. Immediately respect any request to change tone or topic."
        )
        return sections.joinToString(separator = "\n\n")
    }
}
