package com.Lia.assistant.ui.screens.permissions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaSpacing

private data class PermissionEntry(
    val title: String,
    val description: String,
    val permission: String?,
    val required: Boolean,
    val granted: Boolean
)

@Composable
fun PermissionsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var refreshTick by remember { mutableIntStateOf(0) }

    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refreshTick++
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        refreshTick++
    }

    val entries = remember(refreshTick) { buildPermissionEntries(context) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        NovaTopBar(
            title = "Permissions",
            subtitle = "Live status checked on resume",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(NovaSpacing.lg),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md)
        ) {
            entries.forEach { entry ->
                val lightColor = when {
                    entry.granted -> colors.lagoon
                    entry.required -> colors.error
                    else -> colors.warning
                }
                val pulseScale = remember { Animatable(1f) }
                val reducedMotion = LocalNovaReducedMotion.current
                LaunchedEffect(entry.granted) {
                    if (!reducedMotion) {
                        pulseScale.snapTo(1.5f)
                        pulseScale.animateTo(1f, tween(350))
                    }
                }

                NovaGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (!entry.granted && entry.permission != null) {
                            launcher.launch(entry.permission)
                        }
                    }
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .graphicsLayer {
                                    scaleX = pulseScale.value
                                    scaleY = pulseScale.value
                                }
                                .clip(CircleShape)
                                .background(lightColor)
                        )
                        Spacer(Modifier.width(NovaSpacing.md))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = entry.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = colors.textPrimary
                            )
                            Text(
                                text = entry.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                        Spacer(Modifier.width(NovaSpacing.sm))
                        Text(
                            text = if (entry.granted) "Granted" else "Grant",
                            style = MaterialTheme.typography.labelLarge,
                            color = lightColor
                        )
                    }
                }
            }

            Spacer(Modifier.height(NovaSpacing.sm))
            NovaButton(
                text = "Open App Settings",
                style = NovaButtonStyle.SECONDARY,
                onClick = {
                    context.startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${context.packageName}")
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

private fun buildPermissionEntries(context: Context): List<PermissionEntry> {
    fun isGranted(p: String) =
        ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED

    return buildList {
        add(
            PermissionEntry(
                title = "Microphone",
                description = "Required for live voice conversation",
                permission = Manifest.permission.RECORD_AUDIO,
                required = true,
                granted = isGranted(Manifest.permission.RECORD_AUDIO)
            )
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(
                PermissionEntry(
                    title = "Notifications",
                    description = "Shows voice session controls and Website Forge alerts",
                    permission = Manifest.permission.POST_NOTIFICATIONS,
                    required = false,
                    granted = isGranted(Manifest.permission.POST_NOTIFICATIONS)
                )
            )
        }
        add(
            PermissionEntry(
                title = "Contacts",
                description = "Resolves names when you say Call or Message",
                permission = Manifest.permission.READ_CONTACTS,
                required = false,
                granted = isGranted(Manifest.permission.READ_CONTACTS)
            )
        )
        add(
            PermissionEntry(
                title = "Phone Calls",
                description = "Places calls directly when granted (otherwise opens dialer)",
                permission = Manifest.permission.CALL_PHONE,
                required = false,
                granted = isGranted(Manifest.permission.CALL_PHONE)
            )
        )
    }
}
