package com.Lia.assistant.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ChatTurnRecord(
    val isUser: Boolean,
    val text: String,
    val timestampMs: Long = System.currentTimeMillis()
)

data class ConversationRecord(
    val id: String,
    val title: String,
    val preview: String,
    val updatedAtMs: Long,
    val turns: List<ChatTurnRecord> = emptyList()
)

object ConversationStore {
    private const val MAX_CONVERSATIONS = 40

    fun load(context: Context): List<ConversationRecord> {
        val raw = NovaPreferences.getString(context, NovaPreferences.Keys.CONVERSATIONS_JSON, "")
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val turnsArr = obj.optJSONArray("turns") ?: JSONArray()
                    val turns = buildList {
                        for (j in 0 until turnsArr.length()) {
                            val t = turnsArr.getJSONObject(j)
                            add(
                                ChatTurnRecord(
                                    isUser = t.optBoolean("isUser", true),
                                    text = t.optString("text", ""),
                                    timestampMs = t.optLong("timestampMs", 0L)
                                )
                            )
                        }
                    }
                    add(
                        ConversationRecord(
                            id = obj.getString("id"),
                            title = obj.optString("title", "Conversation"),
                            preview = obj.optString("preview", ""),
                            updatedAtMs = obj.optLong("updatedAtMs", 0L),
                            turns = turns
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(context: Context, list: List<ConversationRecord>) {
        val arr = JSONArray()
        list.take(MAX_CONVERSATIONS).forEach { record ->
            val turnsArr = JSONArray()
            record.turns.forEach { turn ->
                turnsArr.put(
                    JSONObject()
                        .put("isUser", turn.isUser)
                        .put("text", turn.text)
                        .put("timestampMs", turn.timestampMs)
                )
            }
            arr.put(
                JSONObject()
                    .put("id", record.id)
                    .put("title", record.title)
                    .put("preview", record.preview)
                    .put("updatedAtMs", record.updatedAtMs)
                    .put("turns", turnsArr)
            )
        }
        NovaPreferences.putString(context, NovaPreferences.Keys.CONVERSATIONS_JSON, arr.toString())
    }
}
