package com.Lia.assistant.ui.screens.actions

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaSpacing

private data class QuickActionTile(
    val title: String,
    val examplePhrase: String,
    val icon: ImageVector,
    val tint: Color,
    val onClick: () -> Unit
)

@Composable
fun QuickActionsScreen(
    onBack: () -> Unit,
    onOpenForge: () -> Unit,
    onOpenVoice: () -> Unit,
    onOpenChat: () -> Unit,
    onOpenPersonality: () -> Unit
) {
    val colors = LocalNovaColors.current

    val tiles = listOf(
        QuickActionTile(
            title = "Build a website",
            examplePhrase = "\"Ek cafe ki website banao\"",
            icon = Icons.Rounded.AutoFixHigh,
            tint = colors.accent,
            onClick = onOpenForge
        ),
        QuickActionTile(
            title = "Live Voice Talk",
            examplePhrase = "\"Aaj ka mausam kaisa hai\"",
            icon = Icons.Rounded.Mic,
            tint = colors.lagoon,
            onClick = onOpenVoice
        ),
        QuickActionTile(
            title = "Open an App",
            examplePhrase = "\"YouTube kholo\"",
            icon = Icons.Rounded.Apps,
            tint = colors.lotus,
            onClick = onOpenVoice
        ),
        QuickActionTile(
            title = "Call Someone",
            examplePhrase = "\"Maa ko call lagao\"",
            icon = Icons.Rounded.Call,
            tint = colors.success,
            onClick = onOpenVoice
        ),
        QuickActionTile(
            title = "Text Chat",
            examplePhrase = "Write emails, ideas & code",
            icon = Icons.AutoMirrored.Rounded.Chat,
            tint = colors.accentSecondary,
            onClick = onOpenChat
        ),
        QuickActionTile(
            title = "Switch Persona",
            examplePhrase = "Teacher, Developer, Nautanki...",
            icon = Icons.Rounded.Language,
            tint = colors.accent,
            onClick = onOpenPersonality
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        NovaTopBar(
            title = "Quick Actions",
            subtitle = "Real tools ready to launch",
            onBack = onBack
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(NovaSpacing.lg),
            horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md),
            verticalArrangement = Arrangement.spacedBy(NovaSpacing.md),
            modifier = Modifier.weight(1f)
        ) {
            items(tiles) { tile ->
                NovaGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = tile.onClick
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(tile.tint.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = tile.icon,
                            contentDescription = null,
                            tint = tile.tint
                        )
                    }
                    Spacer(Modifier.height(NovaSpacing.md))
                    Text(
                        text = tile.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.textPrimary
                    )
                    Spacer(Modifier.height(NovaSpacing.xs))
                    Text(
                        text = tile.examplePhrase,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                }
            }
        }
    }
}
