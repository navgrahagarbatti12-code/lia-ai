package com.Lia.assistant.ui.fx

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion

@Composable
fun rememberDeviceTilt(): State<Offset> {
    val context = LocalContext.current
    val reducedMotion = LocalNovaReducedMotion.current
    val tiltState = remember { mutableStateOf(Offset.Zero) }

    DisposableEffect(context, reducedMotion) {
        if (reducedMotion) {
            tiltState.value = Offset.Zero
            return@DisposableEffect onDispose {}
        }

        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accel = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (sensorManager == null || accel == null) {
            return@DisposableEffect onDispose {}
        }

        var filteredX = 0f
        var filteredY = 0f
        val alpha = 0.15f

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val rawX = (event.values[0] / 9.81f).coerceIn(-1f, 1f)
                val rawY = (event.values[1] / 9.81f).coerceIn(-1f, 1f)
                filteredX += alpha * (rawX - filteredX)
                filteredY += alpha * (rawY - filteredY)
                tiltState.value = Offset(filteredX, filteredY)
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        sensorManager.registerListener(listener, accel, SensorManager.SENSOR_DELAY_UI)
        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    return tiltState
}
