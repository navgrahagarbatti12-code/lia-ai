package com.Lia.assistant.ui.screens.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.theme.LocalBottomBarInset
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(
    appState: NovaAppState,
    onOpenConversation: (String) -> Unit,
    onStartNewChat: () -> Unit
) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val bottomInset = LocalBottomBarInset.current

    var query by remember { mutableStateOf("") }
    val filtered = remember(appState.conversations, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) appState.conversations
        else appState.conversations.filter {
            it.title.lowercase().contains(q) || it.preview.lowercase().contains(q)
        }
    }
    val listState = rememberLazyListState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(bottom = bottomInset)
    ) {
        Text(
            text = "History",
            style = MaterialTheme.typography.headlineLarge,
            color = colors.textPrimary,
            modifier = Modifier.padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm)
        )

        NovaTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = "Search conversations...",
            leadingIcon = Icons.Rounded.Search,
            modifier = Modifier.padding(horizontal = NovaSpacing.lg),
            testTag = "history_search_input"
        )

        Spacer(Modifier.height(NovaSpacing.md))

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(NovaSpacing.xl),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    LiaOrb3D(
                        state = NovaOrbState.IDLE,
                        size = 110.dp,
                        amplitude = 0f,
                        style = appState.orbStyle,
                        assistantName = appState.assistantName,
                        modifier = Modifier.graphicsLayer { alpha = 0.65f }
                    )
                    Spacer(Modifier.height(NovaSpacing.lg))
                    Text(
                        text = if (appState.conversations.isEmpty()) "No conversations yet" else "No matching chats",
                        style = MaterialTheme.typography.headlineMedium,
                        color = colors.textPrimary
                    )
                    Spacer(Modifier.height(NovaSpacing.sm))
                    Text(
                        text = "Your typed chats appear here automatically.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = colors.textSecondary
                    )
                    Spacer(Modifier.height(NovaSpacing.xl))
                    NovaButton(
                        text = "Start a Chat",
                        onClick = onStartNewChat
                    )
                }
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = NovaSpacing.lg, vertical = NovaSpacing.sm),
                verticalArrangement = Arrangement.spacedBy(NovaSpacing.sm)
            ) {
                itemsIndexed(filtered, key = { _, item -> item.id }) { index, record ->
                    val scrollTiltX by remember(listState, index, reducedMotion) {
                        derivedStateOf {
                            if (reducedMotion) 0f
                            else {
                                val info = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
                                    ?: return@derivedStateOf 0f
                                if (info.offset < 0) {
                                    (info.offset / info.size.toFloat().coerceAtLeast(1f)).coerceIn(-1f, 0f) * -14f
                                } else 0f
                            }
                        }
                    }

                    NovaGlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .graphicsLayer {
                                rotationX = scrollTiltX
                                cameraDistance = 12f * density
                            },
                        onClick = { onOpenConversation(record.id) }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.ChatBubbleOutline,
                                contentDescription = null,
                                tint = colors.accent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(NovaSpacing.md))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = record.title.ifBlank { "Conversation" },
                                    style = MaterialTheme.typography.titleMedium,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = record.preview,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                                        .format(Date(record.updatedAtMs)),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = colors.textTertiary
                                )
                            }
                            IconButton(
                                onClick = { appState.deleteConversation(record.id) },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = "Delete conversation",
                                    tint = colors.textSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
