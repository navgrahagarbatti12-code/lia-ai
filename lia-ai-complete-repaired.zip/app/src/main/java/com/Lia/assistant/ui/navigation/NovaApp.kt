package com.Lia.assistant.ui.navigation

import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.forge.ForgeController
import com.Lia.assistant.forge.ForgeStartResult
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.fx.rememberDeviceTilt
import com.Lia.assistant.ui.screens.actions.QuickActionsScreen
import com.Lia.assistant.ui.screens.chat.ChatScreen
import com.Lia.assistant.ui.screens.forge.ForgeScreen
import com.Lia.assistant.ui.screens.history.HistoryScreen
import com.Lia.assistant.ui.screens.home.HomeScreen
import com.Lia.assistant.ui.screens.info.AboutScreen
import com.Lia.assistant.ui.screens.info.DebugScreen
import com.Lia.assistant.ui.screens.info.PrivacyScreen
import com.Lia.assistant.ui.screens.onboarding.OnboardingScreen
import com.Lia.assistant.ui.screens.orb.OrbStyleScreen
import com.Lia.assistant.ui.screens.permissions.PermissionsScreen
import com.Lia.assistant.ui.screens.personality.PersonalityScreen
import com.Lia.assistant.ui.screens.profile.ProfileScreen
import com.Lia.assistant.ui.screens.settings.SettingsScreen
import com.Lia.assistant.ui.screens.splash.LiaSplash3D
import com.Lia.assistant.ui.screens.voice.VoiceScreen
import com.Lia.assistant.ui.theme.LocalBottomBarInset
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.nightSky
import com.Lia.assistant.voice.VoiceSessionManager

object NovaRoutes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val CHAT = "chat"
    const val CHAT_WITH_ID = "chat?conversationId={conversationId}"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val VOICE = "voice"
    const val QUICK_ACTIONS = "quick_actions"
    const val PROFILE = "profile"
    const val PERSONALITY = "personality"
    const val ORB_STYLE = "orb_style"
    const val PRIVACY = "privacy"
    const val PERMISSIONS = "permissions"
    const val ABOUT = "about"
    const val DEBUG = "debug"
    const val FORGE = "forge"
}

@Composable
fun NovaApp(appState: NovaAppState) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val tilt by rememberDeviceTilt()
    val orbState by VoiceSessionManager.state.collectAsState()
    val orbAmplitude by VoiceSessionManager.amplitude.collectAsState()
    val pendingForgeOpen by ForgeController.pendingOpen.collectAsState()

    val targetGlow = when (orbState) {
        NovaOrbState.LISTENING -> colors.lagoon
        NovaOrbState.SPEAKING -> colors.lotus
        NovaOrbState.THINKING -> Color(0xFF8B5CF6)
        NovaOrbState.CONNECTING -> colors.warning
        NovaOrbState.ERROR -> colors.error
        NovaOrbState.IDLE -> colors.accentGlow
    }
    val animatedGlow by animateColorAsState(
        targetValue = targetGlow,
        animationSpec = tween(NovaMotion.SLOW_MS),
        label = "ambient_glow"
    )

    // Observe ForgeController.pendingOpen from Voice tool or notification
    LaunchedEffect(pendingForgeOpen, appState.isLoaded) {
        if (pendingForgeOpen && appState.isLoaded) {
            ForgeController.consumePendingOpen()
            navController.navigate(NovaRoutes.FORGE) {
                launchSingleTop = true
            }
        }
    }

    if (!appState.isLoaded) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .nightSky(tilt.x, tilt.y, animatedGlow)
        )
        return
    }

    val showBottomBar = currentRoute == NovaRoutes.HOME ||
        currentRoute?.startsWith(NovaRoutes.CHAT) == true ||
        currentRoute == NovaRoutes.HISTORY ||
        currentRoute == NovaRoutes.SETTINGS

    val startDest = if (appState.hasOnboarded) NovaRoutes.HOME else NovaRoutes.ONBOARDING

    fun navigateTopTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .nightSky(tilt.x, tilt.y, animatedGlow),
        containerColor = Color.Transparent,
        bottomBar = {
            if (showBottomBar) {
                LiaBottomNavigation(
                    currentRoute = currentRoute,
                    orbState = orbState,
                    orbAmplitude = orbAmplitude,
                    orbStyle = appState.orbStyle,
                    assistantName = appState.assistantName,
                    onNavigateHome = { navigateTopTab(NovaRoutes.HOME) },
                    onNavigateChat = { navigateTopTab(NovaRoutes.CHAT) },
                    onNavigateVoice = {
                        navController.navigate(NovaRoutes.VOICE) { launchSingleTop = true }
                    },
                    onNavigateHistory = { navigateTopTab(NovaRoutes.HISTORY) },
                    onNavigateSettings = { navigateTopTab(NovaRoutes.SETTINGS) }
                )
            }
        }
    ) { _ ->
        val bottomInset = if (showBottomBar) 88.dp else 0.dp
        CompositionLocalProvider(LocalBottomBarInset provides bottomInset) {
            NavHost(
                navController = navController,
                startDestination = startDest,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(NovaRoutes.SPLASH) {
                    LiaSplash3D(
                        assistantName = appState.assistantName,
                        onFinished = {
                            val next = if (appState.hasOnboarded) NovaRoutes.HOME else NovaRoutes.ONBOARDING
                            navController.navigate(next) {
                                popUpTo(NovaRoutes.SPLASH) { inclusive = true }
                            }
                        }
                    )
                }

                composable(NovaRoutes.ONBOARDING) {
                    OnboardingScreen(
                        appState = appState,
                        onComplete = {
                            navController.navigate(NovaRoutes.HOME) {
                                popUpTo(NovaRoutes.ONBOARDING) { inclusive = true }
                            }
                        }
                    )
                }

                composable(NovaRoutes.HOME) {
                    HomeScreen(
                        appState = appState,
                        onOpenVoice = { navController.navigate(NovaRoutes.VOICE) { launchSingleTop = true } },
                        onOpenChat = { navigateTopTab(NovaRoutes.CHAT) },
                        onOpenProfile = { navController.navigate(NovaRoutes.PROFILE) },
                        onOpenQuickActions = { navController.navigate(NovaRoutes.QUICK_ACTIONS) },
                        onTryForge = { prompt ->
                            val res = ForgeController.start(context, prompt)
                            if (res != ForgeStartResult.Started) {
                                Toast.makeText(context, res.spokenMessage, Toast.LENGTH_LONG).show()
                                if (res == ForgeStartResult.MissingKey) {
                                    navigateTopTab(NovaRoutes.SETTINGS)
                                }
                            }
                        }
                    )
                }

                composable(
                    route = NovaRoutes.CHAT_WITH_ID,
                    arguments = listOf(
                        navArgument("conversationId") {
                            type = NavType.StringType
                            nullable = true
                            defaultValue = null
                        }
                    )
                ) { entry ->
                    val convoId = entry.arguments?.getString("conversationId")
                    ChatScreen(
                        appState = appState,
                        initialConversationId = convoId,
                        onBack = {
                            if (!navController.popBackStack()) {
                                navigateTopTab(NovaRoutes.HOME)
                            }
                        },
                        onOpenForge = {
                            navController.navigate(NovaRoutes.FORGE) { launchSingleTop = true }
                        }
                    )
                }

                composable(NovaRoutes.HISTORY) {
                    HistoryScreen(
                        appState = appState,
                        onOpenConversation = { id ->
                            navController.navigate("${NovaRoutes.CHAT}?conversationId=$id")
                        },
                        onStartNewChat = { navigateTopTab(NovaRoutes.CHAT) }
                    )
                }

                composable(NovaRoutes.SETTINGS) {
                    SettingsScreen(
                        appState = appState,
                        onOpenProfile = { navController.navigate(NovaRoutes.PROFILE) },
                        onOpenPersonality = { navController.navigate(NovaRoutes.PERSONALITY) },
                        onOpenOrbStyle = { navController.navigate(NovaRoutes.ORB_STYLE) },
                        onOpenPermissions = { navController.navigate(NovaRoutes.PERMISSIONS) },
                        onOpenPrivacy = { navController.navigate(NovaRoutes.PRIVACY) },
                        onOpenAbout = { navController.navigate(NovaRoutes.ABOUT) },
                        onOpenDebug = { navController.navigate(NovaRoutes.DEBUG) },
                        onOpenAccessibilityDisclosure = {
                            navController.navigate(FlavorRoutes.ACCESSIBILITY_DISCLOSURE)
                        }
                    )
                }

                composable(NovaRoutes.VOICE) {
                    VoiceScreen(
                        appState = appState,
                        onClose = { navController.popBackStack() },
                        onOpenSettings = { navigateTopTab(NovaRoutes.SETTINGS) }
                    )
                }

                composable(NovaRoutes.QUICK_ACTIONS) {
                    QuickActionsScreen(
                        onBack = { navController.popBackStack() },
                        onOpenForge = { navController.navigate(NovaRoutes.FORGE) },
                        onOpenVoice = { navController.navigate(NovaRoutes.VOICE) },
                        onOpenChat = { navigateTopTab(NovaRoutes.CHAT) },
                        onOpenPersonality = { navController.navigate(NovaRoutes.PERSONALITY) }
                    )
                }

                composable(NovaRoutes.PROFILE) {
                    ProfileScreen(
                        appState = appState,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NovaRoutes.PERSONALITY) {
                    PersonalityScreen(
                        appState = appState,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NovaRoutes.ORB_STYLE) {
                    OrbStyleScreen(
                        appState = appState,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NovaRoutes.PRIVACY) {
                    PrivacyScreen(
                        appState = appState,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NovaRoutes.PERMISSIONS) {
                    PermissionsScreen(onBack = { navController.popBackStack() })
                }

                composable(NovaRoutes.ABOUT) {
                    AboutScreen(
                        appState = appState,
                        onBack = { navController.popBackStack() },
                        onOpenDebug = { navController.navigate(NovaRoutes.DEBUG) }
                    )
                }

                composable(NovaRoutes.DEBUG) {
                    DebugScreen(
                        appState = appState,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NovaRoutes.FORGE) {
                    ForgeScreen(onBack = { navController.popBackStack() })
                }

                registerAccessibilityDisclosureRoute(navController)
            }
        }
    }
}
