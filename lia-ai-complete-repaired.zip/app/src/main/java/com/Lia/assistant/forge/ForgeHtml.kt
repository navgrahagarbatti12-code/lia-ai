package com.Lia.assistant.forge

object ForgeHtml {
    private const val SAFETY_NET_MARKER = "<!-- lia-forge-safety-net -->"

    private val FENCE_START = Regex("^\\s*```(?:html|HTML)?\\s*\\r?\\n?")
    private val FENCE_END = Regex("\\r?\\n?```\\s*$")

    fun stripFences(raw: String): String {
        var s = raw.trim()
        s = s.replace(FENCE_START, "")
        s = s.replace(FENCE_END, "")
        return s.trim()
    }

    fun looksLikeHtml(raw: String): Boolean {
        val lower = raw.trim().lowercase()
        if (lower.isEmpty()) return false
        return lower.contains("<!doctype html") ||
            lower.contains("<html") ||
            (lower.contains("<body") && lower.contains("<")) ||
            lower.contains("<section")
    }

    fun repairTruncated(raw: String): String {
        val trimmed = raw.trimEnd()
        val lower = trimmed.lowercase()
        val sb = StringBuilder(trimmed)

        val openScript = "<script".toRegex(RegexOption.IGNORE_CASE).findAll(lower).count()
        val closeScript = "</script>".toRegex(RegexOption.IGNORE_CASE).findAll(lower).count()
        if (openScript > closeScript) {
            sb.append("\n</script>")
        }

        val openStyle = "<style".toRegex(RegexOption.IGNORE_CASE).findAll(lower).count()
        val closeStyle = "</style>".toRegex(RegexOption.IGNORE_CASE).findAll(lower).count()
        if (openStyle > closeStyle) {
            sb.append("\n</style>")
        }

        if (!lower.contains("</body>")) {
            sb.append("\n</body>")
        }
        if (!lower.contains("</html>")) {
            sb.append("\n</html>")
        }
        return sb.toString()
    }

    fun withSafetyNet(html: String): String {
        if (html.contains(SAFETY_NET_MARKER)) return html
        val safetyScript = """
            $SAFETY_NET_MARKER
            <script>
            (function(){
              function revealStuck(){
                var vh = window.innerHeight || document.documentElement.clientHeight || 800;
                var nodes = document.querySelectorAll('section,header,footer,main,article,div');
                for (var i = 0; i < nodes.length; i++) {
                  var el = nodes[i];
                  if (el.tagName === 'CANVAS') continue;
                  if (el.getAttribute('aria-hidden') === 'true') continue;
                  var cs = window.getComputedStyle(el);
                  if (!cs) continue;
                  if (cs.position === 'fixed' || cs.pointerEvents === 'none') continue;
                  if (parseFloat(cs.opacity) < 0.05) {
                    var r = el.getBoundingClientRect();
                    if (r.top < vh * 1.15 && r.bottom > -40) {
                      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                      el.style.opacity = '1';
                      if (cs.transform && cs.transform !== 'none') {
                        el.style.transform = 'none';
                      }
                    }
                  }
                }
              }
              setTimeout(revealStuck, 1400);
            })();
            </script>
        """.trimIndent()

        val bodyCloseIdx = html.lastIndexOf("</body>", ignoreCase = true)
        return if (bodyCloseIdx >= 0) {
            html.substring(0, bodyCloseIdx) + "\n" + safetyScript + "\n" + html.substring(bodyCloseIdx)
        } else {
            html + "\n" + safetyScript
        }
    }
}
