package com.Lia.assistant.ui.screens.home

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Lia.assistant.data.NovaAppState
import com.Lia.assistant.license.AccessKeyBanner
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.fx.LiaOrb3D
import com.Lia.assistant.ui.fx.NovaOrbState
import com.Lia.assistant.ui.fx.rememberDeviceTilt
import com.Lia.assistant.ui.theme.LocalBottomBarInset
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.LocalNovaReducedMotion
import com.Lia.assistant.ui.theme.NovaMotion
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.depthSurface
import com.Lia.assistant.voice.VoiceSessionManager
import java.util.Calendar

private data class TrySayingPrompt(
    val title: String,
    val phrase: String,
    val opensForge: Boolean = false
)

@Composable
fun HomeScreen(
    appState: NovaAppState,
    onOpenVoice: () -> Unit,
    onOpenChat: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenQuickActions: () -> Unit,
    onTryForge: (String) -> Unit
) {
    val colors = LocalNovaColors.current
    val reducedMotion = LocalNovaReducedMotion.current
    val bottomInset = LocalBottomBarInset.current
    val tilt by rememberDeviceTilt()

    val liveState by VoiceSessionManager.state.collectAsState()
    val liveAmp by VoiceSessionManager.amplitude.collectAsState()

    val greeting = remember(appState.userName) {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val partOfDay = when {
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
        val cleanUser = appState.userName.trim()
        if (cleanUser.isNotEmpty()) "$partOfDay, $cleanUser" else partOfDay
    }

    val entrance = remember { Animatable(if (reducedMotion) 1f else 0f) }
    LaunchedEffect(reducedMotion) {
        if (reducedMotion) {
            entrance.snapTo(1f)
        } else {
            entrance.animateTo(1f, tween(NovaMotion.SLOW_MS))
        }
    }

    val tryList = remember {
        listOf(
            TrySayingPrompt("Build a Website", "\"Ek cafe ki website banao\"", opensForge = true),
            TrySayingPrompt("Hinglish Help", "\"Mera schedule plan kar do\""),
            TrySayingPrompt("Quick App Launch", "\"YouTube kholo\""),
            TrySayingPrompt("Brainstorm Ideas", "\"3 weekend trip ideas batao\"")
        )
    }
    val rowState = rememberLazyListState()

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(bottom = bottomInset)
    ) {
        val orbDiameter = (maxWidth * 0.55f).coerceIn(170.dp, 240.dp)
        val parallaxX = if (reducedMotion) 0f else tilt.x * 10f
        val parallaxY = if (reducedMotion) 0f else tilt.y * 8f

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(vertical = NovaSpacing.md),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header: floating logo + quick actions + profile circles
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = NovaSpacing.lg),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .depthSurface(shape = CircleShape, elevation = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = appState.assistantName,
                            tint = colors.accent
                        )
                    }
                    Spacer(Modifier.width(NovaSpacing.sm))
                    Text(
                        text = appState.assistantName,
                        style = MaterialTheme.typography.titleLarge,
                        color = colors.textPrimary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(NovaSpacing.sm)) {
                    IconButton(
                        onClick = onOpenQuickActions,
                        modifier = Modifier
                            .size(48.dp)
                            .depthSurface(shape = CircleShape, elevation = 6.dp)
                            .testTag("home_quick_actions_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Bolt,
                            contentDescription = "Quick Actions",
                            tint = colors.lagoon
                        )
                    }
                    IconButton(
                        onClick = onOpenProfile,
                        modifier = Modifier
                            .size(48.dp)
                            .depthSurface(shape = CircleShape, elevation = 6.dp)
                            .testTag("home_profile_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Person,
                            contentDescription = "Profile",
                            tint = colors.textPrimary
                        )
                    }
                }
            }

            Spacer(Modifier.height(NovaSpacing.lg))

            AccessKeyBanner(
                modifier = Modifier.padding(horizontal = NovaSpacing.lg, vertical = NovaSpacing.xs),
                onNavigateToProfile = onOpenProfile
            )

            Spacer(Modifier.height(NovaSpacing.md))

            // Time-based serif greeting
            Text(
                text = greeting,
                style = MaterialTheme.typography.displayMedium,
                color = colors.textPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(horizontal = NovaSpacing.lg)
                    .graphicsLayer {
                        alpha = entrance.value
                        translationY = (1f - entrance.value) * 16f
                    }
            )

            Spacer(Modifier.height(NovaSpacing.xl))

            // Layer 3 Hero Object: LiaOrb3D ~55% screen width
            Box(
                modifier = Modifier
                    .graphicsLayer {
                        translationX = parallaxX
                        translationY = parallaxY + (1f - entrance.value) * 20f
                        val sc = 0.9f + entrance.value * 0.1f
                        scaleX = sc
                        scaleY = sc
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onOpenVoice
                    )
                    .testTag("home_hero_orb"),
                contentAlignment = Alignment.Center
            ) {
                LiaOrb3D(
                    state = liveState,
                    size = orbDiameter,
                    amplitude = liveAmp,
                    style = appState.orbStyle,
                    assistantName = appState.assistantName
                )
            }

            Spacer(Modifier.height(NovaSpacing.sm))

            Text(
                text = if (liveState == NovaOrbState.IDLE) "Tap me to talk" else "Session active • Tap to open",
                style = MaterialTheme.typography.titleMedium.copy(fontStyle = FontStyle.Italic),
                color = colors.textSecondary
            )

            Spacer(Modifier.height(NovaSpacing.xl))

            // Layer 4 Floating Pill Actions: Talk + Type
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = NovaSpacing.xl),
                horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md)
            ) {
                NovaButton(
                    text = "Talk",
                    icon = Icons.Rounded.Mic,
                    onClick = onOpenVoice,
                    modifier = Modifier.weight(1f),
                    testTag = "home_talk_button"
                )
                NovaButton(
                    text = "Type",
                    style = NovaButtonStyle.SECONDARY,
                    icon = Icons.Rounded.Keyboard,
                    onClick = onOpenChat,
                    modifier = Modifier.weight(1f),
                    testTag = "home_type_button"
                )
            }

            Spacer(Modifier.height(NovaSpacing.xl))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = NovaSpacing.lg),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TRY SAYING",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.accent
                )
                Text(
                    text = appState.personality.displayName,
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textSecondary
                )
            }

            Spacer(Modifier.height(NovaSpacing.sm))

            // "Try saying" glass cards with +-6 degree scroll rotationY
            LazyRow(
                state = rowState,
                contentPadding = PaddingValues(horizontal = NovaSpacing.lg),
                horizontalArrangement = Arrangement.spacedBy(NovaSpacing.md)
            ) {
                itemsIndexed(tryList) { index, item ->
                    val tiltYDeg by remember(rowState, index, reducedMotion) {
                        derivedStateOf {
                            if (reducedMotion) 0f
                            else {
                                val info = rowState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
                                    ?: return@derivedStateOf 0f
                                val vpCenter = rowState.layoutInfo.viewportEndOffset / 2f
                                val itemCenter = info.offset + info.size / 2f
                                val norm = ((itemCenter - vpCenter) / vpCenter.coerceAtLeast(1f)).coerceIn(-1f, 1f)
                                norm * 6f
                            }
                        }
                    }

                    NovaGlassCard(
                        modifier = Modifier
                            .width(210.dp)
                            .graphicsLayer {
                                rotationY = tiltYDeg
                                cameraDistance = 14f * density
                            },
                        onClick = {
                            if (item.opensForge) {
                                onTryForge("Build a cozy artisanal cafe landing page")
                            } else {
                                onOpenVoice()
                            }
                        }
                    ) {
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.accent
                        )
                        Spacer(Modifier.height(NovaSpacing.xs))
                        Text(
                            text = item.phrase,
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.textPrimary
                        )
                    }
                }
            }

            Spacer(Modifier.height(NovaSpacing.xl))
        }
    }
}
