package com.Lia.assistant.ui.screens.forge

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.Lia.assistant.forge.ForgeController
import com.Lia.assistant.ui.components.NovaConfirmDialog
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaShapes
import com.Lia.assistant.ui.theme.NovaSpacing
import com.Lia.assistant.ui.theme.depthSurface
import kotlinx.coroutines.delay
import java.io.File
import java.text.DateFormat
import java.util.Date

@Composable
fun ResultToolbar(
    currentFile: File?,
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
    onRebuild: () -> Unit,
    onOpenSaved: (File) -> Unit,
    onDeletedCurrent: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current

    var toolbarVisible by remember { mutableStateOf(true) }
    var lastInteractionMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showListDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var editPrompt by remember { mutableStateOf("") }

    fun touch() {
        toolbarVisible = true
        lastInteractionMs = System.currentTimeMillis()
    }

    LaunchedEffect(toolbarVisible, lastInteractionMs, showEditDialog, showListDialog, showDeleteConfirm) {
        if (toolbarVisible && !showEditDialog && !showListDialog && !showDeleteConfirm) {
            delay(4000L)
            if (System.currentTimeMillis() - lastInteractionMs >= 3900L) {
                toolbarVisible = false
            }
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/html")
    ) { uri ->
        if (uri != null && currentFile != null && currentFile.exists()) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    currentFile.inputStream().use { inp -> inp.copyTo(out) }
                }
            }.onSuccess {
                Toast.makeText(context, "Website saved", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun shareFile() {
        val f = currentFile ?: return
        if (!f.exists()) return
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.forge.fileprovider", f)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/html"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Website"))
    }

    fun openInBrowser() {
        val f = currentFile ?: return
        if (!f.exists()) return
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.forge.fileprovider", f)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "text/html")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
            .onFailure { Toast.makeText(context, "No browser handler found", Toast.LENGTH_SHORT).show() }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(NovaSpacing.md)
    ) {
        if (toolbarVisible) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .depthSurface(shape = NovaShapes.pill, elevation = 12.dp)
                    .padding(horizontal = NovaSpacing.xs, vertical = NovaSpacing.xs),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                ToolbarAction(Icons.AutoMirrored.Rounded.ArrowBack, "Back") {
                    touch()
                    onBack()
                }
                ToolbarAction(Icons.Rounded.Share, "Share") {
                    touch()
                    shareFile()
                }
                ToolbarAction(Icons.Rounded.SaveAlt, "Save HTML") {
                    touch()
                    saveLauncher.launch(currentFile?.name ?: "website.html")
                }
                ToolbarAction(Icons.Rounded.OpenInBrowser, "Open in browser") {
                    touch()
                    openInBrowser()
                }
                ToolbarAction(Icons.Rounded.Edit, "Edit website") {
                    touch()
                    editPrompt = ""
                    showEditDialog = true
                }
                ToolbarAction(Icons.Rounded.Refresh, "Rebuild") {
                    touch()
                    onRebuild()
                }
                ToolbarAction(Icons.Rounded.FolderOpen, "My websites") {
                    touch()
                    showListDialog = true
                }
                ToolbarAction(Icons.Rounded.DeleteOutline, "Delete website", tint = colors.error) {
                    touch()
                    showDeleteConfirm = true
                }
            }
        }

        // Always-visible menu handle at bottom right
        IconButton(
            onClick = { touch() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(48.dp)
                .depthSurface(shape = CircleShape, elevation = 10.dp)
                .testTag("forge_toolbar_handle")
        ) {
            Icon(
                imageVector = Icons.Rounded.Menu,
                contentDescription = "Show Forge menu",
                tint = colors.accent
            )
        }
    }

    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            containerColor = colors.surfaceRaised,
            titleContentColor = colors.textPrimary,
            title = { Text("Edit Website", style = MaterialTheme.typography.titleLarge) },
            text = {
                NovaTextField(
                    value = editPrompt,
                    onValueChange = { editPrompt = it },
                    placeholder = "Describe the change (e.g., warmer palette, add pricing)",
                    singleLine = false,
                    maxLines = 3
                )
            },
            confirmButton = {
                TextButton(
                    enabled = editPrompt.isNotBlank(),
                    onClick = {
                        val req = editPrompt.trim()
                        showEditDialog = false
                        onEdit(req)
                    }
                ) {
                    Text("Apply", color = colors.accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            }
        )
    }

    if (showListDialog) {
        val saved = remember(showListDialog) { ForgeController.savedWebsites(context) }
        AlertDialog(
            onDismissRequest = { showListDialog = false },
            containerColor = colors.surfaceRaised,
            titleContentColor = colors.textPrimary,
            title = { Text("My Websites", style = MaterialTheme.typography.titleLarge) },
            text = {
                if (saved.isEmpty()) {
                    Text("No saved websites yet.", style = MaterialTheme.typography.bodyLarge, color = colors.textSecondary)
                } else {
                    LazyColumn(
                        modifier = Modifier.height(260.dp),
                        verticalArrangement = Arrangement.spacedBy(NovaSpacing.xs)
                    ) {
                        items(saved, key = { it.absolutePath }) { item ->
                            val dateStr = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                                .format(Date(item.lastModified()))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .defaultMinSize(minHeight = 48.dp)
                                    .clip(NovaShapes.small)
                                    .clickable {
                                        showListDialog = false
                                        onOpenSaved(item)
                                    }
                                    .padding(NovaSpacing.sm)
                            ) {
                                Text(
                                    text = item.nameWithoutExtension,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "$dateStr • ${item.length() / 1024} KB",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.textSecondary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showListDialog = false }) {
                    Text("Close", color = colors.accent)
                }
            }
        )
    }

    if (showDeleteConfirm && currentFile != null) {
        NovaConfirmDialog(
            title = "Delete Website?",
            message = "Remove ${currentFile.name} permanently?",
            confirmLabel = "Delete",
            isDestructive = true,
            onConfirm = {
                showDeleteConfirm = false
                ForgeController.deleteWebsite(currentFile)
                onDeletedCurrent()
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }
}

@Composable
private fun ToolbarAction(
    icon: ImageVector,
    label: String,
    tint: androidx.compose.ui.graphics.Color? = null,
    onClick: () -> Unit
) {
    val colors = LocalNovaColors.current
    IconButton(
        onClick = onClick,
        modifier = Modifier.size(44.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint ?: colors.textPrimary,
            modifier = Modifier.size(20.dp)
        )
    }
}
