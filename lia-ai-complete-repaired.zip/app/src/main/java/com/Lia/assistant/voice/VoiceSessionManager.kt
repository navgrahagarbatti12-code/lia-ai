package com.Lia.assistant.voice

import android.content.Context
import com.Lia.assistant.action.ActionExecutor
import com.Lia.assistant.action.InstalledAppLabelCache
import com.Lia.assistant.data.ApiKeyStore
import com.Lia.assistant.data.AssistantBrand
import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.NovaPreferences
import com.Lia.assistant.data.Personality
import com.Lia.assistant.data.PersonalityRepository
import com.Lia.assistant.forge.ForgeController
import com.Lia.assistant.license.AccessKeyManager
import com.Lia.assistant.ui.fx.NovaOrbState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicLong

object VoiceSessionManager {
    private const val MAX_RECONNECT_ATTEMPTS = 5
    private const val RECONNECT_DELAY_MS = 1200L
    private const val PLAYBACK_SILENCE_WATCHDOG_MS = 300L
    private const val VAD_THRESHOLD = 0.025f

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val connectMutex = Mutex()
    private val reconnectMutex = Mutex()
    private val epochCounter = AtomicLong(0L)

    private var appContext: Context? = null
    private var liveClient: GeminiLiveClient? = null
    private var audioIO: LiveAudioIO? = null
    private var micStarted = false
    private var inPlaybackTurn = false
    private var playbackWatchdogJob: Job? = null
    private var reconnectJob: Job? = null
    private var reconnectAttempts = 0

    private val _state = MutableStateFlow(NovaOrbState.IDLE)
    val state: StateFlow<NovaOrbState> = _state.asStateFlow()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted.asStateFlow()

    private val _statusText = MutableStateFlow("")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _isActive = MutableStateFlow(false)
    val isActive: StateFlow<Boolean> = _isActive.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _currentPersonality = MutableStateFlow(Personality.NORMAL)
    val currentPersonality: StateFlow<Personality> = _currentPersonality.asStateFlow()

    private val _currentLanguage = MutableStateFlow(LanguagePreference.AUTO)
    val currentLanguage: StateFlow<LanguagePreference> = _currentLanguage.asStateFlow()

    private val _detectedLanguage = MutableStateFlow(DetectedLanguage.UNKNOWN)
    val detectedLanguage: StateFlow<DetectedLanguage> = _detectedLanguage.asStateFlow()

    private val _vadActive = MutableStateFlow(false)
    val vadActive: StateFlow<Boolean> = _vadActive.asStateFlow()

    fun start(context: Context) {
        val ctx = context.applicationContext
        appContext = ctx

        if (_isActive.value) return

        if (!AccessKeyManager.isActive(ctx)) {
            _state.value = NovaOrbState.ERROR
            _lastError.value = "Access key is not active. Activate your key in Profile."
            _statusText.value = "Access key required"
            return
        }

        if (!ApiKeyStore.hasKey(ctx)) {
            _state.value = NovaOrbState.ERROR
            _lastError.value = "Add your Gemini API key in Settings to use Voice Mode."
            _statusText.value = "API key missing"
            return
        }

        _isActive.value = true
        _muted.value = false
        _lastError.value = null
        _amplitude.value = 0f
        _vadActive.value = false
        _detectedLanguage.value = DetectedLanguage.UNKNOWN
        _state.value = NovaOrbState.CONNECTING
        _statusText.value = "Connecting..."

        ConversationMemory.clear()
        VoiceLatencyTracker.reset()
        EchoGuard.reset()
        reconnectAttempts = 0
        micStarted = false
        inPlaybackTurn = false

        InstalledAppLabelCache.prewarm(ctx)

        val volume = NovaPreferences.getFloat(ctx, NovaPreferences.Keys.VOICE_VOLUME, 1.0f)
        audioIO?.release()
        audioIO = LiveAudioIO(
            onMicChunk = { pcm ->
                if (_isActive.value && !_muted.value && !EchoGuard.isMicMuted()) {
                    liveClient?.sendAudio(pcm)
                }
            },
            onMicAmplitude = { rms ->
                val activeSpeech = !_muted.value && !EchoGuard.isMicMuted() && rms > VAD_THRESHOLD
                _vadActive.value = activeSpeech
                if (_state.value == NovaOrbState.LISTENING && !_muted.value && !EchoGuard.isMicMuted()) {
                    _amplitude.value = rms
                }
            }
        ).apply {
            setVolume(volume)
        }

        ioScope.launch {
            connectMutex.withLock {
                if (_isActive.value) {
                    connectSession(ctx, isResuming = false)
                }
            }
        }
    }

    private suspend fun connectSession(context: Context, isResuming: Boolean) {
        val apiKey = ApiKeyStore.getKey(context)
        if (apiKey.isBlank()) {
            _state.value = NovaOrbState.ERROR
            _lastError.value = "Add your Gemini API key in Settings."
            _isActive.value = false
            return
        }

        val myEpoch = epochCounter.incrementAndGet()
        liveClient?.disconnect()
        liveClient = null
        playbackWatchdogJob?.cancel()
        if (inPlaybackTurn) {
            inPlaybackTurn = false
            EchoGuard.notifyPlaybackStopped()
        }

        val personality = PersonalityRepository.getPersonality(context)
        val language = PersonalityRepository.getLanguage(context)
        val assistantName = PersonalityRepository.getAssistantName(context)
        val uiVoiceName = PersonalityRepository.getVoiceName(context)

        _currentPersonality.value = personality
        _currentLanguage.value = language
        _state.value = NovaOrbState.CONNECTING
        _statusText.value = if (isResuming) "Reconnecting $assistantName..." else "Connecting $assistantName..."

        val recap = if (isResuming) ConversationMemory.recap() else null
        val prompt = PersonalityPromptBuilder.build(
            personality = personality,
            language = language,
            detectedLanguage = _detectedLanguage.value,
            recap = recap,
            assistantName = assistantName
        )

        val geminiVoice = mapGeminiVoice(uiVoiceName)

        val client = GeminiLiveClient(apiKey, object : GeminiLiveClient.Listener {
            override fun onSetupComplete() {
                if (epochCounter.get() != myEpoch || !_isActive.value) return
                reconnectAttempts = 0
                _lastError.value = null
                _state.value = NovaOrbState.LISTENING
                _statusText.value = "$assistantName is listening..."
                if (!micStarted) {
                    val started = audioIO?.startMic() == true
                    micStarted = started
                    if (!started) {
                        _lastError.value = "Unable to open microphone."
                        _state.value = NovaOrbState.ERROR
                    }
                }
            }

            override fun onAudioChunk(bytes: ByteArray) {
                if (epochCounter.get() != myEpoch || !_isActive.value) return
                if (!inPlaybackTurn) {
                    inPlaybackTurn = true
                    EchoGuard.notifyPlaybackStarted()
                    VoiceLatencyTracker.markFirstAudioByte()
                }
                val rms = audioIO?.playChunk(bytes) ?: 0f
                _state.value = NovaOrbState.SPEAKING
                _amplitude.value = rms
                _statusText.value = "$assistantName is speaking..."
                rearmPlaybackWatchdog(myEpoch, assistantName)
            }

            override fun onInputTranscript(text: String) {
                if (epochCounter.get() != myEpoch || !_isActive.value) return
                ConversationMemory.addUserTurn(text)
                VoiceLatencyTracker.markSpeechEnd()
                val detected = LanguageDetector.detect(text)
                if (detected != DetectedLanguage.UNKNOWN) {
                    _detectedLanguage.value = detected
                }
            }

            override fun onOutputTranscript(text: String) {
                if (epochCounter.get() != myEpoch || !_isActive.value) return
                ConversationMemory.addAssistantTurn(text)
            }

            override fun onToolCall(id: String, name: String, args: JSONObject) {
                if (epochCounter.get() != myEpoch || !_isActive.value) return
                _state.value = NovaOrbState.THINKING
                _statusText.value = "Working on it..."

                if (name == "build_website") {
                    val promptArg = args.optString("prompt", "").trim()
                    val result = ForgeController.start(context, promptArg)
                    val payload = JSONObject().put(
                        "result",
                        if (result == com.Lia.assistant.forge.ForgeStartResult.Started) {
                            "forge_started"
                        } else {
                            result.spokenMessage
                        }
                    )
                    if (epochCounter.get() == myEpoch) {
                        liveClient?.sendToolResponse(id, name, payload)
                    }
                    return
                }

                ioScope.launch {
                    VoiceLatencyTracker.markToolStart()
                    val result = runCatching {
                        ActionExecutor.execute(context, name, args)
                    }.getOrElse { err ->
                        JSONObject().put("error", err.message ?: "Action failed")
                    }
                    VoiceLatencyTracker.markToolEnd()
                    if (epochCounter.get() == myEpoch && _isActive.value) {
                        liveClient?.sendToolResponse(id, name, result)
                    }
                }
            }

            override fun onTurnComplete() {
                if (epochCounter.get() != myEpoch || !_isActive.value) return
                finishPlaybackTurn(myEpoch, assistantName)
                VoiceLatencyTracker.markTurnComplete()
            }

            override fun onInterrupted() {
                if (epochCounter.get() != myEpoch || !_isActive.value) return
                audioIO?.flushPlayback()
                finishPlaybackTurn(myEpoch, assistantName)
            }

            override fun onError(message: String) {
                if (epochCounter.get() != myEpoch || !_isActive.value) return
                _lastError.value = message
                scheduleReconnect(context)
            }

            override fun onClosed() {
                if (epochCounter.get() != myEpoch || !_isActive.value) return
                scheduleReconnect(context)
            }
        })

        liveClient = client
        client.connect(systemInstruction = prompt, voiceName = geminiVoice)
    }

    private fun rearmPlaybackWatchdog(epoch: Long, assistantName: String) {
        playbackWatchdogJob?.cancel()
        playbackWatchdogJob = ioScope.launch {
            delay(PLAYBACK_SILENCE_WATCHDOG_MS)
            if (epochCounter.get() == epoch && _isActive.value && inPlaybackTurn) {
                finishPlaybackTurn(epoch, assistantName)
            }
        }
    }

    private fun finishPlaybackTurn(epoch: Long, assistantName: String) {
        if (epochCounter.get() != epoch) return
        playbackWatchdogJob?.cancel()
        playbackWatchdogJob = null
        if (inPlaybackTurn) {
            inPlaybackTurn = false
            EchoGuard.notifyPlaybackStopped()
        }
        if (_isActive.value) {
            _state.value = NovaOrbState.LISTENING
            _amplitude.value = 0f
            _statusText.value = "$assistantName is listening..."
        }
    }

    private fun scheduleReconnect(context: Context) {
        ioScope.launch {
            reconnectMutex.withLock {
                if (!_isActive.value) return@withLock
                if (reconnectJob?.isActive == true) return@withLock

                reconnectJob = ioScope.launch {
                    if (!_isActive.value) return@launch
                    if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                        _state.value = NovaOrbState.ERROR
                        _lastError.value = "Connection lost - tap Stop and reopen Voice Mode"
                        _statusText.value = "Connection lost"
                        return@launch
                    }
                    reconnectAttempts++
                    VoiceLatencyTracker.incrementReconnectCount()
                    _state.value = NovaOrbState.CONNECTING
                    _statusText.value = "Reconnecting ($reconnectAttempts/$MAX_RECONNECT_ATTEMPTS)..."
                    delay(RECONNECT_DELAY_MS)
                    if (!_isActive.value) return@launch
                    connectMutex.withLock {
                        if (_isActive.value) {
                            connectSession(context, isResuming = true)
                        }
                    }
                }
            }
        }
    }

    fun refreshInstructions(context: Context) {
        val ctx = context.applicationContext
        appContext = ctx
        if (!_isActive.value) return
        ioScope.launch {
            connectMutex.withLock {
                if (_isActive.value) {
                    connectSession(ctx, isResuming = true)
                }
            }
        }
    }

    fun toggleMute() {
        val next = !_muted.value
        _muted.value = next
        if (next) {
            _vadActive.value = false
            if (_state.value == NovaOrbState.LISTENING) {
                _amplitude.value = 0f
            }
        }
    }

    fun stop() {
        epochCounter.incrementAndGet()
        reconnectJob?.cancel()
        reconnectJob = null
        playbackWatchdogJob?.cancel()
        playbackWatchdogJob = null

        liveClient?.disconnect()
        liveClient = null

        audioIO?.release()
        audioIO = null
        micStarted = false
        inPlaybackTurn = false

        EchoGuard.reset()
        ConversationMemory.clear()

        _isActive.value = false
        _muted.value = false
        _vadActive.value = false
        _amplitude.value = 0f
        _state.value = NovaOrbState.IDLE
        _statusText.value = ""
    }

    internal fun mapGeminiVoice(uiVoice: String): String {
        val normalized = uiVoice.trim()
        return when (normalized.lowercase()) {
            "aoede", "warm", "pearl" -> "Aoede"
            "kore", "clear", "bright" -> "Kore"
            "puck", "playful", "upbeat" -> "Puck"
            "charon", "deep", "calm" -> "Charon"
            "fenrir", "bold", "resonant" -> "Fenrir"
            "leda", "soft", "gentle" -> "Leda"
            "orus", "steady", "crisp" -> "Orus"
            "zephyr", "breezy", "light" -> "Zephyr"
            else -> if (normalized.isNotEmpty() && normalized in AVAILABLE_VOICES) {
                normalized
            } else {
                AssistantBrand.NAME.let { "Aoede" }
            }
        }
    }

    val AVAILABLE_VOICES = listOf("Aoede", "Kore", "Puck", "Charon", "Fenrir", "Leda", "Orus", "Zephyr")
}
