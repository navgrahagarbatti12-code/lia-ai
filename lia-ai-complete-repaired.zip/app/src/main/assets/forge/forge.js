import * as THREE from 'three';
import { EffectComposer } from './postprocessing/EffectComposer.js';
import { RenderPass } from './postprocessing/RenderPass.js';
import { UnrealBloomPass } from './postprocessing/UnrealBloomPass.js';
import { ShaderPass } from './postprocessing/ShaderPass.js';
import { OutputPass } from './postprocessing/OutputPass.js';

const GLYPHS = ['{', '}', '<', '>', '/', '=', ';', '(', ')', '0', '1', '#', '$', '*', '&', '%'];
const STAGE_LABELS = [
  'Igniting Forge',
  'Weaving Structure',
  'Sculpting Glass',
  'Choreographing Motion',
  'Rendering Visuals',
  'Final Polish'
];

const VignetteChromaShader = {
  uniforms: {
    tDiffuse: { value: null },
    uAbErr: { value: 0.0022 },
    uVignette: { value: 0.42 },
    uFlash: { value: 0.0 }
  },
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform float uAbErr;
    uniform float uVignette;
    uniform float uFlash;
    varying vec2 vUv;
    void main() {
      vec2 dir = vUv - vec2(0.5);
      float dist = length(dir);
      vec2 offset = dir * uAbErr * (0.5 + dist * 2.0);
      float r = texture2D(tDiffuse, vUv + offset).r;
      float g = texture2D(tDiffuse, vUv).g;
      float b = texture2D(tDiffuse, vUv - offset).b;
      vec3 col = vec3(r, g, b);
      float vig = smoothstep(0.95, 0.28, dist);
      col *= mix(1.0 - uVignette, 1.0, vig);
      col += vec3(1.0, 0.96, 0.9) * uFlash * 0.65;
      gl_FragColor = vec4(col, 1.0);
    }
  `
};

class ForgeReactor {
  constructor() {
    this.canvas = document.getElementById('forge-canvas');
    this.disposed = false;
    this.paused = false;
    this.reducedMotion = false;
    this.dirty = true;
    this.rafId = null;

    this.theme = {
      background: '#06050E',
      backgroundGradientTop: '#15113A',
      accent: '#FFB547',
      accentSecondary: '#FF8A3D',
      lagoon: '#3FE0D0',
      lotus: '#FF6FAE',
      textPrimary: '#EEE9FF',
      surfaceBorder: '#443E78',
      lowRam: false
    };

    this.state = {
      stage: 0,
      progress: 0.1,
      tokensPerSec: 0,
      sections: [],
      log: [],
      logSeq: 0,
      failed: false
    };

    this.revealActive = false;
    this.revealT = 0;
    this.revealCallbackSent = false;
    this.introT = 0;
    this.kickAmount = 0;
    this.lastLogSeq = -1;
    this.lastStage = 0;

    this.orbitYaw = 0;
    this.orbitPitch = 0.18;
    this.dragYaw = 0;
    this.dragPitch = 0;
    this.tiltX = 0;
    this.tiltY = 0;
    this.dragging = false;
    this.lastPointer = { x: 0, y: 0 };

    this.ripples = [];
    for (let i = 0; i < 6; i++) {
      this.ripples.push({ center: new THREE.Vector2(0, 0), start: -10, strength: 0 });
    }
    this.rippleCursor = 0;

    this.disposables = [];
    this.textures = [];
    this.fpsSamples = [];
    this.qualityScale = 1.0;
    this.lastTime = performance.now() * 0.001;
    this.elapsed = 0;
  }

  track(obj) {
    if (obj) this.disposables.push(obj);
    return obj;
  }

  trackTex(tex) {
    if (tex) this.textures.push(tex);
    return tex;
  }

  init(themeJson) {
    try {
      if (themeJson) {
        const parsed = typeof themeJson === 'string' ? JSON.parse(themeJson) : themeJson;
        Object.assign(this.theme, parsed || {});
      }
      this.reducedMotion = !!this.theme.reducedMotion;
      document.documentElement.style.background = this.theme.background;
      document.body.style.background = this.theme.background;

      const width = Math.max(1, window.innerWidth);
      const height = Math.max(1, window.innerHeight);

      this.renderer = new THREE.WebGLRenderer({
        canvas: this.canvas,
        antialias: !this.theme.lowRam,
        powerPreference: 'high-performance',
        alpha: false
      });
      const maxDpr = this.theme.lowRam ? 1.5 : 2.0;
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxDpr));
      this.renderer.setSize(width, height, false);
      this.renderer.setClearColor(new THREE.Color(this.theme.background), 1);
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.05;

      this.scene = new THREE.Scene();
      this.scene.fog = new THREE.FogExp2(this.theme.background, 0.022);

      this.camera = new THREE.PerspectiveCamera(48, width / height, 0.1, 160);
      this.camera.position.set(0, 8.5, 22);

      this.buildBackdrop();
      this.buildFloorGrid();
      this.buildReactorCore();
      this.buildGlyphParticles();
      this.buildBeamsAndShockwaves();
      this.buildGlassSlabs();
      this.buildStageRing();
      this.buildLogCards();
      this.buildDust();
      this.buildPostProcessing(width, height);
      this.bindEvents();

      this.spawnRipple(0, 0, 1.0);
      this.dirty = true;
      this.startLoop();

      if (window.ForgeBridge && window.ForgeBridge.onReady) {
        window.ForgeBridge.onReady();
      }
    } catch (err) {
      if (window.ForgeBridge && window.ForgeBridge.onWebGLFailed) {
        window.ForgeBridge.onWebGLFailed(String(err && err.message ? err.message : err));
      }
    }
  }

  color(hex) {
    return new THREE.Color(hex || '#FFFFFF');
  }

  buildBackdrop() {
    const geo = this.track(new THREE.SphereGeometry(72, 32, 24));
    const mat = this.track(new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uTime: { value: 0 },
        uBottom: { value: this.color(this.theme.background) },
        uTop: { value: this.color(this.theme.backgroundGradientTop) },
        uAccent: { value: this.color(this.theme.accent) },
        uLotus: { value: this.color(this.theme.lotus) },
        uLagoon: { value: this.color(this.theme.lagoon) }
      },
      vertexShader: `
        varying vec3 vPos;
        void main() {
          vPos = normalize(position);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform vec3 uBottom;
        uniform vec3 uTop;
        uniform vec3 uAccent;
        uniform vec3 uLotus;
        uniform vec3 uLagoon;
        varying vec3 vPos;

        float hash(vec3 p) {
          p = fract(p * 0.3183099 + 0.1);
          p *= 17.0;
          return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
        }

        void main() {
          float h = clamp(vPos.y * 0.5 + 0.5, 0.0, 1.0);
          vec3 base = mix(uBottom, uTop, smoothstep(0.08, 0.92, h));
          float neb1 = sin(vPos.x * 4.0 + uTime * 0.08) * cos(vPos.z * 3.5 - uTime * 0.06);
          float neb2 = sin(vPos.y * 5.0 - vPos.x * 2.5 + uTime * 0.05);
          base += uLotus * max(0.0, neb1) * 0.075;
          base += uLagoon * max(0.0, neb2) * 0.065;
          float star = step(0.9965, hash(floor(vPos * 120.0)));
          base += mix(uAccent, vec3(1.0), 0.7) * star * 0.65;
          gl_FragColor = vec4(base, 1.0);
        }
      `
    }));
    this.backdropMat = mat;
    this.scene.add(new THREE.Mesh(geo, mat));
  }

  buildFloorGrid() {
    const geo = this.track(new THREE.PlaneGeometry(46, 46, 1, 1));
    geo.rotateX(-Math.PI / 2);
    const mat = this.track(new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: {
        uTime: { value: 0 },
        uLagoon: { value: this.color(this.theme.lagoon) },
        uAccent: { value: this.color(this.theme.accent) },
        uBorder: { value: this.color(this.theme.surfaceBorder) },
        uRipple0: { value: new THREE.Vector4(0, 0, -10, 0) },
        uRipple1: { value: new THREE.Vector4(0, 0, -10, 0) },
        uRipple2: { value: new THREE.Vector4(0, 0, -10, 0) },
        uRipple3: { value: new THREE.Vector4(0, 0, -10, 0) },
        uRipple4: { value: new THREE.Vector4(0, 0, -10, 0) },
        uRipple5: { value: new THREE.Vector4(0, 0, -10, 0) }
      },
      vertexShader: `
        varying vec3 vWorld;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorld = wp.xyz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform vec3 uLagoon;
        uniform vec3 uAccent;
        uniform vec3 uBorder;
        uniform vec4 uRipple0;
        uniform vec4 uRipple1;
        uniform vec4 uRipple2;
        uniform vec4 uRipple3;
        uniform vec4 uRipple4;
        uniform vec4 uRipple5;
        varying vec3 vWorld;

        float evalRipple(vec4 r, vec2 p) {
          float age = uTime - r.z;
          if (age < 0.0 || age > 2.6 || r.w <= 0.0) return 0.0;
          float rad = age * 7.5;
          float ring = exp(-abs(length(p - r.xy) - rad) * 2.1);
          return ring * (1.0 - age / 2.6) * r.w;
        }

        void main() {
          vec2 coord = vWorld.xz * 0.75;
          vec2 grid = abs(fract(coord - 0.5) - 0.5) / fwidth(coord);
          float line = 1.0 - min(min(grid.x, grid.y), 1.0);
          float dist = length(vWorld.xz);
          float fade = exp(-dist * 0.11);
          float rip = evalRipple(uRipple0, vWorld.xz)
                    + evalRipple(uRipple1, vWorld.xz)
                    + evalRipple(uRipple2, vWorld.xz)
                    + evalRipple(uRipple3, vWorld.xz)
                    + evalRipple(uRipple4, vWorld.xz)
                    + evalRipple(uRipple5, vWorld.xz);
          vec3 col = mix(uBorder, uLagoon, 0.35) * line * 0.45 * fade;
          col += uAccent * rip * 0.9 * fade;
          float alpha = clamp((line * 0.35 + rip * 0.65) * fade, 0.0, 0.85);
          gl_FragColor = vec4(col, alpha);
        }
      `
    }));
    this.floorMat = mat;
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.y = -3.6;
    this.scene.add(mesh);
  }

  buildReactorCore() {
    this.coreGroup = new THREE.Group();
    this.scene.add(this.coreGroup);

    const sphereGeo = this.track(new THREE.SphereGeometry(1.32, 48, 36));
    this.coreMat = this.track(new THREE.ShaderMaterial({
      transparent: true,
      uniforms: {
        uTime: { value: 0 },
        uPower: { value: 0.2 },
        uCore: { value: this.color(this.theme.accent) },
        uRim: { value: this.color(this.theme.lotus) },
        uLagoon: { value: this.color(this.theme.lagoon) }
      },
      vertexShader: `
        varying vec3 vNormal;
        varying vec3 vView;
        varying vec3 vPos;
        void main() {
          vPos = position;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vNormal = normalize(normalMatrix * normal);
          vView = normalize(-mv.xyz);
          gl_Position = projectionMatrix * mv;
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform float uPower;
        uniform vec3 uCore;
        uniform vec3 uRim;
        uniform vec3 uLagoon;
        varying vec3 vNormal;
        varying vec3 vView;
        varying vec3 vPos;
        void main() {
          float fresnel = pow(1.0 - max(dot(vNormal, vView), 0.0), 2.4);
          float pulse = 0.5 + 0.5 * sin(vPos.y * 4.5 - uTime * 3.0 + vPos.x * 2.5);
          vec3 interior = mix(uCore, uLagoon, pulse * 0.45);
          vec3 col = interior * (0.55 + uPower * 0.75) + uRim * fresnel * (1.25 + uPower * 0.6);
          gl_FragColor = vec4(col, 0.92);
        }
      `
    }));
    this.coreSphere = new THREE.Mesh(sphereGeo, this.coreMat);
    this.coreGroup.add(this.coreSphere);

    const wireGeo = this.track(new THREE.IcosahedronGeometry(1.62, 1));
    const wireMat = this.track(new THREE.MeshBasicMaterial({
      color: this.color(this.theme.lagoon),
      wireframe: true,
      transparent: true,
      opacity: 0.36
    }));
    this.wireMesh = new THREE.Mesh(wireGeo, wireMat);
    this.coreGroup.add(this.wireMesh);

    this.gyroRings = [];
    const ringColors = [this.theme.accent, this.theme.lotus, this.theme.lagoon];
    for (let i = 0; i < 3; i++) {
      const rGeo = this.track(new THREE.TorusGeometry(2.05 + i * 0.34, 0.032, 12, 72));
      const rMat = this.track(new THREE.MeshBasicMaterial({
        color: this.color(ringColors[i]),
        transparent: true,
        opacity: 0.72,
        blending: THREE.AdditiveBlending,
        depthWrite: false
      }));
      const ring = new THREE.Mesh(rGeo, rMat);
      ring.rotation.set(i * 0.9, i * 0.6, 0);
      this.coreGroup.add(ring);
      this.gyroRings.push(ring);
    }

    const haloCanvas = document.createElement('canvas');
    haloCanvas.width = 128;
    haloCanvas.height = 128;
    const hCtx = haloCanvas.getContext('2d');
    const grad = hCtx.createRadialGradient(64, 64, 4, 64, 64, 64);
    grad.addColorStop(0, 'rgba(255,255,255,0.9)');
    grad.addColorStop(0.35, 'rgba(255,181,71,0.45)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    hCtx.fillStyle = grad;
    hCtx.fillRect(0, 0, 128, 128);
    const haloTex = this.trackTex(new THREE.CanvasTexture(haloCanvas));
    const haloMat = this.track(new THREE.SpriteMaterial({
      map: haloTex,
      color: this.color(this.theme.accent),
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    }));
    this.coreHalo = new THREE.Sprite(haloMat);
    this.coreHalo.scale.set(6.4, 6.4, 1);
    this.coreGroup.add(this.coreHalo);
  }

  buildGlyphParticles() {
    const count = 1800;
    const atlas = document.createElement('canvas');
    atlas.width = 512;
    atlas.height = 512;
    const ctx = atlas.getContext('2d');
    ctx.clearRect(0, 0, 512, 512);
    ctx.font = 'bold 84px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#FFFFFF';
    for (let i = 0; i < 16; i++) {
      const gx = (i % 4) * 128 + 64;
      const gy = Math.floor(i / 4) * 128 + 64;
      ctx.fillText(GLYPHS[i], gx, gy);
    }
    const atlasTex = this.trackTex(new THREE.CanvasTexture(atlas));

    const geo = this.track(new THREE.BufferGeometry());
    const pos = new Float32Array(count * 3);
    const aRadius = new Float32Array(count);
    const aAngle = new Float32Array(count);
    const aSpeed = new Float32Array(count);
    const aGlyph = new Float32Array(count);
    const aTint = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      aRadius[i] = 3.2 + Math.random() * 11.5;
      aAngle[i] = Math.random() * Math.PI * 2;
      aSpeed[i] = 0.45 + Math.random() * 0.9;
      aGlyph[i] = i % 16;
      aTint[i] = Math.random();
      pos[i * 3] = 0;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 4.5;
      pos[i * 3 + 2] = 0;
    }

    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aRadius', new THREE.BufferAttribute(aRadius, 1));
    geo.setAttribute('aAngle', new THREE.BufferAttribute(aAngle, 1));
    geo.setAttribute('aSpeed', new THREE.BufferAttribute(aSpeed, 1));
    geo.setAttribute('aGlyph', new THREE.BufferAttribute(aGlyph, 1));
    geo.setAttribute('aTint', new THREE.BufferAttribute(aTint, 1));

    this.glyphMat = this.track(new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      uniforms: {
        uTime: { value: 0 },
        uSpeedMul: { value: 1.0 },
        uBurst: { value: 0.0 },
        uAtlas: { value: atlasTex },
        uAccent: { value: this.color(this.theme.accent) },
        uLagoon: { value: this.color(this.theme.lagoon) },
        uLotus: { value: this.color(this.theme.lotus) }
      },
      vertexShader: `
        attribute float aRadius;
        attribute float aAngle;
        attribute float aSpeed;
        attribute float aGlyph;
        attribute float aTint;
        uniform float uTime;
        uniform float uSpeedMul;
        uniform float uBurst;
        varying float vGlyph;
        varying float vAlpha;
        varying float vTint;
        void main() {
          float life = fract(aSpeed * 0.14 * uTime * uSpeedMul + aRadius * 0.05);
          float r = mix(aRadius, 1.5, life) + uBurst * (6.5 + aRadius * 0.4);
          float theta = aAngle + uTime * aSpeed * 0.38 * uSpeedMul + (1.0 - life) * 1.4;
          vec3 p = vec3(cos(theta) * r, position.y * (1.0 - life * 0.65), sin(theta) * r);
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = clamp(240.0 / max(-mv.z, 1.0), 8.0, 26.0);
          vGlyph = aGlyph;
          vAlpha = sin(life * 3.14159) * 0.78;
          vTint = aTint;
        }
      `,
      fragmentShader: `
        uniform sampler2D uAtlas;
        uniform vec3 uAccent;
        uniform vec3 uLagoon;
        uniform vec3 uLotus;
        varying float vGlyph;
        varying float vAlpha;
        varying float vTint;
        void main() {
          float idx = floor(vGlyph + 0.5);
          vec2 cell = vec2(mod(idx, 4.0), 3.0 - floor(idx / 4.0));
          vec2 uv = (cell + vec2(gl_PointCoord.x, 1.0 - gl_PointCoord.y)) / 4.0;
          float mask = texture2D(uAtlas, uv).a;
          if (mask < 0.08) discard;
          vec3 c = vTint < 0.33 ? uAccent : (vTint < 0.66 ? uLagoon : uLotus);
          gl_FragColor = vec4(c, mask * vAlpha);
        }
      `
    }));

    this.glyphPoints = new THREE.Points(geo, this.glyphMat);
    this.scene.add(this.glyphPoints);
  }

  buildBeamsAndShockwaves() {
    this.beams = [];
    const beamGeo = this.track(new THREE.CylinderGeometry(0.025, 0.025, 1.0, 6));
    for (let i = 0; i < 22; i++) {
      const mat = this.track(new THREE.MeshBasicMaterial({
        color: this.color(i % 2 === 0 ? this.theme.lagoon : this.theme.accent),
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false
      }));
      const mesh = new THREE.Mesh(beamGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.beams.push({ mesh, mat, life: 0, maxLife: 0.7, start: new THREE.Vector3(), end: new THREE.Vector3() });
    }

    const shockCanvas = document.createElement('canvas');
    shockCanvas.width = 128;
    shockCanvas.height = 128;
    const sCtx = shockCanvas.getContext('2d');
    sCtx.strokeStyle = '#FFFFFF';
    sCtx.lineWidth = 8;
    sCtx.beginPath();
    sCtx.arc(64, 64, 52, 0, Math.PI * 2);
    sCtx.stroke();
    const shockTex = this.trackTex(new THREE.CanvasTexture(shockCanvas));

    this.shockwaves = [];
    for (let i = 0; i < 4; i++) {
      const mat = this.track(new THREE.SpriteMaterial({
        map: shockTex,
        color: this.color(i % 2 === 0 ? this.theme.accent : this.theme.lagoon),
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false
      }));
      const sprite = new THREE.Sprite(mat);
      sprite.visible = false;
      this.scene.add(sprite);
      this.shockwaves.push({ sprite, mat, age: 99, maxAge: 1.2 });
    }
  }

  buildGlassSlabs() {
    this.slabs = [];
    this.slabGroup = new THREE.Group();
    this.scene.add(this.slabGroup);

    for (let i = 0; i < 10; i++) {
      const geo = this.track(new THREE.PlaneGeometry(2.35, 1.48));
      const mat = this.track(new THREE.ShaderMaterial({
        transparent: true,
        side: THREE.DoubleSide,
        depthWrite: false,
        uniforms: {
          uBirth: { value: 0.0 },
          uStyled: { value: 0.0 },
          uMotion: { value: 0.0 },
          uTime: { value: 0.0 },
          uIsHero: { value: i === 0 ? 1.0 : 0.0 },
          uBg: { value: this.color(this.theme.backgroundGradientTop) },
          uBorder: { value: this.color(this.theme.rimLight || this.theme.textPrimary) },
          uAccent: { value: this.color(this.theme.accent) },
          uLagoon: { value: this.color(this.theme.lagoon) },
          uLotus: { value: this.color(this.theme.lotus) }
        },
        vertexShader: `
          varying vec2 vUv;
          void main() {
            vUv = uv;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          uniform float uBirth;
          uniform float uStyled;
          uniform float uMotion;
          uniform float uTime;
          uniform float uIsHero;
          uniform vec3 uBg;
          uniform vec3 uBorder;
          uniform vec3 uAccent;
          uniform vec3 uLagoon;
          uniform vec3 uLotus;
          varying vec2 vUv;

          float roundedBox(vec2 p, vec2 b, float r) {
            vec2 q = abs(p) - b + r;
            return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
          }

          void main() {
            if (uBirth <= 0.01) discard;
            vec2 p = vUv - 0.5;
            float sdf = roundedBox(p, vec2(0.47, 0.45), 0.07);
            if (sdf > 0.0) discard;

            float scanCutoff = 1.0 - uBirth;
            if (vUv.y < scanCutoff) discard;
            float scanLine = exp(-abs(vUv.y - scanCutoff) * 42.0) * (1.0 - smoothstep(0.85, 1.0, uBirth));

            float rim = smoothstep(-0.028, 0.0, sdf);
            vec3 fill = uBg * 1.15;

            if (uStyled > 0.5) {
              float bar1 = smoothstep(0.03, 0.0, abs(vUv.y - 0.62)) * step(0.14, vUv.x) * step(vUv.x, 0.72);
              float bar2 = smoothstep(0.024, 0.0, abs(vUv.y - 0.44)) * step(0.14, vUv.x) * step(vUv.x, 0.58);
              float bar3 = smoothstep(0.024, 0.0, abs(vUv.y - 0.28)) * step(0.14, vUv.x) * step(vUv.x, 0.82);
              fill += uLagoon * bar1 * 0.48 + uBorder * (bar2 + bar3) * 0.26;
            }

            if (uIsHero > 0.5) {
              float d1 = smoothstep(0.025, 0.015, length(vUv - vec2(0.14, 0.84)));
              float d2 = smoothstep(0.025, 0.015, length(vUv - vec2(0.22, 0.84)));
              float d3 = smoothstep(0.025, 0.015, length(vUv - vec2(0.30, 0.84)));
              fill += uLotus * d1 + uAccent * d2 + uLagoon * d3;
            }

            if (uMotion > 0.5) {
              float shimmer = exp(-abs((vUv.x + vUv.y * 0.4) - mod(uTime * 0.65, 2.2)) * 8.0);
              fill += uAccent * shimmer * 0.25;
            }

            vec3 col = mix(fill, uBorder, rim * 0.78) + uAccent * scanLine * 0.9;
            float alpha = clamp((0.68 + rim * 0.28) * uBirth, 0.0, 0.94);
            gl_FragColor = vec4(col, alpha);
          }
        `
      }));

      const angle = (i / 10) * Math.PI * 2;
      const radius = 5.4 + (i % 2) * 1.1;
      const y = ((i % 3) - 1) * 1.15;
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(Math.cos(angle) * radius, y, Math.sin(angle) * radius);
      mesh.lookAt(0, y * 0.3, 0);
      mesh.visible = false;
      this.slabGroup.add(mesh);
      this.slabs.push({
        mesh,
        mat,
        baseAngle: angle,
        baseRadius: radius,
        baseY: y,
        active: false,
        birth: 0,
        driftOffset: new THREE.Vector3((Math.random() - 0.5) * 4, (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 4)
      });
    }
  }

  buildStageRing() {
    this.stageGroup = new THREE.Group();
    this.stageGroup.position.y = -2.25;
    this.scene.add(this.stageGroup);

    const arcGeo = this.track(new THREE.RingGeometry(4.15, 4.24, 96));
    arcGeo.rotateX(-Math.PI / 2);
    this.stageArcMat = this.track(new THREE.ShaderMaterial({
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false,
      uniforms: {
        uProgress: { value: 0.1 },
        uAccent: { value: this.color(this.theme.accent) },
        uBorder: { value: this.color(this.theme.surfaceBorder) }
      },
      vertexShader: `
        varying vec3 vPos;
        void main() {
          vPos = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform float uProgress;
        uniform vec3 uAccent;
        uniform vec3 uBorder;
        varying vec3 vPos;
        void main() {
          float ang = atan(vPos.z, vPos.x);
          float norm = fract((ang + 1.570796) / 6.283185);
          float lit = step(norm, uProgress);
          vec3 col = mix(uBorder, uAccent, lit);
          float alpha = mix(0.28, 0.9, lit);
          gl_FragColor = vec4(col, alpha);
        }
      `
    }));
    this.stageGroup.add(new THREE.Mesh(arcGeo, this.stageArcMat));

    this.stageNodes = [];
    const nodeGeo = this.track(new THREE.SphereGeometry(0.16, 16, 16));
    for (let i = 0; i < 6; i++) {
      const mat = this.track(new THREE.MeshBasicMaterial({
        color: this.color(this.theme.surfaceBorder),
        transparent: true,
        opacity: 0.85
      }));
      const node = new THREE.Mesh(nodeGeo, mat);
      const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
      node.position.set(Math.cos(a) * 4.2, 0, Math.sin(a) * 4.2);
      this.stageGroup.add(node);

      const labelCanvas = document.createElement('canvas');
      labelCanvas.width = 256;
      labelCanvas.height = 64;
      const lCtx = labelCanvas.getContext('2d');
      lCtx.font = 'bold 24px sans-serif';
      lCtx.textAlign = 'center';
      lCtx.textBaseline = 'middle';
      lCtx.fillStyle = this.theme.textPrimary;
      lCtx.fillText(STAGE_LABELS[i], 128, 32);
      const labelTex = this.trackTex(new THREE.CanvasTexture(labelCanvas));
      const labelMat = this.track(new THREE.SpriteMaterial({ map: labelTex, transparent: true, opacity: 0.55 }));
      const sprite = new THREE.Sprite(labelMat);
      sprite.position.set(Math.cos(a) * 4.95, 0.25, Math.sin(a) * 4.95);
      sprite.scale.set(1.85, 0.46, 1);
      this.stageGroup.add(sprite);

      this.stageNodes.push({ node, mat, labelMat });
    }
  }

  buildLogCards() {
    this.logCards = [];
    for (let i = 0; i < 4; i++) {
      const c = document.createElement('canvas');
      c.width = 512;
      c.height = 112;
      const tex = this.trackTex(new THREE.CanvasTexture(c));
      const mat = this.track(new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0.0 }));
      const sprite = new THREE.Sprite(mat);
      const side = i % 2 === 0 ? -1 : 1;
      sprite.position.set(side * (4.8 + (i % 2) * 0.6), 2.5 - i * 0.9, -2.5 - i * 0.5);
      sprite.scale.set(3.2, 0.72, 1);
      sprite.visible = false;
      this.scene.add(sprite);
      this.logCards.push({ canvas: c, ctx: c.getContext('2d'), tex, mat, sprite, text: '' });
    }
  }

  redrawLogCard(card, text) {
    if (card.text === text) return;
    card.text = text;
    const ctx = card.ctx;
    ctx.clearRect(0, 0, 512, 112);
    if (!text) {
      card.sprite.visible = false;
      return;
    }
    card.sprite.visible = true;
    ctx.fillStyle = 'rgba(23, 20, 58, 0.74)';
    ctx.strokeStyle = 'rgba(238, 233, 255, 0.28)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(6, 6, 500, 100, 22);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = this.theme.accent;
    ctx.beginPath();
    ctx.arc(36, 56, 8, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = this.theme.textPrimary;
    ctx.font = '600 28px sans-serif';
    ctx.textBaseline = 'middle';
    const clipped = text.length > 30 ? text.slice(0, 29) + '…' : text;
    ctx.fillText(clipped, 58, 56);
    card.tex.needsUpdate = true;
    card.mat.opacity = 0.88;
  }

  buildDust() {
    const count = 220;
    const geo = this.track(new THREE.BufferGeometry());
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 30;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 16;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 30;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = this.track(new THREE.PointsMaterial({
      color: this.color(this.theme.textPrimary),
      size: 0.06,
      transparent: true,
      opacity: 0.32,
      depthWrite: false
    }));
    this.dust = new THREE.Points(geo, mat);
    this.scene.add(this.dust);
  }

  buildPostProcessing(width, height) {
    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));

    const bloomRes = new THREE.Vector2(Math.max(1, Math.floor(width / 2)), Math.max(1, Math.floor(height / 2)));
    this.bloomPass = new UnrealBloomPass(bloomRes, 0.36, 0.42, 0.55);
    this.composer.addPass(this.bloomPass);

    this.vignettePass = new ShaderPass(VignetteChromaShader);
    this.composer.addPass(this.vignettePass);

    this.composer.addPass(new OutputPass());
  }

  spawnRipple(x, z, strength) {
    const r = this.ripples[this.rippleCursor % this.ripples.length];
    this.rippleCursor++;
    r.center.set(x, z);
    r.start = this.elapsed;
    r.strength = strength;
  }

  spawnShockwave(colorHex) {
    const sw = this.shockwaves.find(s => s.age >= s.maxAge) || this.shockwaves[0];
    sw.age = 0;
    sw.mat.color.set(colorHex || this.theme.accent);
    sw.mat.opacity = 0.9;
    sw.sprite.scale.set(1.2, 1.2, 1);
    sw.sprite.visible = true;
  }

  spawnBeam() {
    const beam = this.beams.find(b => b.life <= 0);
    if (!beam) return;
    const activeSlabs = this.slabs.filter(s => s.active);
    const target = activeSlabs.length ? activeSlabs[Math.floor(Math.random() * activeSlabs.length)].mesh.position : new THREE.Vector3(Math.cos(Math.random() * 6.28) * 5, 0, Math.sin(Math.random() * 6.28) * 5);
    beam.start.set(0, 0, 0);
    beam.end.copy(target);
    beam.life = beam.maxLife;
    beam.mesh.visible = true;
  }

  update(stateJson) {
    try {
      const next = typeof stateJson === 'string' ? JSON.parse(stateJson) : stateJson;
      if (!next) return;
      const prevStage = this.state.stage;
      Object.assign(this.state, next);

      if (this.state.stage > prevStage) {
        this.kickAmount = 1.0;
        this.spawnShockwave(this.theme.accent);
        this.spawnRipple(0, 0, 1.0);
        for (let i = 0; i < 4; i++) this.spawnBeam();
      }

      if (this.state.logSeq !== this.lastLogSeq) {
        this.lastLogSeq = this.state.logSeq;
        this.spawnBeam();
        const logs = Array.isArray(this.state.log) ? this.state.log.slice(-4) : [];
        for (let i = 0; i < 4; i++) {
          this.redrawLogCard(this.logCards[i], logs[i] || '');
        }
      }

      const desiredSlabs = Math.min(10, Math.max(1, (this.state.sections ? this.state.sections.length : 0) + (this.state.stage >= 1 ? 1 : 0)));
      for (let i = 0; i < this.slabs.length; i++) {
        if (i < desiredSlabs && !this.slabs[i].active) {
          this.slabs[i].active = true;
          this.slabs[i].mesh.visible = true;
          this.spawnRipple(this.slabs[i].mesh.position.x, this.slabs[i].mesh.position.z, 0.7);
        }
        this.slabs[i].mat.uniforms.uStyled.value = this.state.stage >= 2 ? 1.0 : 0.0;
        this.slabs[i].mat.uniforms.uMotion.value = this.state.stage >= 3 ? 1.0 : 0.0;
      }

      this.stageArcMat.uniforms.uProgress.value = Math.max(0.05, Math.min(1.0, this.state.progress || 0.1));
      for (let i = 0; i < 6; i++) {
        const done = i <= this.state.stage;
        const active = i === this.state.stage;
        this.stageNodes[i].mat.color.set(done ? this.theme.accent : this.theme.surfaceBorder);
        this.stageNodes[i].labelMat.opacity = active ? 1.0 : (done ? 0.78 : 0.35);
      }

      this.dirty = true;
    } catch (_) {}
  }

  reveal() {
    if (this.revealActive) return;
    this.revealActive = true;
    this.revealT = 0;
    this.revealCallbackSent = false;
    this.spawnShockwave(this.theme.lotus);
    this.spawnRipple(0, 0, 1.3);
    this.dirty = true;
    if (this.reducedMotion) {
      this.finishReveal();
    }
  }

  finishReveal() {
    if (this.revealCallbackSent) return;
    this.revealCallbackSent = true;
    if (window.ForgeBridge && window.ForgeBridge.onRevealFinished) {
      window.ForgeBridge.onRevealFinished();
    }
  }

  fail(msg) {
    this.state.failed = true;
    this.canvas.classList.add('failed');
    this.coreMat.uniforms.uPower.value = 0.05;
    this.dirty = true;
  }

  setReducedMotion(flag) {
    this.reducedMotion = !!flag;
    this.dirty = true;
  }

  bindEvents() {
    this._onResize = () => {
      if (this.disposed) return;
      const w = Math.max(1, window.innerWidth);
      const h = Math.max(1, window.innerHeight);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h, false);
      this.composer.setSize(w, h);
      this.dirty = true;
    };
    window.addEventListener('resize', this._onResize);

    this._onVisibility = () => {
      this.paused = document.hidden;
      if (!this.paused) {
        this.lastTime = performance.now() * 0.001;
        this.dirty = true;
      }
    };
    document.addEventListener('visibilitychange', this._onVisibility);

    this._onPointerDown = (e) => {
      this.dragging = true;
      this.lastPointer.x = e.clientX;
      this.lastPointer.y = e.clientY;
    };
    this._onPointerMove = (e) => {
      if (!this.dragging) return;
      const dx = e.clientX - this.lastPointer.x;
      const dy = e.clientY - this.lastPointer.y;
      this.lastPointer.x = e.clientX;
      this.lastPointer.y = e.clientY;
      this.dragYaw += dx * 0.004;
      this.dragPitch = Math.max(-0.35, Math.min(0.45, this.dragPitch + dy * 0.003));
      this.dirty = true;
    };
    this._onPointerUp = () => {
      this.dragging = false;
    };
    this.canvas.addEventListener('pointerdown', this._onPointerDown);
    window.addEventListener('pointermove', this._onPointerMove);
    window.addEventListener('pointerup', this._onPointerUp);

    this._onOrient = (e) => {
      if (this.reducedMotion) return;
      if (e.gamma != null && e.beta != null) {
        this.tiltX = Math.max(-1, Math.min(1, e.gamma / 35));
        this.tiltY = Math.max(-1, Math.min(1, (e.beta - 45) / 35));
      }
    };
    window.addEventListener('deviceorientation', this._onOrient);
  }

  startLoop() {
    const tick = (nowMs) => {
      if (this.disposed) return;
      this.rafId = requestAnimationFrame(tick);
      if (this.paused) return;

      const now = nowMs * 0.001;
      const rawDt = Math.min(0.05, Math.max(0.001, now - this.lastTime));
      this.lastTime = now;

      if (this.reducedMotion) {
        if (!this.dirty) return;
        this.dirty = false;
        this.step(0.016);
        this.composer.render();
        return;
      }

      this.elapsed += rawDt;
      this.adaptQuality(rawDt);
      this.step(rawDt);
      this.composer.render();
    };
    this.rafId = requestAnimationFrame(tick);
  }

  adaptQuality(dt) {
    this.fpsSamples.push(1 / dt);
    if (this.fpsSamples.length < 30) return;
    const avg = this.fpsSamples.reduce((a, b) => a + b, 0) / this.fpsSamples.length;
    this.fpsSamples.length = 0;
    if (avg < 36 && this.qualityScale > 0.72) {
      this.qualityScale = 0.72;
      this.renderer.setPixelRatio(1.0);
    }
  }

  step(dt) {
    this.introT = Math.min(1.0, this.introT + dt / 2.0);
    const introEase = 1 - Math.pow(1 - this.introT, 3);
    const power = Math.min(1.0, 0.18 + (this.state.progress || 0) * 0.6 + Math.min(0.35, (this.state.tokensPerSec || 0) / 140));

    this.backdropMat.uniforms.uTime.value = this.elapsed;
    this.floorMat.uniforms.uTime.value = this.elapsed;
    for (let i = 0; i < 6; i++) {
      const r = this.ripples[i];
      this.floorMat.uniforms[`uRipple${i}`].value.set(r.center.x, r.center.y, r.start, r.strength);
    }

    this.coreMat.uniforms.uTime.value = this.elapsed;
    this.coreMat.uniforms.uPower.value = this.state.failed ? 0.05 : power;
    const coreScale = 1.0 + Math.sin(this.elapsed * 2.4) * 0.04 + power * 0.08;
    this.coreSphere.scale.setScalar(coreScale);
    this.wireMesh.rotation.y += dt * (0.35 + power * 0.8);
    this.wireMesh.rotation.x += dt * 0.2;
    this.gyroRings.forEach((ring, idx) => {
      ring.rotation.x += dt * (0.4 + idx * 0.25) * (0.6 + power);
      ring.rotation.y += dt * (0.55 - idx * 0.15) * (0.6 + power);
    });

    this.glyphMat.uniforms.uTime.value = this.elapsed;
    this.glyphMat.uniforms.uSpeedMul.value = this.state.failed ? 0.15 : (0.75 + power * 1.45);

    this.bloomPass.strength = 0.34 + power * 0.14;

    if (this.kickAmount > 0) {
      this.kickAmount = Math.max(0, this.kickAmount - dt * 2.4);
    }

    // Slabs update
    const slabOrbitSpeed = this.state.failed ? 0.02 : 0.14;
    for (let i = 0; i < this.slabs.length; i++) {
      const s = this.slabs[i];
      if (!s.active) continue;
      s.birth = Math.min(1.0, s.birth + dt * 1.4);
      s.mat.uniforms.uBirth.value = s.birth;
      s.mat.uniforms.uTime.value = this.elapsed;

      if (this.revealActive) {
        const k = Math.min(1.0, this.revealT / 1.5);
        s.mesh.position.lerp(new THREE.Vector3(0, 0.3, 6.5), k * 0.16);
        s.mesh.lookAt(this.camera.position);
      } else if (this.state.failed) {
        s.mesh.position.addScaledVector(s.driftOffset, dt * 0.35);
      } else {
        const a = s.baseAngle + this.elapsed * slabOrbitSpeed;
        const y = s.baseY + Math.sin(this.elapsed * 1.2 + i) * 0.18;
        s.mesh.position.set(Math.cos(a) * s.baseRadius, y, Math.sin(a) * s.baseRadius);
        s.mesh.lookAt(0, y * 0.25, 0);
      }
    }

    // Beams update
    for (const b of this.beams) {
      if (b.life <= 0) continue;
      b.life -= dt;
      if (b.life <= 0) {
        b.mesh.visible = false;
        continue;
      }
      const dir = b.end.clone().sub(b.start);
      const len = dir.length();
      b.mesh.position.copy(b.start).addScaledVector(dir, 0.5);
      b.mesh.scale.set(1, len, 1);
      b.mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
      b.mat.opacity = Math.sin((b.life / b.maxLife) * Math.PI) * 0.85;
    }

    // Shockwaves update
    for (const sw of this.shockwaves) {
      if (sw.age >= sw.maxAge) continue;
      sw.age += dt;
      if (sw.age >= sw.maxAge) {
        sw.sprite.visible = false;
        continue;
      }
      const p = sw.age / sw.maxAge;
      const sc = 1.4 + p * 14.0;
      sw.sprite.scale.set(sc, sc, 1);
      sw.mat.opacity = (1.0 - p) * 0.85;
    }

    // Reveal sequence (~1.5 s)
    if (this.revealActive) {
      this.revealT += dt;
      const p = Math.min(1.0, this.revealT / 1.5);
      this.glyphMat.uniforms.uBurst.value = p;
      this.vignettePass.uniforms.uFlash.value = Math.sin(p * Math.PI);
      this.camera.fov = 48 + Math.sin(p * Math.PI) * 14;
      this.camera.position.z = 11.2 - p * 4.5;
      this.camera.updateProjectionMatrix();
      if (p >= 1.0) {
        this.finishReveal();
      }
    } else {
      const targetDist = 11.4 + (1 - introEase) * 12.0 - this.kickAmount * 0.9;
      this.orbitYaw += dt * 0.08;
      const yaw = this.orbitYaw + this.dragYaw + this.tiltX * 0.22;
      const pitch = this.orbitPitch + this.dragPitch + this.tiltY * 0.14;
      const shakeX = this.kickAmount > 0 ? (Math.random() - 0.5) * this.kickAmount * 0.18 : 0;
      const shakeY = this.kickAmount > 0 ? (Math.random() - 0.5) * this.kickAmount * 0.18 : 0;

      this.camera.position.set(
        Math.sin(yaw) * Math.cos(pitch) * targetDist + shakeX,
        Math.sin(pitch) * targetDist + 2.2 + (1 - introEase) * 4.0 + shakeY,
        Math.cos(yaw) * Math.cos(pitch) * targetDist
      );
      this.camera.fov = 48 + this.kickAmount * 4.5;
      this.camera.updateProjectionMatrix();
      this.camera.lookAt(0, 0.2, 0);
    }
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    if (this.rafId !== null) cancelAnimationFrame(this.rafId);
    window.removeEventListener('resize', this._onResize);
    document.removeEventListener('visibilitychange', this._onVisibility);
    this.canvas?.removeEventListener('pointerdown', this._onPointerDown);
    window.removeEventListener('pointermove', this._onPointerMove);
    window.removeEventListener('pointerup', this._onPointerUp);
    window.removeEventListener('deviceorientation', this._onOrient);

    this.disposables.forEach(d => { try { d.dispose?.(); } catch (_) {} });
    this.textures.forEach(t => { try { t.dispose?.(); } catch (_) {} });
    try { this.composer?.dispose?.(); } catch (_) {}
    try { this.renderer?.dispose?.(); } catch (_) {}
  }
}

const reactor = new ForgeReactor();
window.Forge = {
  init: (themeJson) => reactor.init(themeJson),
  update: (stateJson) => reactor.update(stateJson),
  reveal: () => reactor.reveal(),
  fail: (msg) => reactor.fail(msg),
  setReducedMotion: (flag) => reactor.setReducedMotion(flag),
  dispose: () => reactor.dispose()
};
