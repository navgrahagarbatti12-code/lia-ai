package com.Lia.assistant.action

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.Lia.assistant.voice.LiaToolCatalog
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DirectActionExecutorTest {

    @Test
    fun directToolCatalog_exposesAccessibilityTools() {
        val decls = LiaToolCatalog.declarations()
        val names = (0 until decls.length()).map { decls.getJSONObject(it).getString("name") }.toSet()
        assertTrue(names.contains("read_screen"))
        assertTrue(names.contains("tap_text"))
        assertTrue(names.contains("type_text"))
        assertTrue(names.contains("scroll_screen"))
        assertTrue(names.contains("go_back"))
        assertTrue(names.contains("go_home"))
    }

    @Test
    fun directActionExecutor_blocksWithoutActiveAccessKey() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val result = ActionExecutor.execute(context, "read_screen", JSONObject())
        assertTrue(result.has("error"))
    }
}
