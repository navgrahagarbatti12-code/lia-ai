package com.Lia.assistant.license

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AccessKeyRulesTest {

    @Test
    fun evaluate_handlesActiveExpiredBlockedAndEmptyPlan() {
        val now = 1_000_000L

        val active = AccessKeyRules.evaluate("Pro", now + 50_000L, blocked = false, nowMs = now)
        assertTrue(active.active)
        assertFalse(active.expired)
        assertTrue(active.statusText.contains("Pro"))

        val lifetime = AccessKeyRules.evaluate("Lifetime", 0L, blocked = false, nowMs = now)
        assertTrue(lifetime.active)

        val expired = AccessKeyRules.evaluate("Monthly", now - 10L, blocked = false, nowMs = now)
        assertFalse(expired.active)
        assertTrue(expired.expired)

        val blocked = AccessKeyRules.evaluate("Pro", now + 50_000L, blocked = true, nowMs = now)
        assertFalse(blocked.active)
        assertTrue(blocked.statusText.contains("blocked", ignoreCase = true))

        val emptyPlan = AccessKeyRules.evaluate("", 0L, blocked = false, nowMs = now)
        assertFalse(emptyPlan.active)
        assertEquals("Not activated", emptyPlan.statusText)
    }
}
