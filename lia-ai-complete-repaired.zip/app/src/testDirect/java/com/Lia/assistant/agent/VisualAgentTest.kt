package com.Lia.assistant.agent

import com.Lia.assistant.agent.core.ActionResult
import com.Lia.assistant.agent.core.CapturedScreen
import com.Lia.assistant.agent.core.DriverResult
import com.Lia.assistant.agent.core.DriverStatus
import com.Lia.assistant.agent.core.FailureReason
import com.Lia.assistant.agent.core.ScreenDriver
import com.Lia.assistant.agent.core.ScreenObservation
import com.Lia.assistant.agent.core.ScreenObserver
import com.Lia.assistant.agent.core.UiActionExecutor
import com.Lia.assistant.agent.core.UiElement
import com.Lia.assistant.agent.social.ControlCommand
import com.Lia.assistant.agent.social.Platform
import com.Lia.assistant.agent.social.SocialAction
import com.Lia.assistant.agent.social.SocialMediaAgent
import com.Lia.assistant.agent.social.SocialTaskRequest
import com.Lia.assistant.agent.social.TaskMode
import com.Lia.assistant.agent.social.TaskState
import com.Lia.assistant.agent.social.TaskStateMachine
import com.Lia.assistant.agent.social.TaskStatus
import com.Lia.assistant.agent.whatsapp.WhatsAppAgent
import com.Lia.assistant.agent.whatsapp.WhatsAppContactMatch
import com.Lia.assistant.agent.whatsapp.WhatsAppNotificationStore
import com.Lia.assistant.agent.whatsapp.WhatsAppUnreadItem
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class FakeScreenDriver(
    private val screens: MutableList<CapturedScreen>
) : ScreenDriver {
    private var idx = 0
    var currentStamp: Long = 100L
        private set
    val clickedLabels = mutableListOf<String>()
    var forceStaleOnNextClick = false

    override suspend fun capture(): CapturedScreen? {
        if (screens.isEmpty()) return null
        val screen = screens[idx.coerceAtMost(screens.lastIndex)]
        currentStamp = screen.windowStamp
        return screen
    }

    override suspend fun clickElement(observation: ScreenObservation, element: UiElement): DriverResult {
        if (forceStaleOnNextClick || observation.windowStamp != currentStamp) {
            return DriverResult(DriverStatus.STALE, "Stale observation")
        }
        clickedLabels += element.label
        if (idx < screens.lastIndex) {
            idx++
            currentStamp = screens[idx].windowStamp
        }
        return DriverResult(DriverStatus.OK)
    }

    override suspend fun gestureTap(x: Float, y: Float): DriverResult = DriverResult(DriverStatus.OK)

    override suspend fun setText(observation: ScreenObservation, element: UiElement, text: String): DriverResult {
        if (observation.windowStamp != currentStamp) return DriverResult(DriverStatus.STALE)
        val next = screens[idx].copy(
            elements = screens[idx].elements.map {
                if (it.id == element.id) it.copy(text = text) else it
            }
        )
        screens[idx] = next
        return DriverResult(DriverStatus.OK)
    }

    override suspend fun scroll(direction: String): DriverResult = DriverResult(DriverStatus.OK)
    override suspend fun back(): DriverResult = DriverResult(DriverStatus.OK)
    override suspend fun home(): DriverResult = DriverResult(DriverStatus.OK)
}

class VisualAgentTest {

    @Test
    fun stateMachine_enforcesLegalIllegalAndTerminalTransitions() {
        val sm = TaskStateMachine()
        sm.moveTo(TaskState.OPENING_APP)
        sm.moveTo(TaskState.OBSERVING)
        sm.moveTo(TaskState.RESOLVING_TARGET)
        sm.moveTo(TaskState.VALIDATING_TARGET)
        sm.moveTo(TaskState.WAITING_FOR_CONFIRMATION)
        sm.moveTo(TaskState.EXECUTING_ACTION)
        sm.moveTo(TaskState.VERIFYING)
        sm.moveTo(TaskState.COMPLETED)

        assertTrue(sm.current.isTerminal)
        // Terminal state must never exit
        try {
            sm.moveTo(TaskState.OBSERVING)
            fail("Expected terminal transition to throw")
        } catch (_: IllegalStateException) {
        }

        val illegalSm = TaskStateMachine()
        try {
            illegalSm.moveTo(TaskState.EXECUTING_ACTION)
            fail("Expected illegal transition IDLE -> EXECUTING_ACTION to throw")
        } catch (_: IllegalStateException) {
        }

        // FAILED and CANCELLED reachable from any non-terminal state
        val cancelSm = TaskStateMachine()
        cancelSm.moveTo(TaskState.OPENING_APP)
        cancelSm.moveTo(TaskState.CANCELLED)
        assertEquals(TaskState.CANCELLED, cancelSm.current)
    }

    @Test
    fun socialAgent_pausesOnBlockerAndResumes() = runTest {
        val blockerScreen = CapturedScreen(
            packageName = "com.instagram.android",
            windowClass = "LoginActivity",
            elements = listOf(UiElement("1", text = "Log in to continue")),
            screenWidth = 1080,
            screenHeight = 2400,
            windowStamp = 1L
        )
        val driver = FakeScreenDriver(mutableListOf(blockerScreen))
        val agent = SocialMediaAgent(driver)
        val req = SocialTaskRequest(Platform.INSTAGRAM, SocialAction.CREATE_STORY, "content://media/1", null, TaskMode.PUBLISH, null)

        val report = agent.startTask(req)
        assertEquals(TaskStatus.WAITING_FOR_USER, report.status)
        assertEquals(TaskState.WAITING_FOR_USER, report.machineState)
        assertTrue(report.message.contains("LOGIN"))
    }

    @Test
    fun socialAgent_draftModeNeverPublishesAndPublishRequiresExplicitConfirm() = runTest {
        val draftScreens = mutableListOf(
            CapturedScreen("com.facebook.katana", "Feed", listOf(UiElement("1", text = "What's on your mind", clickable = true)), 1080, 2400, 1L),
            CapturedScreen(
                "com.facebook.katana",
                "Composer",
                listOf(
                    UiElement("2", text = "", editable = true, viewId = "composer_edit"),
                    UiElement("3", text = "Save draft", clickable = true)
                ),
                1080,
                2400,
                2L
            ),
            CapturedScreen("com.facebook.katana", "DraftSaved", listOf(UiElement("4", text = "Draft saved")), 1080, 2400, 4L)
        )
        val draftDriver = FakeScreenDriver(draftScreens)
        val draftAgent = SocialMediaAgent(draftDriver)
        val draftReq = SocialTaskRequest(Platform.FACEBOOK, SocialAction.TEXT_POST, null, "Hello world", TaskMode.DRAFT, null)
        val draftReport = draftAgent.startTask(draftReq)
        assertEquals(TaskStatus.COMPLETED, draftReport.status)
        assertTrue(draftDriver.clickedLabels.none { it.equals("Post", ignoreCase = true) })

        val publishScreens = mutableListOf(
            CapturedScreen("com.facebook.katana", "Feed", listOf(UiElement("1", text = "What's on your mind", clickable = true)), 1080, 2400, 10L),
            CapturedScreen(
                "com.facebook.katana",
                "Composer",
                listOf(
                    UiElement("2", text = "", editable = true),
                    UiElement("3", text = "Post", clickable = true)
                ),
                1080,
                2400,
                11L
            ),
            CapturedScreen("com.facebook.katana", "UnknownScreen", listOf(UiElement("4", text = "Loading...")), 1080, 2400, 13L)
        )
        val publishDriver = FakeScreenDriver(publishScreens)
        val publishAgent = SocialMediaAgent(publishDriver)
        val publishReq = SocialTaskRequest(Platform.FACEBOOK, SocialAction.TEXT_POST, null, "Live post", TaskMode.PUBLISH, null)

        val waitConfirm = publishAgent.startTask(publishReq)
        assertEquals(TaskStatus.WAITING_FOR_CONFIRMATION, waitConfirm.status)

        // Confirm WITHOUT prior user yes must be refused
        val refused = publishAgent.control(ControlCommand.CONFIRM, waitConfirm.taskId, userExplicitlySaidYes = false)
        assertEquals(TaskStatus.WAITING_FOR_CONFIRMATION, refused.status)
        assertTrue(refused.message.contains("Refused"))

        // Confirm WITH explicit yes executes and reports SUBMITTED_UNVERIFIED when confirmation screen missing
        val done = publishAgent.control(ControlCommand.CONFIRM, waitConfirm.taskId, userExplicitlySaidYes = true)
        assertEquals(TaskStatus.SUBMITTED_UNVERIFIED, done.status)
    }

    @Test
    fun staleObservation_isRejectedByUiActionExecutor() = runTest {
        val screen = CapturedScreen("pkg", "cls", listOf(UiElement("1", text = "Next", clickable = true)), 1080, 2400, 50L)
        val driver = FakeScreenDriver(mutableListOf(screen))
        val observer = ScreenObserver(driver)
        val obs = observer.observe()!!
        driver.forceStaleOnNextClick = true

        val result = UiActionExecutor(driver, observer).clickAndVerify(obs, obs.elements.first())
        assertTrue(result is ActionResult.Failed)
        assertEquals(FailureReason.STALE_OBSERVATION, (result as ActionResult.Failed).reason)
    }

    @Test
    fun whatsappAgent_readsUnreadWithoutOpeningAppAndFailsOnAmbiguousContact() = runTest {
        WhatsAppNotificationStore.clear()
        WhatsAppNotificationStore.record(WhatsAppUnreadItem("k1", "Mummy", "Khana kha liya?", 1000L))

        val driver = FakeScreenDriver(mutableListOf())
        val agent = WhatsAppAgent(
            driver = driver,
            contactFinder = { query ->
                if (query.equals("Rahul", ignoreCase = true)) {
                    listOf(
                        WhatsAppContactMatch("Rahul Sharma", "+919800000001"),
                        WhatsAppContactMatch("Rahul Verma", "+919800000002")
                    )
                } else emptyList()
            }
        )

        val unread = agent.execute(JSONObject().put("action", "READ_UNREAD"))
        assertEquals(1, unread.getInt("count"))
        assertEquals(0, driver.clickedLabels.size)

        val ambiguous = agent.execute(
            JSONObject().put("action", "SEND_MESSAGE").put("contact", "Rahul").put("message", "Hi")
        )
        assertEquals("contact_ambiguous", ambiguous.getString("status"))
    }
}
