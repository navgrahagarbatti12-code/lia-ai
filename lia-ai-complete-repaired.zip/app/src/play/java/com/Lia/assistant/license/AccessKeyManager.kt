package com.Lia.assistant.license

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class LicenseInfo(
    val active: Boolean = true,
    val plan: String = "play",
    val expiresAt: Long = Long.MAX_VALUE,
    val statusText: String = "",
    val blocked: Boolean = false,
    val hasRememberedKey: Boolean = false
)

object AccessKeyManager {
    private val _info = MutableStateFlow(LicenseInfo())
    val info: StateFlow<LicenseInfo> = _info.asStateFlow()

    fun refreshInfo(context: Context) = Unit
    suspend fun activate(context: Context, key: String): Result<LicenseInfo> = Result.success(_info.value)
    suspend fun liveCheck(context: Context) = Unit
    fun isActive(context: Context): Boolean = true
}

@Composable
fun AccessKeyBanner(modifier: Modifier = Modifier, onNavigateToProfile: () -> Unit = {}) = Unit

@Composable
fun AccessKeySection(modifier: Modifier = Modifier) = Unit
