package com.Lia.assistant.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController

object FlavorRoutes {
    const val ACCESSIBILITY_DISCLOSURE = "accessibility_disclosure"
}

fun NavGraphBuilder.registerAccessibilityDisclosureRoute(navController: NavHostController) = Unit

@Composable
fun AccessibilitySettingsRows(onOpenDisclosure: () -> Unit) = Unit
