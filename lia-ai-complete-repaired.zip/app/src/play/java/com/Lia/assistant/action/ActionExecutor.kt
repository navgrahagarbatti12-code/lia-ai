package com.Lia.assistant.action

import android.content.Context
import org.json.JSONObject

object ActionExecutor {
    suspend fun execute(context: Context, name: String, args: JSONObject): JSONObject {
        return when (name) {
            "open_app" -> handleOpenApp(context, args)
            "call_contact" -> handleCallContact(context, args)
            "message_contact" -> handleMessageContact(context, args)
            else -> JSONObject().put("error", "Unknown tool: $name")
        }
    }

    private suspend fun handleOpenApp(context: Context, args: JSONObject): JSONObject {
        val appName = args.optString("app_name", args.optString("app", "")).trim()
        if (appName.isEmpty()) {
            return JSONObject().put("status", "missing_app_name")
        }
        return when (val result = AppLauncher.findAndLaunch(context, appName)) {
            is AppLauncher.LaunchResult.Launched ->
                JSONObject().put("status", "opened").put("package", result.packageName)
            is AppLauncher.LaunchResult.NotFound ->
                JSONObject().put("status", "app_not_found").put("query", result.query)
            is AppLauncher.LaunchResult.Failed ->
                JSONObject().put("status", "failed").put("reason", result.reason)
        }
    }

    private fun handleCallContact(context: Context, args: JSONObject): JSONObject {
        val target = args.optString("contact", args.optString("target", "")).trim()
        if (target.isEmpty()) {
            return JSONObject().put("status", "missing_contact")
        }
        return when (val lookup = ContactResolver.lookup(context, target)) {
            is ContactResolver.LookupResult.Found -> {
                val status = CommIntents.placeCall(context, lookup.phoneNumber)
                JSONObject()
                    .put("status", status)
                    .put("contact", lookup.displayName)
            }
            ContactResolver.LookupResult.NoPermission ->
                JSONObject().put("status", "no_contacts_permission")
            ContactResolver.LookupResult.NotFound ->
                JSONObject().put("status", "contact_not_found")
        }
    }

    private fun handleMessageContact(context: Context, args: JSONObject): JSONObject {
        val target = args.optString("contact", args.optString("target", "")).trim()
        val message = args.optString("message", args.optString("text", "")).trim()
        val channel = args.optString("channel", "sms").trim().lowercase()
        if (target.isEmpty()) {
            return JSONObject().put("status", "missing_contact")
        }
        return when (val lookup = ContactResolver.lookup(context, target)) {
            is ContactResolver.LookupResult.Found -> {
                val opened = if (channel == "whatsapp" || channel == "wa") {
                    CommIntents.openWhatsAppComposer(context, lookup.phoneNumber, message)
                } else {
                    CommIntents.openSmsComposer(context, lookup.phoneNumber, message)
                }
                if (opened) {
                    JSONObject()
                        .put("status", "composer_opened")
                        .put("contact", lookup.displayName)
                } else {
                    JSONObject().put("status", "composer_failed")
                }
            }
            ContactResolver.LookupResult.NoPermission ->
                JSONObject().put("status", "no_contacts_permission")
            ContactResolver.LookupResult.NotFound ->
                JSONObject().put("status", "contact_not_found")
        }
    }
}
