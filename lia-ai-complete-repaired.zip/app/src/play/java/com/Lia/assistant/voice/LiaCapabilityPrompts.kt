package com.Lia.assistant.voice

object LiaCapabilityPrompts {
    fun toolInstruction(assistantName: String): String =
        "Phone capabilities for $assistantName: You can open installed apps, place calls or open the dialer, " +
            "prepare an SMS or WhatsApp message in the composer for the user to tap Send, and launch the Website Forge. " +
            "You cannot read the screen, tap/type/scroll inside other apps, send messages silently without the user tapping Send, or post to social media apps — " +
            "if asked to do those, politely explain that screen control is not available in this Play version."
}
