package com.Lia.assistant.voice

import org.json.JSONArray

object LiaToolCatalog {
    fun declarations(): JSONArray = JSONArray().apply {
        put(
            functionDecl(
                name = "open_app",
                description = "Open an installed app on the user's phone by name.",
                params = mapOf("app_name" to "App name such as YouTube, Camera, Settings, WhatsApp"),
                required = listOf("app_name")
            )
        )
        put(
            functionDecl(
                name = "call_contact",
                description = "Place a phone call or open the dialer for a contact name or phone number.",
                params = mapOf("contact" to "Contact name or phone number"),
                required = listOf("contact")
            )
        )
        put(
            functionDecl(
                name = "message_contact",
                description = "Open an SMS or WhatsApp message composer pre-filled for a contact so the user can tap Send.",
                params = mapOf(
                    "contact" to "Contact name or phone number",
                    "message" to "Message body to pre-fill",
                    "channel" to "sms or whatsapp"
                ),
                required = listOf("contact", "message")
            )
        )
        put(
            functionDecl(
                name = "build_website",
                description = "Open the 3D Website Forge and generate a complete animated website from the user's description.",
                params = mapOf("prompt" to "Detailed website topic and user requirements"),
                required = listOf("prompt")
            )
        )
    }
}
