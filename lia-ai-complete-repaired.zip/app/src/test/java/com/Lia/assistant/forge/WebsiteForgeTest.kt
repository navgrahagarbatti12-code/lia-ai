package com.Lia.assistant.forge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WebsiteForgeTest {

    @Test
    fun sseParser_extractsTextMultiPartErrorsFinishReasonAndDone() {
        assertTrue(SseParser.isDoneLine("data: [DONE]"))
        assertTrue(SseParser.isDoneLine("[DONE]"))
        assertNull(SseParser.extractDataJson("data: [DONE]"))
        assertNull(SseParser.extractDataJson(": keep-alive"))

        val single = SseParser.extractDataJson(
            """data: {"candidates":[{"content":{"parts":[{"text":"<h1>Hi</h1>"},{"text":"<p>Cafe</p>"}]},"finishReason":"STOP"}]}"""
        )
        assertNotNull(single)
        assertEquals("<h1>Hi</h1><p>Cafe</p>", SseParser.extractText(single!!))
        assertEquals("STOP", SseParser.extractFinishReason(single))
        assertNull(SseParser.extractError(single))

        val errJson = SseParser.extractDataJson("""data: {"error":{"code":503,"message":"The model is overloaded."}}""")
        assertNotNull(errJson)
        assertEquals("The model is overloaded.", SseParser.extractError(errJson!!))
    }

    @Test
    fun forgeHtml_stripsFences_checksLooksLikeHtml_andRepairsTruncated() {
        val fenced = "```html\n<!DOCTYPE html><html><body><h1>Test</h1></body></html>\n```"
        val clean = ForgeHtml.stripFences(fenced)
        assertTrue(clean.startsWith("<!DOCTYPE html>"))
        assertFalse(clean.contains("```"))
        assertTrue(ForgeHtml.looksLikeHtml(clean))
        assertFalse(ForgeHtml.looksLikeHtml("Sure, here is an explanation about HTML."))

        val truncated = "<!DOCTYPE html><html><head><style>.a{}</style></head><body><section>Hero</section><script>console.log(1)"
        val repaired = ForgeHtml.repairTruncated(truncated)
        assertTrue(repaired.contains("</script>"))
        assertTrue(repaired.contains("</body>"))
        assertTrue(repaired.contains("</html>"))
    }

    @Test
    fun forgeHtml_safetyNet_isIdempotent() {
        val base = "<!DOCTYPE html><html><body><h1>Cafe</h1></body></html>"
        val once = ForgeHtml.withSafetyNet(base)
        val twice = ForgeHtml.withSafetyNet(once)
        assertEquals(once, twice)
        assertTrue(once.contains("revealStuck"))
    }

    @Test
    fun stageDetector_keepsHeadAtStart_andDetectsCanvasAsVisuals() {
        val headOnly = "<!DOCTYPE html><html><head><style>body{color:white;}</style><script src=\"https://cdn.tailwindcss.com\"></script></head>"
        assertEquals(ForgeStage.SPARK, ForgeStageDetector.detect(headOnly))

        val structured = "$headOnly<body><header id=\"hero-section\">Hero</header>"
        assertEquals(ForgeStage.STYLING, ForgeStageDetector.detect(structured))

        val withMotion = "$structured<script>gsap.from('.card',{opacity:0})</script>"
        assertEquals(ForgeStage.MOTION, ForgeStageDetector.detect(withMotion))

        val withCanvas = "$withMotion<canvas id=\"scene\"></canvas>"
        assertEquals(ForgeStage.VISUALS, ForgeStageDetector.detect(withCanvas))

        val polished = "$withCanvas<footer>Footer</footer></body></html>"
        assertEquals(ForgeStage.POLISH, ForgeStageDetector.detect(polished))
    }

    @Test
    fun stageDetector_extractsCleanSectionNames() {
        val html = """
            <body>
              <header data-section="hero_banner"><h1>Roastery</h1></header>
              <section id="signature-menu">Menu</section>
              <footer aria-label="contact_footer">Contact</footer>
            </body>
        """.trimIndent()
        val names = ForgeStageDetector.extractSectionNames(html)
        assertEquals(listOf("Hero Banner", "Signature Menu", "Contact Footer"), names)
    }

    @Test
    fun websiteForgeClient_mapsOverloadToRetryableFriendlyMessage() {
        val (msg503, retry503) = WebsiteForgeClient.mapFriendlyError(503, "UNAVAILABLE")
        assertTrue(retry503)
        assertTrue(msg503.contains("busy", ignoreCase = true))

        val (msg401, retry401) = WebsiteForgeClient.mapFriendlyError(401, "API key invalid")
        assertFalse(retry401)
        assertTrue(msg401.contains("API key", ignoreCase = true))
    }

    @Test
    fun forgeIntent_matchesCommandsAndIgnoresQuestions() {
        assertNotNull(ForgeIntent.extract("Lia, ek cafe ki website banao"))
        assertNotNull(ForgeIntent.extract("Create a landing page for my design studio"))
        assertNotNull(ForgeIntent.extract("Website bana do coffee shop ke liye"))

        assertNull(ForgeIntent.extract("How do I build a website?"))
        assertNull(ForgeIntent.extract("What is a landing page"))
        assertNull(ForgeIntent.extract("Tell me how to make a website"))
        assertNull(ForgeIntent.extract("Open YouTube"))
    }
}
