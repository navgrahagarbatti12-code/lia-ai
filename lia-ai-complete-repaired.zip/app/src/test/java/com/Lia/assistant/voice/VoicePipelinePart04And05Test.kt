package com.Lia.assistant.voice

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

@OptIn(ExperimentalCoroutinesApi::class)
class VoicePipelinePart04And05Test {

    @Test
    fun toolCallDeduplicator_skipsSeenIdsAndEvictsOldestWhenBounded() {
        val dedup = ToolCallDeduplicator(maxSize = 3)
        assertTrue(dedup.shouldProcess("c1"))
        assertFalse(dedup.shouldProcess("c1"))
        assertTrue(dedup.shouldProcess("c2"))
        assertTrue(dedup.shouldProcess("c3"))
        assertTrue(dedup.shouldProcess("c4")) // evicts c1
        assertTrue(dedup.shouldProcess("c1")) // c1 was evicted so it's accepted again
        assertFalse(dedup.shouldProcess("c4"))
    }

    @Test
    fun geminiLiveClient_parsesFramesAndIgnoresHousekeeping() {
        var setupCount = 0
        var audioBytes: ByteArray? = null
        var inText = ""
        var outText = ""
        val toolCalls = mutableListOf<String>()
        var turned = 0
        var interrupted = 0

        val client = GeminiLiveClient("key", object : GeminiLiveClient.Listener {
            override fun onSetupComplete() { setupCount++ }
            override fun onAudioChunk(bytes: ByteArray) { audioBytes = bytes }
            override fun onInputTranscript(text: String) { inText = text }
            override fun onOutputTranscript(text: String) { outText = text }
            override fun onToolCall(id: String, name: String, args: JSONObject) {
                toolCalls += "$id:$name:${args.optString("app")}"
            }
            override fun onTurnComplete() { turned++ }
            override fun onInterrupted() { interrupted++ }
            override fun onError(message: String) = Unit
            override fun onClosed() = Unit
        })

        // Setup payload must NOT include realtimeInputConfig.automaticActivityDetection
        val setup = client.buildSetupPayload("Sys", "Aoede")
        assertFalse(setup.getJSONObject("setup").has("realtimeInputConfig"))

        client.handleIncomingFrame("""{"sessionResumptionUpdate":{"newHandle":"abc"}}""")
        client.handleIncomingFrame("""{"goAway":{}}""")
        client.handleIncomingFrame("""{"setupComplete":{}}""")
        assertEquals(1, setupCount)

        val pcmB64 = Base64.getEncoder().encodeToString(byteArrayOf(1, 2, 3, 4))
        client.handleIncomingFrame(
            """{"serverContent":{"modelTurn":{"parts":[{"inlineData":{"mimeType":"audio/pcm;rate=24000","data":"$pcmB64"}}]},"inputTranscription":{"text":"hello"},"outputTranscription":{"text":"hi there"},"interrupted":true,"turnComplete":true}}"""
        )
        assertEquals(4, audioBytes?.size)
        assertEquals("hello", inText)
        assertEquals("hi there", outText)
        assertEquals(1, interrupted)
        assertEquals(1, turned)

        val toolFrame = """{"toolCall":{"functionCalls":[{"id":"t1","name":"open_app","args":{"app":"YouTube"}},{"id":"t1","name":"open_app","args":{"app":"YouTube"}}]}}"""
        client.handleIncomingFrame(toolFrame)
        assertEquals(listOf("t1:open_app:YouTube"), toolCalls)
    }

    @Test
    fun echoGuard_counterTailAndWatchdogWithFakeClock() = runTest {
        val testScope = TestScope(testScheduler)
        EchoGuard.setScopeForTesting(testScope)

        assertFalse(EchoGuard.isMicMuted())
        EchoGuard.notifyPlaybackStarted()
        EchoGuard.notifyPlaybackStarted()
        assertTrue(EchoGuard.isMicMuted())

        // Stopping 1 of 2 leaves mic muted
        EchoGuard.notifyPlaybackStopped()
        testScope.advanceTimeBy(EchoGuard.ECHO_TAIL_MS + 100)
        testScope.runCurrent()
        assertTrue(EchoGuard.isMicMuted())

        // Stopping second starts 450ms tail
        EchoGuard.notifyPlaybackStopped()
        testScope.advanceTimeBy(EchoGuard.ECHO_TAIL_MS - 50)
        testScope.runCurrent()
        assertTrue(EchoGuard.isMicMuted())

        testScope.advanceTimeBy(60)
        testScope.runCurrent()
        assertFalse(EchoGuard.isMicMuted())

        // Watchdog force-unmutes after 60s
        EchoGuard.notifyPlaybackStarted()
        assertTrue(EchoGuard.isMicMuted())
        testScope.advanceTimeBy(EchoGuard.WATCHDOG_MS + 10)
        testScope.runCurrent()
        assertFalse(EchoGuard.isMicMuted())

        EchoGuard.reset()
    }

    @Test
    fun liveAudioIo_rmsComputesExpectedAmplitude() {
        assertEquals(0f, LiveAudioIO.rms(byteArrayOf()), 0.0001f)
        // Little-endian max positive short 0x7FFF = 32767 -> ~1.0
        val maxSamples = byteArrayOf(0xFF.toByte(), 0x7F, 0xFF.toByte(), 0x7F)
        assertEquals(1.0f, LiveAudioIO.rms(maxSamples), 0.001f)
    }
}
