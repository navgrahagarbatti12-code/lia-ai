package com.Lia.assistant.action

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneActionsCommonTest {

    @Test
    fun appLauncher_matchesExactPrefixWordPrefixAndRejectsLooseSubstring() {
        val apps = mapOf(
            "youtube" to "com.google.android.youtube",
            "youtube music" to "com.google.android.apps.youtube.music",
            "whatsapp" to "com.whatsapp",
            "whatsapp business" to "com.whatsapp.w4b",
            "settings" to "com.android.settings",
            "x" to "com.twitter.android"
        )

        assertEquals("com.google.android.youtube", AppLauncher.findApp("YouTube", apps))
        assertEquals("com.google.android.apps.youtube.music", AppLauncher.findApp("you mus", apps))
        assertEquals("com.whatsapp", AppLauncher.findApp("whats", apps))
        assertEquals("com.android.settings", AppLauncher.findApp("set", apps))

        // Loose middle substring must NOT match
        assertNull(AppLauncher.findApp("tube", apps))
        // Short 1-char key must NOT prefix-match unless exact
        assertEquals("com.twitter.android", AppLauncher.findApp("x", apps))
        assertNull(AppLauncher.findApp("xy", apps))
    }

    @Test
    fun contactResolver_detectsPhoneNumbersAndRanksExactOverPrefixOverContains() {
        assertTrue(ContactResolver.looksLikePhoneNumber("+91 98765-43210"))
        assertTrue(ContactResolver.looksLikePhoneNumber("12345"))
        assertFalse(ContactResolver.looksLikePhoneNumber("1234"))
        assertFalse(ContactResolver.looksLikePhoneNumber("Rahul"))

        val candidates = listOf(
            ContactResolver.ContactCandidate("Amit Kumar Sharma", "333"),
            ContactResolver.ContactCandidate("Rahul Verma", "222"),
            ContactResolver.ContactCandidate("Rahul", "111"),
            ContactResolver.ContactCandidate("My Rahul Office", "444")
        )
        assertEquals("111", ContactResolver.rankBestCandidate("rahul", candidates)?.phoneNumber)

        val prefixVsContains = listOf(
            ContactResolver.ContactCandidate("Best Rahul", "222"),
            ContactResolver.ContactCandidate("Rahul Sharma", "111")
        )
        assertEquals("111", ContactResolver.rankBestCandidate("rahul", prefixVsContains)?.phoneNumber)
    }
}
