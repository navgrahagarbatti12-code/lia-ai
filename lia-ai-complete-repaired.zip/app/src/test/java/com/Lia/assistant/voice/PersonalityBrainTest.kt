package com.Lia.assistant.voice

import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class PersonalityBrainTest {

    @Before
    fun setUp() {
        ConversationMemory.clear()
    }

    @Test
    fun buildPrompt_succeedsForEveryPersonalityAndLanguageCombination() {
        for (personality in Personality.entries) {
            for (language in LanguagePreference.entries) {
                val prompt = PersonalityPromptBuilder.build(
                    personality = personality,
                    language = language,
                    detectedLanguage = DetectedLanguage.UNKNOWN,
                    recap = null,
                    assistantName = "Lia"
                )
                assertTrue(prompt.contains("You are Lia,"))
                assertTrue(prompt.contains(personality.systemInstruction))
                assertTrue(prompt.contains("Language policy:"))
                assertFalse(prompt.contains("This is a continuing conversation"))
            }
        }
    }

    @Test
    fun buildPrompt_includesRecapOnlyWhenProvided() {
        val withoutRecap = PersonalityPromptBuilder.build(
            personality = Personality.NORMAL,
            language = LanguagePreference.AUTO,
            recap = null,
            assistantName = "Lia"
        )
        assertFalse(withoutRecap.contains("This is a continuing conversation"))

        val withRecap = PersonalityPromptBuilder.build(
            personality = Personality.FRIENDLY,
            language = LanguagePreference.AUTO,
            recap = "User: hello\nYou: hi there!",
            assistantName = "Aria"
        )
        assertTrue(withRecap.contains("You are Aria,"))
        assertTrue(withRecap.contains("This is a continuing conversation — do not greet again. Recap:"))
        assertTrue(withRecap.contains("User: hello"))
    }

    @Test
    fun companionAndGfMode_containMandatoryBoundaryRules() {
        val companion = Personality.COMPANION.systemInstruction.lowercase()
        val gfMode = Personality.GF_MODE.systemInstruction.lowercase()
        listOf(companion, gfMode).forEach { instruction ->
            assertTrue(instruction.contains("never claim to be human"))
            assertTrue(instruction.contains("sexually explicit"))
            assertTrue(instruction.contains("change tone or topic"))
        }
    }

    @Test
    fun languageDetector_handlesHindiHinglishEnglishAndBlank() {
        assertEquals(DetectedLanguage.HINDI, LanguageDetector.detect("नमस्ते लिया, आज मौसम कैसा है?"))
        assertEquals(DetectedLanguage.HINGLISH, LanguageDetector.detect("kya haal hai yaar"))
        assertEquals(DetectedLanguage.HINGLISH, LanguageDetector.detect("ek cafe ki website banao please"))
        assertEquals(DetectedLanguage.ENGLISH, LanguageDetector.detect("what's the weather"))
        assertEquals(DetectedLanguage.ENGLISH, LanguageDetector.detect("open YouTube and search for music"))
        assertEquals(DetectedLanguage.UNKNOWN, LanguageDetector.detect("   \n  "))
    }

    @Test
    fun conversationMemory_keepsRolling12TurnsAndCapsRecapAt1600Chars() {
        assertNull(ConversationMemory.recap())
        for (i in 1..15) {
            ConversationMemory.addUserTurn("message $i " + "x".repeat(200))
        }
        val turns = ConversationMemory.turns()
        assertEquals(12, turns.size)
        assertTrue(turns.first().text.startsWith("message 4 "))
        val recap = ConversationMemory.recap()
        assertNotNull(recap)
        assertTrue(recap!!.length <= 1600)

        ConversationMemory.clear()
        assertNull(ConversationMemory.recap())
    }
}
