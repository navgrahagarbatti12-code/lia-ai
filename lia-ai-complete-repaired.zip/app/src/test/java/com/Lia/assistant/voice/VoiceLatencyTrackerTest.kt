package com.Lia.assistant.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test

class VoiceLatencyTrackerTest {

    private var fakeNow = 1000L

    @Before
    fun setUp() {
        fakeNow = 1000L
        VoiceLatencyTracker.setClockForTesting { fakeNow }
    }

    @Test
    fun inOrderMarks_computeExactDeltas() {
        VoiceLatencyTracker.markSpeechEnd(1000L)
        VoiceLatencyTracker.markFirstAudioByte(1320L)
        VoiceLatencyTracker.markTurnComplete(2500L)

        val snap = VoiceLatencyTracker.snapshot.value
        assertEquals(320L, snap.firstAudioLatencyMs)
        assertEquals(1500L, snap.turnDurationMs)
    }

    @Test
    fun outOfOrderMarks_areIgnored() {
        // First audio before speechEnd is ignored
        VoiceLatencyTracker.markFirstAudioByte(900L)
        assertNull(VoiceLatencyTracker.snapshot.value.firstAudioLatencyMs)

        VoiceLatencyTracker.markSpeechEnd(2000L)
        // Out-of-order first audio earlier than speechEnd is ignored
        VoiceLatencyTracker.markFirstAudioByte(1500L)
        assertNull(VoiceLatencyTracker.snapshot.value.firstAudioLatencyMs)

        VoiceLatencyTracker.markFirstAudioByte(2250L)
        // Out-of-order turnComplete earlier than firstAudio is ignored
        VoiceLatencyTracker.markTurnComplete(2100L)
        assertNull(VoiceLatencyTracker.snapshot.value.turnDurationMs)

        VoiceLatencyTracker.markTurnComplete(2700L)
        val snap = VoiceLatencyTracker.snapshot.value
        assertEquals(250L, snap.firstAudioLatencyMs)
        assertEquals(700L, snap.turnDurationMs)
    }

    @Test
    fun toolMarksAndReconnectCount_trackCorrectly() {
        VoiceLatencyTracker.markToolStart(3000L)
        VoiceLatencyTracker.markToolEnd(2900L) // out of order ignored
        assertNull(VoiceLatencyTracker.snapshot.value.toolExecutionMs)

        VoiceLatencyTracker.markToolEnd(3450L)
        assertEquals(450L, VoiceLatencyTracker.snapshot.value.toolExecutionMs)

        VoiceLatencyTracker.incrementReconnectCount()
        VoiceLatencyTracker.incrementReconnectCount()
        assertEquals(2, VoiceLatencyTracker.reconnectCount.value)

        VoiceLatencyTracker.reset()
        assertEquals(0, VoiceLatencyTracker.reconnectCount.value)
        assertNull(VoiceLatencyTracker.snapshot.value.toolExecutionMs)
    }
}
