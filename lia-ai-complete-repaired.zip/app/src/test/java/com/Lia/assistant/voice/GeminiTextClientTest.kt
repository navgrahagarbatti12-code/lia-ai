package com.Lia.assistant.voice

import com.Lia.assistant.data.LanguagePreference
import com.Lia.assistant.data.Personality
import com.Lia.assistant.forge.ForgeIntent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiTextClientTest {

    @Test
    fun pickBestModel_prefersFlashExcludingLiveImageTtsAndFallsBack() {
        val modelsJson = """
            {
              "models": [
                {"name": "models/gemini-2.5-flash-live-preview", "supportedGenerationMethods": ["generateContent"]},
                {"name": "models/gemini-2.5-flash-image", "supportedGenerationMethods": ["generateContent"]},
                {"name": "models/gemini-2.5-flash-tts", "supportedGenerationMethods": ["generateContent"]},
                {"name": "models/gemini-2.5-flash", "supportedGenerationMethods": ["generateContent"]}
              ]
            }
        """.trimIndent()
        assertEquals("gemini-2.5-flash", GeminiTextClient.pickBestModel(modelsJson))

        val fallbackJson = """
            {
              "models": [
                {"name": "models/embedding-001", "supportedGenerationMethods": ["embedContent"]},
                {"name": "models/gemini-2.5-pro", "supportedGenerationMethods": ["generateContent"]}
              ]
            }
        """.trimIndent()
        assertEquals("gemini-2.5-pro", GeminiTextClient.pickBestModel(fallbackJson))
    }

    @Test
    fun reply_handlesBlankKeyAndEmptyHistoryWithoutNetwork() = runTest {
        val blankKey = GeminiTextClient.reply("", "sys", listOf(ChatTurn(true, "hi")))
        assertTrue(blankKey is ChatReplyResult.Error)

        val emptyHist = GeminiTextClient.reply("abc", "sys", emptyList())
        assertTrue(emptyHist is ChatReplyResult.Error)
    }

    @Test
    fun parseReplyText_extractsTextOrReportsBlocked() {
        val ok = GeminiTextClient.parseReplyText(
            """{"candidates":[{"content":{"parts":[{"text":"Namaste!"},{"text":" How can I help?"}]}}]}"""
        )
        assertEquals(ChatReplyResult.Success("Namaste! How can I help?"), ok)

        val blocked = GeminiTextClient.parseReplyText("""{"candidates":[{"finishReason":"SAFETY"}]}""")
        assertTrue(blocked is ChatReplyResult.Error)
    }

    @Test
    fun chatPromptBuilder_omitsToolAndVoiceReferences() {
        val prompt = ChatPromptBuilder.build(Personality.DEVELOPER, LanguagePreference.HINGLISH, "Lia")
        assertTrue(prompt.contains("typed chat"))
        assertTrue(prompt.contains("Personality: Developer."))
        assertFalse(prompt.contains("open_app"))
    }

    @Test
    fun forgeIntent_matchesBuildCommandsAndIgnoresQuestions() {
        assertNotNull(ForgeIntent.extract("Lia, ek cafe ki website banao"))
        assertNotNull(ForgeIntent.extract("Build a modern portfolio website for a photographer"))
        assertNotNull(ForgeIntent.extract("create a landing page for my bakery"))

        assertNull(ForgeIntent.extract("How do I build a website?"))
        assertNull(ForgeIntent.extract("What is a landing page"))
        assertNull(ForgeIntent.extract("kya website banana mushkil hai?"))
        assertNull(ForgeIntent.extract("Tell me about coffee shops"))
    }
}
