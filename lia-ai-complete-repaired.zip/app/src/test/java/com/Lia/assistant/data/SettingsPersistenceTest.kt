package com.Lia.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.preferencesOf
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SettingsPersistenceTest {

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences(NovaPreferences.PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .clear()
            .commit()
    }

    @Test
    fun apiKeyStore_trimsAndPersistsKey() {
        assertFalse(ApiKeyStore.hasKey(context))
        ApiKeyStore.saveKey(context, "   test-key-123  \n")
        assertTrue(ApiKeyStore.hasKey(context))
        assertEquals("test-key-123", ApiKeyStore.getKey(context))
    }

    @Test
    fun personalityRepository_fallsBackToNovaPreferencesWhenDataStoreEmpty() {
        NovaPreferences.putString(context, NovaPreferences.Keys.PERSONALITY, Personality.TEACHER.name)
        NovaPreferences.putString(context, NovaPreferences.Keys.LANGUAGE, LanguagePreference.HINGLISH.name)
        NovaPreferences.putString(context, NovaPreferences.Keys.ASSISTANT_NAME, "Aria")
        NovaPreferences.putString(context, NovaPreferences.Keys.VOICE_NAME, "Kore")

        val empty = emptyPreferences()
        assertEquals(Personality.TEACHER, PersonalityRepository.personalityFrom(empty, context))
        assertEquals(LanguagePreference.HINGLISH, PersonalityRepository.languageFrom(empty, context))
        assertEquals("Aria", PersonalityRepository.assistantNameFrom(empty, context))
        assertEquals("Kore", PersonalityRepository.voiceNameFrom(empty, context))
    }

    @Test
    fun personalityRepository_dataStoreOverridesFallbackAndBlankUsesDefaults() = runTest {
        NovaPreferences.putString(context, NovaPreferences.Keys.PERSONALITY, Personality.FUNNY.name)
        val dsPrefs = preferencesOf(
            stringPreferencesKey("personality") to Personality.DEVELOPER.name,
            stringPreferencesKey("assistant_name") to "   "
        )
        assertEquals(Personality.DEVELOPER, PersonalityRepository.personalityFrom(dsPrefs, context))
        assertEquals(AssistantBrand.NAME, PersonalityRepository.assistantNameFrom(dsPrefs, context))

        PersonalityRepository.setPersonality(context, Personality.NAUTANKI)
        assertEquals(Personality.NAUTANKI, PersonalityRepository.getPersonality(context))
        assertEquals(
            Personality.NAUTANKI.name,
            NovaPreferences.getString(context, NovaPreferences.Keys.PERSONALITY)
        )
    }
}
