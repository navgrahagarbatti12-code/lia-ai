package com.Lia.assistant.agent.core

import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.Lia.assistant.action.NovaAccessibilityService
import java.util.concurrent.atomic.AtomicLong

interface ScreenDriver {
    suspend fun capture(): CapturedScreen?
    suspend fun clickElement(observation: ScreenObservation, element: UiElement): DriverResult
    suspend fun gestureTap(x: Float, y: Float): DriverResult
    suspend fun setText(observation: ScreenObservation, element: UiElement, text: String): DriverResult
    suspend fun scroll(direction: String): DriverResult
    suspend fun back(): DriverResult
    suspend fun home(): DriverResult
}

class ScreenObserver(private val driver: ScreenDriver) {
    private val seq = AtomicLong(0L)

    @Volatile
    var latestObservationId: Long = 0L
        private set

    suspend fun observe(): ScreenObservation? {
        val captured = driver.capture() ?: return null
        val id = seq.incrementAndGet()
        latestObservationId = id
        return ScreenObservation(
            observationId = id,
            packageName = captured.packageName,
            windowClass = captured.windowClass,
            elements = captured.elements,
            screenWidth = captured.screenWidth,
            screenHeight = captured.screenHeight,
            windowStamp = captured.windowStamp
        )
    }
}

class AccessibilityScreenDriver : ScreenDriver {
    @Volatile
    private var latestWindowStamp: Long = 0L

    override suspend fun capture(): CapturedScreen? {
        val service = NovaAccessibilityService.instance ?: return null
        val root = service.rootInActiveWindow ?: return null
        val stamp = System.nanoTime()
        latestWindowStamp = stamp
        val pkg = root.packageName?.toString().orEmpty()
        val windowClass = root.className?.toString().orEmpty()
        val metrics = service.resources.displayMetrics
        val elements = collectElements(root)
        return CapturedScreen(
            packageName = pkg,
            windowClass = windowClass,
            elements = elements,
            screenWidth = metrics.widthPixels,
            screenHeight = metrics.heightPixels,
            windowStamp = stamp
        )
    }

    override suspend fun clickElement(observation: ScreenObservation, element: UiElement): DriverResult {
        if (observation.windowStamp != latestWindowStamp) {
            return DriverResult(DriverStatus.STALE, "Observation is stale")
        }
        val service = NovaAccessibilityService.instance
            ?: return DriverResult(DriverStatus.UNSUPPORTED, "Accessibility service inactive")
        val targetText = element.label
        if (targetText.isNotEmpty() && service.tapText(targetText)) {
            return DriverResult(DriverStatus.OK, "Clicked via accessibility")
        }
        if (!element.bounds.isEmpty && service.gestureTap(element.bounds.centerX, element.bounds.centerY)) {
            return DriverResult(DriverStatus.OK, "Clicked via bounds gesture")
        }
        return DriverResult(DriverStatus.NOT_FOUND, "Target not clickable")
    }

    override suspend fun gestureTap(x: Float, y: Float): DriverResult {
        val service = NovaAccessibilityService.instance
            ?: return DriverResult(DriverStatus.UNSUPPORTED, "Accessibility service inactive")
        return if (service.gestureTap(x, y)) {
            DriverResult(DriverStatus.OK)
        } else {
            DriverResult(DriverStatus.FAILED, "Gesture failed")
        }
    }

    override suspend fun setText(
        observation: ScreenObservation,
        element: UiElement,
        text: String
    ): DriverResult {
        if (observation.windowStamp != latestWindowStamp) {
            return DriverResult(DriverStatus.STALE, "Observation is stale")
        }
        val service = NovaAccessibilityService.instance
            ?: return DriverResult(DriverStatus.UNSUPPORTED, "Accessibility service inactive")
        val root = service.rootInActiveWindow
            ?: return DriverResult(DriverStatus.FAILED, "No active window")
        val node = findMatchingEditable(root, element)
            ?: return DriverResult(DriverStatus.NOT_FOUND, "Editable element not found")
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            DriverResult(DriverStatus.OK)
        } else {
            DriverResult(DriverStatus.FAILED, "ACTION_SET_TEXT failed")
        }
    }

    override suspend fun scroll(direction: String): DriverResult {
        val service = NovaAccessibilityService.instance
            ?: return DriverResult(DriverStatus.UNSUPPORTED, "Accessibility service inactive")
        return if (service.scrollScreen(direction)) {
            DriverResult(DriverStatus.OK)
        } else {
            DriverResult(DriverStatus.FAILED, "Nothing scrollable")
        }
    }

    override suspend fun back(): DriverResult {
        val service = NovaAccessibilityService.instance
            ?: return DriverResult(DriverStatus.UNSUPPORTED, "Accessibility service inactive")
        return if (service.goBack()) DriverResult(DriverStatus.OK) else DriverResult(DriverStatus.FAILED)
    }

    override suspend fun home(): DriverResult {
        val service = NovaAccessibilityService.instance
            ?: return DriverResult(DriverStatus.UNSUPPORTED, "Accessibility service inactive")
        return if (service.goHome()) DriverResult(DriverStatus.OK) else DriverResult(DriverStatus.FAILED)
    }

    private fun collectElements(root: AccessibilityNodeInfo): List<UiElement> {
        val list = ArrayList<UiElement>(64)
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.addLast(root)
        var idx = 0
        while (queue.isNotEmpty() && list.size < 80) {
            val node = queue.removeFirst()
            if (node.isVisibleToUser) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                list += UiElement(
                    id = "el_${idx++}",
                    text = node.text?.toString()?.trim().orEmpty(),
                    contentDescription = node.contentDescription?.toString()?.trim().orEmpty(),
                    viewId = node.viewIdResourceName.orEmpty(),
                    className = node.className?.toString().orEmpty(),
                    clickable = node.isClickable,
                    editable = node.isEditable,
                    scrollable = node.isScrollable,
                    bounds = UiBounds(rect.left, rect.top, rect.right, rect.bottom)
                )
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.addLast(it) }
            }
        }
        return list
    }

    private fun findMatchingEditable(
        root: AccessibilityNodeInfo,
        target: UiElement
    ): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.addLast(root)
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            if (node.isVisibleToUser && node.isEditable) {
                val vid = node.viewIdResourceName.orEmpty()
                if (target.viewId.isNotEmpty() && vid == target.viewId) return node
                val txt = node.text?.toString()?.trim().orEmpty()
                if (target.text.isNotEmpty() && txt == target.text) return node
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.addLast(it) }
            }
        }
        return root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
    }
}
