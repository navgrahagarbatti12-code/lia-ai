package com.Lia.assistant.agent.core

enum class ExecPhase {
    OBSERVE,
    RESOLVE,
    ACT,
    WAIT,
    VERIFY
}

enum class ActionMethod {
    ACCESSIBILITY_CLICK,
    GESTURE_ON_ELEMENT_BOUNDS,
    VISION_TAP,
    SET_TEXT
}

enum class Blocker {
    LOGIN,
    CAPTCHA,
    TWO_FACTOR,
    SECURITY_CHECK,
    PERMISSION_PROMPT
}

enum class FailureReason {
    STALE_OBSERVATION,
    TARGET_NOT_FOUND,
    ACTION_FAILED,
    VERIFICATION_FAILED,
    UNSUPPORTED,
    AMBIGUOUS_CONTACT,
    INVALID_REQUEST,
    USER_REJECTED,
    BLOCKER
}

data class UiBounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
    val isEmpty: Boolean get() = right <= left || bottom <= top
}

data class UiElement(
    val id: String,
    val text: String = "",
    val contentDescription: String = "",
    val viewId: String = "",
    val className: String = "",
    val clickable: Boolean = false,
    val editable: Boolean = false,
    val scrollable: Boolean = false,
    val bounds: UiBounds = UiBounds(0, 0, 0, 0)
) {
    val label: String
        get() = text.ifBlank { contentDescription }
}

data class CapturedScreen(
    val packageName: String,
    val windowClass: String,
    val elements: List<UiElement>,
    val screenWidth: Int,
    val screenHeight: Int,
    val windowStamp: Long
)

data class ScreenObservation(
    val observationId: Long,
    val packageName: String,
    val windowClass: String,
    val elements: List<UiElement>,
    val screenWidth: Int,
    val screenHeight: Int,
    val windowStamp: Long
)

enum class DriverStatus {
    OK,
    FAILED,
    STALE,
    NOT_FOUND,
    UNSUPPORTED
}

data class DriverResult(
    val status: DriverStatus,
    val detail: String = ""
)

sealed class ActionResult {
    data class Success(val detail: String = "") : ActionResult()
    data class Failed(val reason: FailureReason, val detail: String = "") : ActionResult()
    data class Blocked(val blocker: Blocker, val detail: String = "") : ActionResult()
}
