package com.Lia.assistant.agent.whatsapp

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class WhatsAppUnreadItem(
    val key: String,
    val sender: String,
    val text: String,
    val timestampMs: Long
)

object WhatsAppNotificationStore {
    private val lock = Any()
    private val items = LinkedHashMap<String, WhatsAppUnreadItem>()

    fun record(item: WhatsAppUnreadItem) {
        synchronized(lock) {
            items[item.key] = item
        }
    }

    fun removeByKey(key: String) {
        synchronized(lock) {
            items.remove(key)
        }
    }

    fun unreadList(): List<WhatsAppUnreadItem> = synchronized(lock) {
        items.values.sortedByDescending { it.timestampMs }
    }

    fun clear() {
        synchronized(lock) {
            items.clear()
        }
    }
}

class WhatsAppNotificationListenerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (sbn.packageName !in WHATSAPP_PACKAGES) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (title.isEmpty() || text.isEmpty()) return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        WhatsAppNotificationStore.record(
            WhatsAppUnreadItem(
                key = sbn.key,
                sender = title,
                text = text,
                timestampMs = sbn.postTime
            )
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (sbn.packageName in WHATSAPP_PACKAGES) {
            WhatsAppNotificationStore.removeByKey(sbn.key)
        }
    }

    companion object {
        private val WHATSAPP_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")

        fun isEnabled(context: android.content.Context): Boolean {
            return androidx.core.app.NotificationManagerCompat
                .getEnabledListenerPackages(context.applicationContext)
                .contains(context.packageName)
        }
    }
}
