package com.Lia.assistant.agent.whatsapp

import android.content.Context
import android.provider.ContactsContract
import com.Lia.assistant.action.CommIntents
import com.Lia.assistant.action.ContactResolver
import com.Lia.assistant.agent.core.ActionResult
import com.Lia.assistant.agent.core.ScreenDriver
import com.Lia.assistant.agent.core.ScreenObserver
import com.Lia.assistant.agent.core.TargetResolver
import com.Lia.assistant.agent.core.TargetSpec
import com.Lia.assistant.agent.core.TextInputExecutor
import com.Lia.assistant.agent.core.UiActionExecutor
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class WhatsAppAction {
    READ_UNREAD,
    SEND_MESSAGE,
    READ_CHAT,
    SEARCH_CHAT,
    MUTE_CHAT,
    UNMUTE_CHAT,
    MARK_READ
}

data class WhatsAppContactMatch(
    val displayName: String,
    val phoneNumber: String
)

sealed class ContactDisambiguation {
    data class Unique(val match: WhatsAppContactMatch) : ContactDisambiguation()
    data class Ambiguous(val candidates: List<WhatsAppContactMatch>) : ContactDisambiguation()
    data object NotFound : ContactDisambiguation()
}

class WhatsAppAgent(
    private val driver: ScreenDriver,
    private val contactFinder: (String) -> List<WhatsAppContactMatch> = { emptyList() },
    private val directChatOpener: (phoneNumber: String, message: String) -> Boolean = { _, _ -> true }
) {
    private val observer = ScreenObserver(driver)
    private val uiExecutor = UiActionExecutor(driver, observer)
    private val textExecutor = TextInputExecutor(driver, observer)

    private var activeTaskId: String? = null
    private var pendingSendTarget: WhatsAppContactMatch? = null
    private var pendingSendMessage: String? = null
    private var awaitingConfirmation = false

    suspend fun execute(args: JSONObject): JSONObject {
        val actionRaw = args.optString("action", "").trim().uppercase()
        val action = WhatsAppAction.entries.firstOrNull { it.name == actionRaw }
            ?: return JSONObject().put("error", "Unsupported WhatsApp action: $actionRaw")

        return when (action) {
            WhatsAppAction.READ_UNREAD -> handleReadUnread()
            WhatsAppAction.SEND_MESSAGE -> handleSendMessage(args)
            WhatsAppAction.READ_CHAT -> handleReadChat(args)
            WhatsAppAction.SEARCH_CHAT -> handleSearchChat(args)
            WhatsAppAction.MUTE_CHAT -> handleMuteToggle(mute = true, args = args)
            WhatsAppAction.UNMUTE_CHAT -> handleMuteToggle(mute = false, args = args)
            WhatsAppAction.MARK_READ -> handleMarkRead(args)
        }
    }

    suspend fun control(args: JSONObject): JSONObject {
        val command = args.optString("command", "").trim().uppercase()
        val taskId = args.optString("task_id", "").trim()
        val userConfirmed = args.optBoolean("user_confirmed", false)

        if (activeTaskId == null || (taskId.isNotEmpty() && taskId != activeTaskId)) {
            return JSONObject().put("status", "no_matching_task")
        }

        return when (command) {
            "CANCEL", "REJECT" -> {
                clearPending()
                JSONObject().put("status", "cancelled")
            }
            "STATUS" -> JSONObject()
                .put("status", if (awaitingConfirmation) "waiting_for_confirmation" else "idle")
                .put("task_id", activeTaskId)
            "CONFIRM" -> {
                if (!awaitingConfirmation) {
                    return JSONObject().put("status", "error").put("reason", "not_awaiting_confirmation")
                }
                if (!userConfirmed) {
                    return JSONObject().put("status", "waiting_for_confirmation")
                        .put("reason", "explicit_yes_required")
                }
                val target = pendingSendTarget
                val msg = pendingSendMessage
                clearPending()
                if (target == null || msg == null) {
                    return JSONObject().put("status", "failed")
                }
                if (!directChatOpener(target.phoneNumber, msg)) {
                    return JSONObject().put("status", "failed")
                }
                val obs = observer.observe() ?: return JSONObject().put("status", "composer_opened")
                val sendBtn = TargetResolver.resolve(obs, TargetSpec(textAnyOf = listOf("Send")))
                if (sendBtn != null) {
                    val res = uiExecutor.clickAndVerify(obs, sendBtn, expectTargetGone = true)
                    if (res is ActionResult.Success) {
                        return JSONObject().put("status", "sent").put("contact", target.displayName)
                    }
                }
                JSONObject().put("status", "composer_opened_send_not_found")
            }
            else -> JSONObject().put("error", "Unknown command: $command")
        }
    }

    private fun handleReadUnread(): JSONObject {
        // Strictly reads from NotificationListener store; never opens WhatsApp UI.
        val unread = WhatsAppNotificationStore.unreadList()
        val arr = JSONArray()
        for (item in unread) {
            arr.put(
                JSONObject()
                    .put("sender", item.sender)
                    .put("text", item.text)
                    .put("timestamp", item.timestampMs)
            )
        }
        return JSONObject()
            .put("status", "ok")
            .put("count", unread.size)
            .put("messages", arr)
    }

    private fun handleSendMessage(args: JSONObject): JSONObject {
        val query = args.optString("contact", "").trim()
        val message = args.optString("message", "").trim()
        if (query.isEmpty() || message.isEmpty()) {
            return JSONObject().put("status", "invalid_arguments")
        }

        val resolved = resolveContact(query)
        return when (resolved) {
            is ContactDisambiguation.Ambiguous -> JSONObject()
                .put("status", "contact_ambiguous")
                .put("candidates", JSONArray(resolved.candidates.map { it.displayName }))
            ContactDisambiguation.NotFound -> JSONObject().put("status", "contact_not_found")
            is ContactDisambiguation.Unique -> {
                val id = UUID.randomUUID().toString()
                activeTaskId = id
                pendingSendTarget = resolved.match
                pendingSendMessage = message
                awaitingConfirmation = true
                JSONObject()
                    .put("status", "waiting_for_confirmation")
                    .put("task_id", id)
                    .put("contact", resolved.match.displayName)
                    .put("phone", resolved.match.phoneNumber)
                    .put("message", message)
            }
        }
    }

    internal fun resolveContact(query: String): ContactDisambiguation {
        if (ContactResolver.looksLikePhoneNumber(query)) {
            return ContactDisambiguation.Unique(WhatsAppContactMatch(query, query))
        }
        val matches = contactFinder(query).distinctBy { it.phoneNumber.filter(Char::isDigit) }
        if (matches.isEmpty()) return ContactDisambiguation.NotFound
        if (matches.size == 1) return ContactDisambiguation.Unique(matches.first())

        val exactMatches = matches.filter { it.displayName.equals(query, ignoreCase = true) }
        if (exactMatches.size == 1) return ContactDisambiguation.Unique(exactMatches.first())

        return ContactDisambiguation.Ambiguous(matches)
    }

    private suspend fun handleReadChat(args: JSONObject): JSONObject {
        val chat = args.optString("contact", "").trim()
        val obs = observer.observe() ?: return JSONObject().put("status", "accessibility_not_enabled")
        if (chat.isNotEmpty()) {
            TargetResolver.resolve(obs, TargetSpec(textAnyOf = listOf(chat)))?.let {
                uiExecutor.clickAndVerify(obs, it, expectTargetGone = false)
            }
        }
        val postObs = observer.observe() ?: obs
        val lines = postObs.elements.mapNotNull { it.label.takeIf(String::isNotBlank) }.take(25)
        return JSONObject().put("status", "ok").put("lines", JSONArray(lines))
    }

    private suspend fun handleSearchChat(args: JSONObject): JSONObject {
        val query = args.optString("query", args.optString("contact", "")).trim()
        val obs = observer.observe() ?: return JSONObject().put("status", "accessibility_not_enabled")
        val searchBtn = TargetResolver.resolve(obs, TargetSpec(textAnyOf = listOf("Search", "Ask Meta AI or Search")))
            ?: return JSONObject().put("status", "search_not_found")
        uiExecutor.clickAndVerify(obs, searchBtn, expectTargetGone = false)
        val inputObs = observer.observe() ?: return JSONObject().put("status", "failed")
        val input = TargetResolver.resolve(inputObs, TargetSpec(editableOnly = true))
            ?: return JSONObject().put("status", "input_not_found")
        val typed = textExecutor.typeAndVerify(inputObs, input, query)
        return JSONObject().put("status", if (typed is ActionResult.Success) "ok" else "failed")
    }

    private suspend fun handleMuteToggle(mute: Boolean, args: JSONObject): JSONObject {
        val obs = observer.observe() ?: return JSONObject().put("status", "accessibility_not_enabled")
        val labels = if (mute) listOf("Mute notifications", "Mute") else listOf("Unmute notifications", "Unmute")
        val target = TargetResolver.resolve(obs, TargetSpec(textAnyOf = labels))
            ?: return JSONObject().put("status", "element_not_found")
        val res = uiExecutor.clickAndVerify(obs, target, expectTargetGone = false)
        return JSONObject().put("status", if (res is ActionResult.Success) "done" else "failed")
    }

    private suspend fun handleMarkRead(args: JSONObject): JSONObject {
        val obs = observer.observe() ?: return JSONObject().put("status", "accessibility_not_enabled")
        val target = TargetResolver.resolve(obs, TargetSpec(textAnyOf = listOf("Mark as read", "Mark read")))
            ?: return JSONObject().put("status", "element_not_found")
        val res = uiExecutor.clickAndVerify(obs, target, expectTargetGone = false)
        return JSONObject().put("status", if (res is ActionResult.Success) "done" else "failed")
    }

    private fun clearPending() {
        activeTaskId = null
        pendingSendTarget = null
        pendingSendMessage = null
        awaitingConfirmation = false
    }

    companion object {
        fun queryContacts(context: Context, query: String): List<WhatsAppContactMatch> {
            val trimmed = query.trim()
            if (trimmed.isEmpty()) return emptyList()
            val list = mutableListOf<WhatsAppContactMatch>()
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            runCatching {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                    arrayOf("%$trimmed%"),
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )?.use { cursor ->
                    val nIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val pIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    while (cursor.moveToNext() && list.size < 8) {
                        val name = if (nIdx >= 0) cursor.getString(nIdx).orEmpty().trim() else ""
                        val phone = if (pIdx >= 0) cursor.getString(pIdx).orEmpty().trim() else ""
                        if (name.isNotEmpty() && phone.isNotEmpty()) {
                            list += WhatsAppContactMatch(name, phone)
                        }
                    }
                }
            }
            return list
        }

        fun openDirectChat(context: Context, phoneNumber: String, message: String): Boolean =
            CommIntents.openWhatsAppComposer(context, phoneNumber, message)
    }
}
