package com.Lia.assistant.agent.social

enum class TaskState(val isTerminal: Boolean = false) {
    IDLE,
    OPENING_APP,
    OBSERVING,
    RESOLVING_TARGET,
    VALIDATING_TARGET,
    EXECUTING_ACTION,
    WAITING_FOR_UI,
    VERIFYING,
    NEXT_STEP,
    RETRY,
    REOBSERVE,
    WAITING_FOR_CONFIRMATION,
    WAITING_FOR_USER,
    COMPLETED(isTerminal = true),
    FAILED(isTerminal = true),
    CANCELLED(isTerminal = true)
}

class TaskStateMachine(initialState: TaskState = TaskState.IDLE) {
    private val _history = mutableListOf(initialState)
    val history: List<TaskState> get() = _history.toList()

    var current: TaskState = initialState
        private set

    fun moveTo(next: TaskState) {
        if (current.isTerminal) {
            throw IllegalStateException("Cannot transition from terminal state $current to $next")
        }
        if (next == TaskState.FAILED || next == TaskState.CANCELLED) {
            current = next
            _history += next
            return
        }
        val allowed = ALLOWED_TRANSITIONS[current].orEmpty()
        if (next !in allowed) {
            throw IllegalStateException("Illegal transition: $current -> $next")
        }
        current = next
        _history += next
    }

    companion object {
        private val ALLOWED_TRANSITIONS: Map<TaskState, Set<TaskState>> = mapOf(
            TaskState.IDLE to setOf(TaskState.OPENING_APP, TaskState.OBSERVING),
            TaskState.OPENING_APP to setOf(TaskState.OBSERVING, TaskState.WAITING_FOR_UI, TaskState.WAITING_FOR_USER),
            TaskState.OBSERVING to setOf(
                TaskState.RESOLVING_TARGET,
                TaskState.WAITING_FOR_USER,
                TaskState.VERIFYING,
                TaskState.COMPLETED
            ),
            TaskState.RESOLVING_TARGET to setOf(
                TaskState.VALIDATING_TARGET,
                TaskState.RETRY,
                TaskState.REOBSERVE,
                TaskState.WAITING_FOR_USER
            ),
            TaskState.VALIDATING_TARGET to setOf(
                TaskState.EXECUTING_ACTION,
                TaskState.WAITING_FOR_CONFIRMATION,
                TaskState.REOBSERVE,
                TaskState.WAITING_FOR_USER
            ),
            TaskState.EXECUTING_ACTION to setOf(
                TaskState.WAITING_FOR_UI,
                TaskState.VERIFYING,
                TaskState.RETRY,
                TaskState.REOBSERVE
            ),
            TaskState.WAITING_FOR_UI to setOf(TaskState.OBSERVING, TaskState.VERIFYING, TaskState.REOBSERVE),
            TaskState.VERIFYING to setOf(
                TaskState.NEXT_STEP,
                TaskState.COMPLETED,
                TaskState.RETRY,
                TaskState.REOBSERVE
            ),
            TaskState.NEXT_STEP to setOf(
                TaskState.OBSERVING,
                TaskState.RESOLVING_TARGET,
                TaskState.WAITING_FOR_CONFIRMATION,
                TaskState.COMPLETED
            ),
            TaskState.RETRY to setOf(TaskState.OBSERVING, TaskState.RESOLVING_TARGET, TaskState.EXECUTING_ACTION),
            TaskState.REOBSERVE to setOf(TaskState.OBSERVING),
            TaskState.WAITING_FOR_CONFIRMATION to setOf(
                TaskState.EXECUTING_ACTION,
                TaskState.NEXT_STEP,
                TaskState.COMPLETED
            ),
            TaskState.WAITING_FOR_USER to setOf(TaskState.OBSERVING, TaskState.REOBSERVE)
        )
    }
}
