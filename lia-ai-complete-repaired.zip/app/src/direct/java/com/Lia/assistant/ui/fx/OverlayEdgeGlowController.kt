package com.Lia.assistant.ui.fx

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Shader
import android.os.Build
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import com.Lia.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

object OverlayEdgeGlowController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var overlayView: EdgeGlowOverlayView? = null
    private var collectJob: Job? = null

    fun show(context: Context) {
        val appCtx = context.applicationContext
        if (!Settings.canDrawOverlays(appCtx)) return
        scope.launch {
            if (overlayView != null) return@launch
            val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@launch
            val view = EdgeGlowOverlayView(appCtx)
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            runCatching {
                wm.addView(view, params)
                overlayView = view
                collectJob = scope.launch {
                    combine(VoiceSessionManager.state, VoiceSessionManager.amplitude) { s, a -> s to a }
                        .collect { (state, amp) ->
                            view.updateState(state, amp)
                        }
                }
            }
        }
    }

    fun hide(context: Context) {
        val appCtx = context.applicationContext
        scope.launch {
            collectJob?.cancel()
            collectJob = null
            val view = overlayView ?: return@launch
            overlayView = null
            val wm = appCtx.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@launch
            runCatching { wm.removeViewImmediate(view) }
        }
    }

    private class EdgeGlowOverlayView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var currentState = NovaOrbState.IDLE
        private var currentAmp = 0f

        fun updateState(state: NovaOrbState, amplitude: Float) {
            currentState = state
            currentAmp = amplitude
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (currentState == NovaOrbState.IDLE) return
            val edgePx = 26f * resources.displayMetrics.density
            val alpha = ((0.52f + currentAmp.coerceIn(0f, 1f) * 0.38f) * 255).toInt().coerceIn(0, 255)
            val baseColor = when (currentState) {
                NovaOrbState.SPEAKING -> Color.rgb(0xFF, 0x6F, 0xAE)
                NovaOrbState.ERROR -> Color.rgb(0xFF, 0x7A, 0x85)
                else -> Color.rgb(0x8B, 0x5C, 0xF6)
            }
            val c0 = Color.argb(alpha, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))
            val c1 = Color.TRANSPARENT
            val w = width.toFloat()
            val h = height.toFloat()

            paint.shader = LinearGradient(0f, 0f, 0f, edgePx, c0, c1, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, edgePx, paint)

            paint.shader = LinearGradient(0f, h - edgePx, 0f, h, c1, c0, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, h - edgePx, w, h, paint)

            paint.shader = LinearGradient(0f, 0f, edgePx, 0f, c0, c1, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, edgePx, h, paint)

            paint.shader = LinearGradient(w - edgePx, 0f, w, 0f, c1, c0, Shader.TileMode.CLAMP)
            canvas.drawRect(w - edgePx, 0f, w, h, paint)
        }
    }
}
