package com.Lia.assistant.ui.navigation

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.Lia.assistant.action.NovaAccessibilityService
import com.Lia.assistant.agent.whatsapp.WhatsAppNotificationListenerService
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaSettingsRow
import com.Lia.assistant.ui.components.NovaTopBar
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaSpacing

object FlavorRoutes {
    const val ACCESSIBILITY_DISCLOSURE = "accessibility_disclosure"
}

fun NavGraphBuilder.registerAccessibilityDisclosureRoute(navController: NavHostController) {
    composable(FlavorRoutes.ACCESSIBILITY_DISCLOSURE) {
        AccessibilityDisclosureScreen(onBack = { navController.popBackStack() })
    }
}

@Composable
fun AccessibilitySettingsRows(onOpenDisclosure: () -> Unit) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var accessibilityOn by remember { mutableStateOf(NovaAccessibilityService.isEnabled(context)) }
    var overlayOn by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var notifAccessOn by remember { mutableStateOf(WhatsAppNotificationListenerService.isEnabled(context)) }

    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                accessibilityOn = NovaAccessibilityService.isEnabled(context)
                overlayOn = Settings.canDrawOverlays(context)
                notifAccessOn = WhatsAppNotificationListenerService.isEnabled(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    NovaSettingsRow(
        icon = Icons.Rounded.AccessibilityNew,
        title = "Screen Control Service",
        subtitle = "Allows tapping, typing, reading screen, and social tasks",
        value = if (accessibilityOn) "Active" else "Off",
        iconTint = if (accessibilityOn) colors.success else colors.warning,
        onClick = onOpenDisclosure
    )
    NovaSettingsRow(
        icon = Icons.Rounded.Layers,
        title = "Overlay Edge Glow",
        subtitle = "Draws active aura over other apps while in voice mode",
        value = if (overlayOn) "Allowed" else "Off",
        iconTint = if (overlayOn) colors.success else colors.textSecondary,
        onClick = {
            context.startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    )
    NovaSettingsRow(
        icon = Icons.Rounded.NotificationsActive,
        title = "WhatsApp Unread Reader",
        subtitle = "Reads unread WhatsApp notifications without opening chats",
        value = if (notifAccessOn) "Allowed" else "Off",
        iconTint = if (notifAccessOn) colors.success else colors.textSecondary,
        onClick = {
            context.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    )
}

@Composable
private fun AccessibilityDisclosureScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var enabled by remember { mutableStateOf(NovaAccessibilityService.isEnabled(context)) }

    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                enabled = NovaAccessibilityService.isEnabled(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
    ) {
        NovaTopBar(
            title = "Screen Control Disclosure",
            subtitle = "Accessibility Service",
            onBack = onBack
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(NovaSpacing.lg)
        ) {
            NovaGlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (enabled) "Status: Enabled" else "Status: Disabled",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (enabled) colors.success else colors.warning
                )
                Spacer(Modifier.height(NovaSpacing.md))
                Text(
                    text = "Lia AI uses Android Accessibility Service in the direct flavor strictly when you request screen actions such as reading on-screen text, tapping buttons, typing messages, or drafting/posting social tasks.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = colors.textPrimary
                )
                Spacer(Modifier.height(NovaSpacing.sm))
                Text(
                    text = "• Nothing runs in the background without an active command.\n" +
                        "• Publish actions always pause for your explicit spoken or tapped confirmation.\n" +
                        "• Login, CAPTCHA, and 2FA screens pause immediately for you.\n" +
                        "• Screen contents are never uploaded unless directly part of your current voice turn.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
                Spacer(Modifier.height(NovaSpacing.xl))
                NovaButton(
                    text = if (enabled) "Manage in Accessibility Settings" else "Enable Accessibility Service",
                    onClick = {
                        context.startActivity(
                            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(NovaSpacing.sm))
                NovaButton(
                    text = "Not Now",
                    style = NovaButtonStyle.TEXT,
                    onClick = onBack,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
