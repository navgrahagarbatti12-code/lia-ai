package com.Lia.assistant.action

import android.content.Context
import com.Lia.assistant.agent.core.AccessibilityScreenDriver
import com.Lia.assistant.agent.social.ControlCommand
import com.Lia.assistant.agent.social.SocialMediaAgent
import com.Lia.assistant.agent.social.SocialTaskRequest
import com.Lia.assistant.agent.whatsapp.WhatsAppAgent
import com.Lia.assistant.license.AccessKeyManager
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

object ActionExecutor {
    private val driver by lazy { AccessibilityScreenDriver() }

    @Volatile
    private var socialAgentInstance: SocialMediaAgent? = null

    private fun getSocialAgent(context: Context): SocialMediaAgent {
        val appCtx = context.applicationContext
        return socialAgentInstance ?: synchronized(this) {
            socialAgentInstance ?: SocialMediaAgent(
                driver = driver,
                appOpener = { platform ->
                    AppLauncher.launch(appCtx, platform.packageName) is AppLauncher.LaunchResult.Launched
                }
            ).also { socialAgentInstance = it }
        }
    }

    @Volatile
    private var whatsAppAgentInstance: WhatsAppAgent? = null

    private fun getWhatsAppAgent(context: Context): WhatsAppAgent {
        return whatsAppAgentInstance ?: synchronized(this) {
            whatsAppAgentInstance ?: WhatsAppAgent(
                driver = driver,
                contactFinder = { query -> WhatsAppAgent.queryContacts(context.applicationContext, query) },
                directChatOpener = { phone, msg -> WhatsAppAgent.openDirectChat(context.applicationContext, phone, msg) }
            ).also { whatsAppAgentInstance = it }
        }
    }

    suspend fun execute(context: Context, name: String, args: JSONObject): JSONObject {
        if (!AccessKeyManager.isActive(context)) {
            return JSONObject().put(
                "error",
                "Access key is not active. Ask the user to activate their access key in Profile."
            )
        }

        return when (name) {
            "open_app" -> handleOpenApp(context, args)
            "call_contact" -> handleCallContact(context, args)
            "message_contact" -> handleMessageContact(context, args)
            "read_screen" -> handleReadScreen(context, args)
            "tap_text" -> handleTapText(context, args)
            "type_text" -> handleTypeText(context, args)
            "scroll_screen" -> handleScrollScreen(context, args)
            "go_back" -> handleGoBack(context)
            "go_home" -> handleGoHome(context)
            "execute_social_media_task" -> handleSocialTask(context, args)
            "social_media_task_control" -> handleSocialControl(context, args)
            "execute_whatsapp_task" -> getWhatsAppAgent(context).execute(args)
            "whatsapp_task_control" -> getWhatsAppAgent(context).control(args)
            else -> JSONObject().put("error", "Unknown tool: $name")
        }
    }

    private suspend fun handleSocialTask(context: Context, args: JSONObject): JSONObject {
        val parsed = SocialTaskRequest.parse(args)
        if (parsed.isFailure) {
            return JSONObject()
                .put("status", "invalid_request")
                .put("error", parsed.exceptionOrNull()?.message ?: "Invalid social request")
        }
        val req = parsed.getOrThrow()
        val report = getSocialAgent(context).startTask(req)
        return JSONObject()
            .put("task_id", report.taskId)
            .put("status", report.status.name)
            .put("state", report.machineState.name)
            .put("message", report.message)
    }

    private suspend fun handleSocialControl(context: Context, args: JSONObject): JSONObject {
        val cmdRaw = args.optString("command", "").trim().uppercase()
        val cmd = ControlCommand.entries.firstOrNull { it.name == cmdRaw }
            ?: return JSONObject().put("error", "Unknown control command: $cmdRaw")
        val taskId = args.optString("task_id", "").trim().takeIf { it.isNotEmpty() }
        val explicitYes = args.optString("user_confirmed", "").equals("true", ignoreCase = true) ||
            args.optBoolean("user_confirmed", false)
        val report = getSocialAgent(context).control(cmd, taskId, explicitYes)
        return JSONObject()
            .put("task_id", report.taskId)
            .put("status", report.status.name)
            .put("state", report.machineState.name)
            .put("message", report.message)
    }

    private suspend fun handleOpenApp(context: Context, args: JSONObject): JSONObject {
        val appName = args.optString("app_name", args.optString("app", "")).trim()
        if (appName.isEmpty()) return JSONObject().put("status", "missing_app_name")
        return when (val result = AppLauncher.findAndLaunch(context, appName)) {
            is AppLauncher.LaunchResult.Launched ->
                JSONObject().put("status", "opened").put("package", result.packageName)
            is AppLauncher.LaunchResult.NotFound ->
                JSONObject().put("status", "app_not_found").put("query", result.query)
            is AppLauncher.LaunchResult.Failed ->
                JSONObject().put("status", "failed").put("reason", result.reason)
        }
    }

    private fun handleCallContact(context: Context, args: JSONObject): JSONObject {
        val target = args.optString("contact", args.optString("target", "")).trim()
        if (target.isEmpty()) return JSONObject().put("status", "missing_contact")
        return when (val lookup = ContactResolver.lookup(context, target)) {
            is ContactResolver.LookupResult.Found -> {
                val status = CommIntents.placeCall(context, lookup.phoneNumber)
                JSONObject().put("status", status).put("contact", lookup.displayName)
            }
            ContactResolver.LookupResult.NoPermission ->
                JSONObject().put("status", "no_contacts_permission")
            ContactResolver.LookupResult.NotFound ->
                JSONObject().put("status", "contact_not_found")
        }
    }

    private suspend fun handleMessageContact(context: Context, args: JSONObject): JSONObject {
        val target = args.optString("contact", args.optString("target", "")).trim()
        val message = args.optString("message", args.optString("text", "")).trim()
        val channel = args.optString("channel", "sms").trim().lowercase()
        if (target.isEmpty()) return JSONObject().put("status", "missing_contact")

        return when (val lookup = ContactResolver.lookup(context, target)) {
            is ContactResolver.LookupResult.Found -> {
                val isWhatsApp = channel == "whatsapp" || channel == "wa"
                val opened = if (isWhatsApp) {
                    CommIntents.openWhatsAppComposer(context, lookup.phoneNumber, message)
                } else {
                    CommIntents.openSmsComposer(context, lookup.phoneNumber, message)
                }
                if (!opened) return JSONObject().put("status", "composer_failed")

                val service = NovaAccessibilityService.instance
                if (service == null || !NovaAccessibilityService.isEnabled(context)) {
                    return JSONObject()
                        .put("status", "composer_opened")
                        .put("contact", lookup.displayName)
                }

                repeat(12) {
                    delay(400)
                    if (isWhatsApp) {
                        service.tapText("Continue to chat")
                    }
                    if (service.tapText("Send")) {
                        return JSONObject()
                            .put("status", "sent")
                            .put("contact", lookup.displayName)
                    }
                }
                JSONObject()
                    .put("status", "composer_opened_send_not_found")
                    .put("contact", lookup.displayName)
            }
            ContactResolver.LookupResult.NoPermission ->
                JSONObject().put("status", "no_contacts_permission")
            ContactResolver.LookupResult.NotFound ->
                JSONObject().put("status", "contact_not_found")
        }
    }

    private fun handleReadScreen(context: Context, args: JSONObject): JSONObject {
        val service = NovaAccessibilityService.instance
        if (service == null || !NovaAccessibilityService.isEnabled(context)) {
            return JSONObject().put("status", "accessibility_not_enabled")
        }
        val maxElements = args.optInt("max_elements", 40).coerceIn(5, 80)
        val elements = service.readScreen(maxElements = maxElements)
        return JSONObject()
            .put("status", "ok")
            .put("elements", JSONArray(elements))
    }

    private fun handleTapText(context: Context, args: JSONObject): JSONObject {
        val service = NovaAccessibilityService.instance
        if (service == null || !NovaAccessibilityService.isEnabled(context)) {
            return JSONObject().put("status", "accessibility_not_enabled")
        }
        val text = args.optString("text", "").trim()
        if (text.isEmpty()) return JSONObject().put("status", "element_not_found")
        val ok = service.tapText(text)
        return JSONObject().put("status", if (ok) "tapped" else "element_not_found")
    }

    private fun handleTypeText(context: Context, args: JSONObject): JSONObject {
        val service = NovaAccessibilityService.instance
        if (service == null || !NovaAccessibilityService.isEnabled(context)) {
            return JSONObject().put("status", "accessibility_not_enabled")
        }
        val text = args.optString("text", "")
        val ok = service.typeText(text)
        return JSONObject().put("status", if (ok) "typed" else "no_focused_field")
    }

    private fun handleScrollScreen(context: Context, args: JSONObject): JSONObject {
        val service = NovaAccessibilityService.instance
        if (service == null || !NovaAccessibilityService.isEnabled(context)) {
            return JSONObject().put("status", "accessibility_not_enabled")
        }
        val direction = args.optString("direction", "down")
        val ok = service.scrollScreen(direction)
        return JSONObject().put("status", if (ok) "scrolled" else "nothing_scrollable")
    }

    private fun handleGoBack(context: Context): JSONObject {
        val service = NovaAccessibilityService.instance
        if (service == null || !NovaAccessibilityService.isEnabled(context)) {
            return JSONObject().put("status", "accessibility_not_enabled")
        }
        val ok = service.goBack()
        return JSONObject().put("status", if (ok) "done" else "failed")
    }

    private fun handleGoHome(context: Context): JSONObject {
        val service = NovaAccessibilityService.instance
        if (service == null || !NovaAccessibilityService.isEnabled(context)) {
            return JSONObject().put("status", "accessibility_not_enabled")
        }
        val ok = service.goHome()
        return JSONObject().put("status", if (ok) "done" else "failed")
    }
}
