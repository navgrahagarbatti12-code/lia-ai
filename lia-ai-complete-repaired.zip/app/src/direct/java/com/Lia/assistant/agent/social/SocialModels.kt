package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.core.TargetSpec
import org.json.JSONObject

enum class Platform(val packageName: String) {
    INSTAGRAM("com.instagram.android"),
    FACEBOOK("com.facebook.katana")
}

enum class SocialAction {
    CREATE_POST,
    CREATE_REEL,
    CREATE_STORY,
    TEXT_POST
}

enum class TaskMode {
    PUBLISH,
    DRAFT
}

enum class TaskStatus {
    RUNNING,
    WAITING_FOR_CONFIRMATION,
    WAITING_FOR_USER,
    COMPLETED,
    SUBMITTED_UNVERIFIED,
    FAILED,
    CANCELLED
}

enum class ControlCommand {
    CONFIRM,
    REJECT,
    RESUME,
    CANCEL,
    STATUS
}

data class PlanStep(
    val description: String,
    val target: TargetSpec,
    val inputText: String? = null,
    val isIrreversible: Boolean = false
)

data class SocialTaskRequest(
    val platform: Platform,
    val action: SocialAction,
    val mediaUri: String?,
    val caption: String?,
    val mode: TaskMode,
    val targetAccount: String?
) {
    companion object {
        fun parse(args: JSONObject): Result<SocialTaskRequest> {
            val platformRaw = args.optString("platform", "").trim().uppercase()
            val platform = Platform.entries.firstOrNull { it.name == platformRaw }
                ?: return Result.failure(IllegalArgumentException("Unsupported platform: '$platformRaw'. Use INSTAGRAM or FACEBOOK."))

            val actionRaw = args.optString("action", "").trim().uppercase()
            val action = SocialAction.entries.firstOrNull { it.name == actionRaw }
                ?: return Result.failure(IllegalArgumentException("Unsupported action: '$actionRaw'."))

            val modeRaw = args.optString("mode", "PUBLISH").trim().uppercase()
            val mode = TaskMode.entries.firstOrNull { it.name == modeRaw }
                ?: return Result.failure(IllegalArgumentException("Invalid mode: '$modeRaw'. Use PUBLISH or DRAFT."))

            val mediaUri = args.optString("media_uri", "").trim().takeIf { it.isNotEmpty() }
            val caption = args.optString("caption", "").trim().takeIf { it.isNotEmpty() }
            val targetAccount = args.optString("target_account", "").trim().takeIf { it.isNotEmpty() }

            if (action == SocialAction.TEXT_POST && platform != Platform.FACEBOOK) {
                return Result.failure(IllegalArgumentException("TEXT_POST is only supported on FACEBOOK."))
            }
            if (action == SocialAction.TEXT_POST && caption == null) {
                return Result.failure(IllegalArgumentException("TEXT_POST requires a non-empty caption."))
            }
            if (action != SocialAction.TEXT_POST && mediaUri != null && !mediaUri.startsWith("content://")) {
                return Result.failure(IllegalArgumentException("media_uri must be a content:// URI shared to Lia."))
            }

            return Result.success(
                SocialTaskRequest(
                    platform = platform,
                    action = action,
                    mediaUri = mediaUri,
                    caption = caption,
                    mode = mode,
                    targetAccount = targetAccount
                )
            )
        }
    }
}

data class TaskReport(
    val taskId: String,
    val status: TaskStatus,
    val machineState: TaskState,
    val message: String,
    val history: List<TaskState>
)
