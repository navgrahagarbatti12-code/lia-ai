package com.Lia.assistant.voice

import org.json.JSONArray

object LiaToolCatalog {
    fun declarations(): JSONArray = JSONArray().apply {
        put(
            functionDecl(
                name = "open_app",
                description = "Open an installed app on the user's phone by name.",
                params = mapOf("app_name" to "App name such as YouTube, Camera, Settings, WhatsApp"),
                required = listOf("app_name")
            )
        )
        put(
            functionDecl(
                name = "call_contact",
                description = "Place a phone call or open the dialer for a contact name or phone number.",
                params = mapOf("contact" to "Contact name or phone number"),
                required = listOf("contact")
            )
        )
        put(
            functionDecl(
                name = "message_contact",
                description = "Send an SMS or WhatsApp message to a contact or phone number.",
                params = mapOf(
                    "contact" to "Contact name or phone number",
                    "message" to "Message text",
                    "channel" to "sms or whatsapp"
                ),
                required = listOf("contact", "message")
            )
        )
        put(
            functionDecl(
                name = "read_screen",
                description = "Read visible UI elements and labels from the active screen.",
                params = mapOf("max_elements" to "Maximum elements to return, default 40")
            )
        )
        put(
            functionDecl(
                name = "tap_text",
                description = "Tap an on-screen button or label matching the given text.",
                params = mapOf("text" to "Visible label or button text to tap"),
                required = listOf("text")
            )
        )
        put(
            functionDecl(
                name = "type_text",
                description = "Type text into the currently focused or editable input field.",
                params = mapOf("text" to "Text to type"),
                required = listOf("text")
            )
        )
        put(
            functionDecl(
                name = "scroll_screen",
                description = "Scroll the active screen up or down.",
                params = mapOf("direction" to "down or up"),
                required = listOf("direction")
            )
        )
        put(
            functionDecl(
                name = "go_back",
                description = "Press the Android system Back action."
            )
        )
        put(
            functionDecl(
                name = "go_home",
                description = "Navigate to the Android Home screen."
            )
        )
        put(
            functionDecl(
                name = "execute_social_media_task",
                description = "Start a guided Instagram or Facebook task (create post, reel, story, or text post). Pauses for confirmation before publishing.",
                params = mapOf(
                    "platform" to "INSTAGRAM or FACEBOOK",
                    "action" to "CREATE_POST, CREATE_REEL, CREATE_STORY, or TEXT_POST",
                    "media_uri" to "Optional content:// URI shared to Lia",
                    "caption" to "Post or story caption text",
                    "mode" to "PUBLISH or DRAFT",
                    "target_account" to "Optional target account handle"
                ),
                required = listOf("platform", "action")
            )
        )
        put(
            functionDecl(
                name = "social_media_task_control",
                description = "Control an active social media task (CONFIRM, REJECT, RESUME, CANCEL, STATUS). Only call confirm after the user explicitly said yes.",
                params = mapOf(
                    "command" to "CONFIRM, REJECT, RESUME, CANCEL, or STATUS",
                    "task_id" to "Active social media task id",
                    "user_confirmed" to "true only after the user explicitly said yes"
                ),
                required = listOf("command")
            )
        )
        put(
            functionDecl(
                name = "execute_whatsapp_task",
                description = "Run a WhatsApp task: READ_UNREAD, SEND_MESSAGE, READ_CHAT, SEARCH_CHAT, MUTE_CHAT, UNMUTE_CHAT, or MARK_READ.",
                params = mapOf(
                    "action" to "READ_UNREAD, SEND_MESSAGE, READ_CHAT, SEARCH_CHAT, MUTE_CHAT, UNMUTE_CHAT, or MARK_READ",
                    "contact" to "Contact name or phone number",
                    "message" to "Message text for SEND_MESSAGE",
                    "query" to "Search query for SEARCH_CHAT"
                ),
                required = listOf("action")
            )
        )
        put(
            functionDecl(
                name = "whatsapp_task_control",
                description = "Control an active WhatsApp task (CONFIRM, REJECT, CANCEL, STATUS). Only call confirm after the user explicitly said yes.",
                params = mapOf(
                    "command" to "CONFIRM, REJECT, CANCEL, or STATUS",
                    "task_id" to "Active WhatsApp task id",
                    "user_confirmed" to "true only after the user explicitly said yes"
                ),
                required = listOf("command")
            )
        )
        put(
            functionDecl(
                name = "build_website",
                description = "Open the 3D Website Forge and generate a complete animated website from the user's description.",
                params = mapOf("prompt" to "Detailed website topic and user requirements"),
                required = listOf("prompt")
            )
        )
    }
}
