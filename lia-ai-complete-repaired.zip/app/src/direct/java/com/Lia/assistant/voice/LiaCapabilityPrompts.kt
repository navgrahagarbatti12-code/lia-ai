package com.Lia.assistant.voice

object LiaCapabilityPrompts {
    fun toolInstruction(assistantName: String): String =
        "Phone capabilities for $assistantName: You can open installed apps, place calls, send SMS or WhatsApp messages, " +
            "read the current screen, tap on-screen labels, type into fields, scroll, navigate back or home, and launch the Website Forge. " +
            "Always confirm with the user before sending messages or taking irreversible actions when uncertain."
}
