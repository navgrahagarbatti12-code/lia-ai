package com.Lia.assistant.license

object AccessKeyRules {
    data class Evaluation(
        val active: Boolean,
        val expired: Boolean,
        val statusText: String
    )

    fun evaluate(
        plan: String,
        expiresAtMs: Long,
        blocked: Boolean,
        nowMs: Long
    ): Evaluation {
        if (blocked) {
            return Evaluation(
                active = false,
                expired = false,
                statusText = "Access key blocked"
            )
        }
        val cleanPlan = plan.trim()
        if (cleanPlan.isEmpty()) {
            return Evaluation(
                active = false,
                expired = false,
                statusText = "Not activated"
            )
        }
        if (expiresAtMs > 0L && nowMs > expiresAtMs) {
            return Evaluation(
                active = false,
                expired = true,
                statusText = "Access key expired"
            )
        }
        return Evaluation(
            active = true,
            expired = false,
            statusText = "Active • $cleanPlan"
        )
    }
}
