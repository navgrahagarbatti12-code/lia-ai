package com.Lia.assistant.agent.social

import com.Lia.assistant.agent.core.ActionResult
import com.Lia.assistant.agent.core.Blocker
import com.Lia.assistant.agent.core.ScreenDriver
import com.Lia.assistant.agent.core.ScreenObservation
import com.Lia.assistant.agent.core.ScreenObserver
import com.Lia.assistant.agent.core.TargetResolver
import com.Lia.assistant.agent.core.TextInputExecutor
import com.Lia.assistant.agent.core.UiActionExecutor
import java.util.UUID

class SocialMediaAgent(
    private val driver: ScreenDriver,
    private val appOpener: suspend (Platform) -> Boolean = { true }
) {
    private val observer = ScreenObserver(driver)
    private val uiExecutor = UiActionExecutor(driver, observer)
    private val textExecutor = TextInputExecutor(driver, observer)

    private var activeTaskId: String? = null
    private var activeRequest: SocialTaskRequest? = null
    private var activePlan: List<PlanStep> = emptyList()
    private var stepIndex: Int = 0
    private var machine = TaskStateMachine()
    private var latestBlocker: Blocker? = null
    private var explicitConfirmationGranted: Boolean = false

    suspend fun startTask(request: SocialTaskRequest): TaskReport {
        val taskId = UUID.randomUUID().toString()
        activeTaskId = taskId
        activeRequest = request
        activePlan = PlatformSelectors.buildPlan(request)
        stepIndex = 0
        latestBlocker = null
        explicitConfirmationGranted = false
        machine = TaskStateMachine(TaskState.IDLE)

        machine.moveTo(TaskState.OPENING_APP)
        val opened = appOpener(request.platform)
        if (!opened) {
            machine.moveTo(TaskState.FAILED)
            return report(TaskStatus.FAILED, "Could not open ${request.platform.name}.")
        }

        return runUntilPauseOrDone()
    }

    suspend fun control(
        command: ControlCommand,
        taskId: String?,
        userExplicitlySaidYes: Boolean = false
    ): TaskReport {
        val currentId = activeTaskId
            ?: return TaskReport("none", TaskStatus.FAILED, TaskState.IDLE, "No active social media task.", emptyList())
        if (!taskId.isNullOrBlank() && taskId != currentId) {
            return TaskReport(currentId, currentStatus(), machine.current, "Task ID mismatch.", machine.history)
        }

        return when (command) {
            ControlCommand.STATUS -> report(currentStatus(), "Task is in ${machine.current}.")
            ControlCommand.CANCEL, ControlCommand.REJECT -> {
                if (!machine.current.isTerminal) {
                    machine.moveTo(TaskState.CANCELLED)
                }
                report(TaskStatus.CANCELLED, "Social task cancelled.")
            }
            ControlCommand.CONFIRM -> {
                if (machine.current != TaskState.WAITING_FOR_CONFIRMATION) {
                    return report(
                        currentStatus(),
                        "Refused CONFIRM: task is not awaiting confirmation (state=${machine.current})."
                    )
                }
                if (!userExplicitlySaidYes) {
                    return report(
                        TaskStatus.WAITING_FOR_CONFIRMATION,
                        "Refused CONFIRM: explicit user yes is required before publishing."
                    )
                }
                explicitConfirmationGranted = true
                executeConfirmedStep()
            }
            ControlCommand.RESUME -> {
                if (machine.current != TaskState.WAITING_FOR_USER) {
                    return report(currentStatus(), "Task is not waiting for user action.")
                }
                machine.moveTo(TaskState.OBSERVING)
                runUntilPauseOrDone(alreadyInObserving = true)
            }
        }
    }

    private suspend fun runUntilPauseOrDone(alreadyInObserving: Boolean = false): TaskReport {
        val request = activeRequest ?: return report(TaskStatus.FAILED, "Missing request")

        while (stepIndex < activePlan.size) {
            if (!alreadyInObserving || machine.current != TaskState.OBSERVING) {
                if (machine.current == TaskState.OPENING_APP ||
                    machine.current == TaskState.NEXT_STEP ||
                    machine.current == TaskState.RETRY ||
                    machine.current == TaskState.REOBSERVE
                ) {
                    machine.moveTo(TaskState.OBSERVING)
                }
            }

            val obs = observer.observe()
            if (obs == null) {
                machine.moveTo(TaskState.FAILED)
                return report(TaskStatus.FAILED, "Screen capture unavailable.")
            }

            val blocker = BlockerDetector.detect(obs)
            if (blocker != null) {
                latestBlocker = blocker
                machine.moveTo(TaskState.WAITING_FOR_USER)
                return report(
                    TaskStatus.WAITING_FOR_USER,
                    "Paused on ${blocker.name} prompt. Ask the user to complete it, then resume."
                )
            }

            val step = activePlan[stepIndex]
            machine.moveTo(TaskState.RESOLVING_TARGET)
            val element = TargetResolver.resolve(obs, step.target)
            if (element == null) {
                machine.moveTo(TaskState.RETRY)
                val retryObs = observer.observe()
                val retryEl = retryObs?.let { TargetResolver.resolve(it, step.target) }
                if (retryObs == null || retryEl == null) {
                    machine.moveTo(TaskState.FAILED)
                    return report(TaskStatus.FAILED, "Could not find UI element for '${step.description}'.")
                }
                return executeResolvedStep(retryObs, retryEl, step, request)
            }

            val stepReport = executeResolvedStep(obs, element, step, request)
            if (machine.current == TaskState.WAITING_FOR_CONFIRMATION ||
                machine.current == TaskState.WAITING_FOR_USER ||
                machine.current.isTerminal
            ) {
                return stepReport
            }
        }

        if (machine.current != TaskState.COMPLETED && !machine.current.isTerminal) {
            machine.moveTo(TaskState.COMPLETED)
        }
        return report(TaskStatus.COMPLETED, "Completed ${request.action.name} on ${request.platform.name}.")
    }

    private suspend fun executeResolvedStep(
        obs: ScreenObservation,
        element: com.Lia.assistant.agent.core.UiElement,
        step: PlanStep,
        request: SocialTaskRequest
    ): TaskReport {
        machine.moveTo(TaskState.VALIDATING_TARGET)

        if (step.isIrreversible && request.mode == TaskMode.PUBLISH && !explicitConfirmationGranted) {
            machine.moveTo(TaskState.WAITING_FOR_CONFIRMATION)
            return report(
                TaskStatus.WAITING_FOR_CONFIRMATION,
                "Ready to publish on ${request.platform.name}. Ask the user for explicit confirmation before confirming."
            )
        }

        if (step.isIrreversible && request.mode == TaskMode.DRAFT) {
            machine.moveTo(TaskState.FAILED)
            return report(TaskStatus.FAILED, "Safety invariant: DRAFT mode cannot execute irreversible publish step.")
        }

        machine.moveTo(TaskState.EXECUTING_ACTION)
        val result = if (step.inputText != null) {
            textExecutor.typeAndVerify(obs, element, step.inputText)
        } else {
            uiExecutor.clickAndVerify(obs, element, expectTargetGone = true)
        }

        return when (result) {
            is ActionResult.Blocked -> {
                latestBlocker = result.blocker
                machine.moveTo(TaskState.REOBSERVE)
                machine.moveTo(TaskState.OBSERVING)
                machine.moveTo(TaskState.WAITING_FOR_USER)
                report(TaskStatus.WAITING_FOR_USER, "Blocked by ${result.blocker.name}.")
            }
            is ActionResult.Failed -> {
                if (step.isIrreversible) {
                    // Post-publish click succeeded or uncertain — finish as SUBMITTED_UNVERIFIED
                    machine.moveTo(TaskState.VERIFYING)
                    machine.moveTo(TaskState.COMPLETED)
                    report(
                        TaskStatus.SUBMITTED_UNVERIFIED,
                        "Tapped publish, but confirmation screen could not be verified (${result.detail}). Please check ${request.platform.name} directly."
                    )
                } else {
                    machine.moveTo(TaskState.FAILED)
                    report(TaskStatus.FAILED, "Step '${step.description}' failed: ${result.reason.name} (${result.detail})")
                }
            }
            is ActionResult.Success -> {
                machine.moveTo(TaskState.VERIFYING)
                stepIndex++
                if (stepIndex >= activePlan.size) {
                    if (step.isIrreversible) {
                        val verifyObs = observer.observe()
                        val confirmed = verifyObs != null && PlatformSelectors.confirmIndicators(request.platform)
                            .any { needle ->
                                verifyObs.elements.any {
                                    it.label.contains(needle, ignoreCase = true)
                                }
                            }
                        machine.moveTo(TaskState.COMPLETED)
                        if (confirmed) {
                            report(TaskStatus.COMPLETED, "Published and verified on ${request.platform.name}.")
                        } else {
                            report(
                                TaskStatus.SUBMITTED_UNVERIFIED,
                                "Submitted on ${request.platform.name}, but post-publish status could not be verified. Please verify in the app."
                            )
                        }
                    } else {
                        machine.moveTo(TaskState.COMPLETED)
                        report(
                            TaskStatus.COMPLETED,
                            if (request.mode == TaskMode.DRAFT) {
                                "Saved draft on ${request.platform.name} without publishing."
                            } else {
                                "Completed ${request.action.name} on ${request.platform.name}."
                            }
                        )
                    }
                } else {
                    machine.moveTo(TaskState.NEXT_STEP)
                    report(TaskStatus.RUNNING, "Advancing to step ${stepIndex + 1}")
                }
            }
        }
    }

    private suspend fun executeConfirmedStep(): TaskReport {
        val request = activeRequest ?: return report(TaskStatus.FAILED, "No request")
        val step = activePlan.getOrNull(stepIndex)
            ?: return report(TaskStatus.FAILED, "No pending step")
        val obs = observer.observe() ?: run {
            machine.moveTo(TaskState.FAILED)
            return report(TaskStatus.FAILED, "Could not observe screen on confirm")
        }
        val element = TargetResolver.resolve(obs, step.target) ?: run {
            machine.moveTo(TaskState.FAILED)
            return report(TaskStatus.FAILED, "Publish button no longer visible")
        }

        machine.moveTo(TaskState.EXECUTING_ACTION)
        val result = uiExecutor.clickAndVerify(obs, element, expectTargetGone = true)
        return when (result) {
            is ActionResult.Success -> {
                machine.moveTo(TaskState.VERIFYING)
                val postObs = observer.observe()
                val confirmed = postObs != null && PlatformSelectors.confirmIndicators(request.platform)
                    .any { needle ->
                        postObs.elements.any { it.label.contains(needle, ignoreCase = true) }
                    }
                machine.moveTo(TaskState.COMPLETED)
                if (confirmed) {
                    report(TaskStatus.COMPLETED, "Published and verified on ${request.platform.name}.")
                } else {
                    report(
                        TaskStatus.SUBMITTED_UNVERIFIED,
                        "Publish was tapped, but final confirmation could not be verified. Please check ${request.platform.name}."
                    )
                }
            }
            is ActionResult.Failed -> {
                machine.moveTo(TaskState.VERIFYING)
                machine.moveTo(TaskState.COMPLETED)
                report(
                    TaskStatus.SUBMITTED_UNVERIFIED,
                    "Publish action may have submitted, but verification failed (${result.detail}). Please check ${request.platform.name}."
                )
            }
            is ActionResult.Blocked -> {
                machine.moveTo(TaskState.FAILED)
                report(TaskStatus.FAILED, "Blocked during publish: ${result.blocker}")
            }
        }
    }

    private fun currentStatus(): TaskStatus = when (machine.current) {
        TaskState.WAITING_FOR_CONFIRMATION -> TaskStatus.WAITING_FOR_CONFIRMATION
        TaskState.WAITING_FOR_USER -> TaskStatus.WAITING_FOR_USER
        TaskState.COMPLETED -> TaskStatus.COMPLETED
        TaskState.FAILED -> TaskStatus.FAILED
        TaskState.CANCELLED -> TaskStatus.CANCELLED
        else -> TaskStatus.RUNNING
    }

    private fun report(status: TaskStatus, message: String): TaskReport = TaskReport(
        taskId = activeTaskId ?: "none",
        status = status,
        machineState = machine.current,
        message = message,
        history = machine.history
    )
}
