package com.Lia.assistant.agent.social

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.Lia.assistant.agent.core.Blocker
import com.Lia.assistant.agent.core.ScreenObservation
import com.Lia.assistant.agent.core.TargetSpec

object PlatformSelectors {
    fun buildPlan(request: SocialTaskRequest): List<PlanStep> {
        return when (request.platform) {
            Platform.INSTAGRAM -> buildInstagramPlan(request)
            Platform.FACEBOOK -> buildFacebookPlan(request)
        }
    }

    private fun buildInstagramPlan(req: SocialTaskRequest): List<PlanStep> {
        val steps = mutableListOf<PlanStep>()
        steps += PlanStep(
            description = "Open Instagram create flow",
            target = TargetSpec(textAnyOf = listOf("Create", "New post", "Add", "+"), clickableOnly = false)
        )
        when (req.action) {
            SocialAction.CREATE_REEL -> steps += PlanStep(
                description = "Select Reel mode",
                target = TargetSpec(textAnyOf = listOf("Reel", "REEL"))
            )
            SocialAction.CREATE_STORY -> steps += PlanStep(
                description = "Select Story mode",
                target = TargetSpec(textAnyOf = listOf("Story", "STORY", "Your story"))
            )
            else -> Unit
        }
        steps += PlanStep(
            description = "Advance media editor",
            target = TargetSpec(textAnyOf = listOf("Next", "Continue"))
        )
        if (!req.caption.isNullOrBlank() && req.action != SocialAction.CREATE_STORY) {
            steps += PlanStep(
                description = "Enter caption",
                target = TargetSpec(
                    textAnyOf = listOf("Write a caption", "Caption"),
                    editableOnly = true
                ),
                inputText = req.caption
            )
        }
        if (req.mode == TaskMode.DRAFT) {
            steps += PlanStep(
                description = "Save as draft",
                target = TargetSpec(textAnyOf = listOf("Save draft", "Draft"))
            )
        } else {
            val publishLabels = if (req.action == SocialAction.CREATE_STORY) {
                listOf("Share", "Your story", "Post")
            } else {
                listOf("Share", "Publish", "Post")
            }
            steps += PlanStep(
                description = "Publish to Instagram",
                target = TargetSpec(textAnyOf = publishLabels),
                isIrreversible = true
            )
        }
        return steps
    }

    private fun buildFacebookPlan(req: SocialTaskRequest): List<PlanStep> {
        val steps = mutableListOf<PlanStep>()
        val entryLabels = when (req.action) {
            SocialAction.CREATE_REEL -> listOf("Reel", "Create reel")
            SocialAction.CREATE_STORY -> listOf("Create story", "Add to story")
            else -> listOf("What's on your mind", "Create post", "Write something here")
        }
        steps += PlanStep(
            description = "Open Facebook composer",
            target = TargetSpec(textAnyOf = entryLabels)
        )
        if (!req.caption.isNullOrBlank()) {
            steps += PlanStep(
                description = "Enter post text",
                target = TargetSpec(
                    textAnyOf = listOf("What's on your mind", "Say something", "Describe your reel"),
                    editableOnly = true
                ),
                inputText = req.caption
            )
        }
        if (req.mode == TaskMode.DRAFT) {
            steps += PlanStep(
                description = "Save as draft",
                target = TargetSpec(textAnyOf = listOf("Save as draft", "Save draft"))
            )
        } else {
            steps += PlanStep(
                description = "Publish to Facebook",
                target = TargetSpec(textAnyOf = listOf("Post", "Share now", "Publish")),
                isIrreversible = true
            )
        }
        return steps
    }

    fun confirmIndicators(platform: Platform): List<String> = when (platform) {
        Platform.INSTAGRAM -> listOf("Posting", "Shared", "Your reel", "Your story", "Home")
        Platform.FACEBOOK -> listOf("Posting", "Posted", "News Feed", "Home")
    }
}

object BlockerDetector {
    fun detect(observation: ScreenObservation): Blocker? {
        val combined = observation.elements.joinToString(" ") {
            "${it.text} ${it.contentDescription} ${it.viewId}"
        }.lowercase()

        return when {
            combined.contains("captcha") ||
                combined.contains("verify you are human") ||
                combined.contains("not a robot") -> Blocker.CAPTCHA
            combined.contains("two-factor") ||
                combined.contains("2fa") ||
                combined.contains("authentication code") -> Blocker.TWO_FACTOR
            combined.contains("security check") ||
                combined.contains("confirm your identity") ||
                combined.contains("suspicious login") -> Blocker.SECURITY_CHECK
            combined.contains("log in") ||
                combined.contains("sign in") ||
                combined.contains("forgot password") -> Blocker.LOGIN
            combined.contains("while using the app") ||
                combined.contains("allow ") && combined.contains("access") -> Blocker.PERMISSION_PROMPT
            else -> null
        }
    }
}

object MediaResolver {
    private val lock = Any()
    private val sharedUris = LinkedHashSet<String>()

    fun recordSharedUri(uri: Uri) {
        if (uri.scheme.equals("content", ignoreCase = true)) {
            synchronized(lock) {
                sharedUris.add(uri.toString())
            }
        }
    }

    fun isAuthorizedContentUri(uriString: String?): Boolean {
        val s = uriString?.trim() ?: return false
        if (!s.startsWith("content://")) return false
        return synchronized(lock) { sharedUris.contains(s) }
    }

    fun latestSharedUri(): String? = synchronized(lock) { sharedUris.lastOrNull() }

    internal fun clearForTesting() {
        synchronized(lock) { sharedUris.clear() }
    }
}

class ShareToLiaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleShareIntent(this, intent)
        finish()
    }

    companion object {
        fun handleShareIntent(context: Context, intent: Intent?) {
            if (intent == null) return
            val streamUri = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            if (streamUri != null && streamUri.scheme.equals("content", ignoreCase = true)) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        streamUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                MediaResolver.recordSharedUri(streamUri)
            }
        }
    }
}
