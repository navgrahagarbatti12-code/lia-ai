package com.Lia.assistant.action

import androidx.core.content.FileProvider

class DirectFileProvider : FileProvider()
