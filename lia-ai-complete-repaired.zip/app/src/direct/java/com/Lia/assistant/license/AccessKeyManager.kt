package com.Lia.assistant.license

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.Lia.assistant.ui.components.NovaButton
import com.Lia.assistant.ui.components.NovaButtonStyle
import com.Lia.assistant.ui.components.NovaGlassCard
import com.Lia.assistant.ui.components.NovaTextField
import com.Lia.assistant.ui.theme.LocalNovaColors
import com.Lia.assistant.ui.theme.NovaSpacing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class LicenseInfo(
    val active: Boolean = false,
    val plan: String = "",
    val expiresAt: Long = 0L,
    val statusText: String = "Not activated",
    val blocked: Boolean = false,
    val hasRememberedKey: Boolean = false
)

object AccessKeyManager {
    private const val PREFS_NAME = "lia_access_key"
    private const val KEY_CODE = "key"
    private const val KEY_PLAN = "plan"
    private const val KEY_EXPIRES_AT = "expires_at"
    private const val KEY_ACTIVE = "active"
    private const val KEY_BLOCKED = "blocked"
    private const val KEY_LAST_CHECK = "last_remote_check"
    private const val LIVE_CHECK_INTERVAL_MS = 3L * 60L * 60L * 1000L
    private const val CONFIG_ASSET_NAME = "licensing_config.json"

    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    private val _info = MutableStateFlow(LicenseInfo())
    val info: StateFlow<LicenseInfo> = _info.asStateFlow()

    @Volatile
    private var initialized = false

    @Volatile
    private var testingOverride: Boolean? = null

    internal fun setTestingOverride(active: Boolean?) {
        testingOverride = active
        if (active != null) {
            _info.value = _info.value.copy(
                active = active,
                statusText = if (active) "Active • Test" else "Not activated"
            )
        }
    }

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun refreshInfo(context: Context) {
        val p = prefs(context)
        val key = p.getString(KEY_CODE, "").orEmpty().trim()
        val plan = p.getString(KEY_PLAN, "").orEmpty()
        val expiresAt = p.getLong(KEY_EXPIRES_AT, 0L)
        val blocked = p.getBoolean(KEY_BLOCKED, false)
        val eval = AccessKeyRules.evaluate(
            plan = plan,
            expiresAtMs = expiresAt,
            blocked = blocked,
            nowMs = System.currentTimeMillis()
        )
        val storedActive = p.getBoolean(KEY_ACTIVE, false) && eval.active && key.isNotEmpty()
        _info.value = LicenseInfo(
            active = storedActive,
            plan = plan,
            expiresAt = expiresAt,
            statusText = if (key.isEmpty()) "Not activated" else eval.statusText,
            blocked = blocked,
            hasRememberedKey = key.isNotEmpty()
        )
        initialized = true
    }

    fun isActive(context: Context): Boolean {
        testingOverride?.let { return it }
        if (!initialized) {
            refreshInfo(context)
        }
        return _info.value.active
    }

    suspend fun activate(context: Context, rawKey: String): Result<LicenseInfo> {
        val cleanKey = rawKey.trim()
        if (cleanKey.isEmpty()) {
            return Result.failure(IllegalArgumentException("Enter an access key"))
        }

        val endpoint = withContext(Dispatchers.IO) { readEndpoint(context.applicationContext) }
        if (endpoint == null) {
            _info.value = _info.value.copy(
                active = false,
                statusText = "Licensing not configured"
            )
            return Result.failure(IllegalStateException("Licensing not configured"))
        }

        val deviceId = getDeviceId(context)
        return withContext(Dispatchers.IO) {
            val payload = JSONObject()
                .put("key", cleanKey)
                .put("deviceId", deviceId)
                .put("action", "activate")

            val req = Request.Builder()
                .url(endpoint)
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .build()

            try {
                httpClient.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    val json = runCatching { JSONObject(body) }.getOrNull()
                    if (!resp.isSuccessful || json == null) {
                        val errMsg = json?.optString("error", "Activation failed (${resp.code})")
                            ?: "Activation failed (${resp.code})"
                        return@withContext Result.failure(IllegalStateException(errMsg))
                    }
                    val blocked = json.optBoolean("blocked", false)
                    val plan = json.optString("plan", "Pro")
                    val expiresAt = json.optLong("expiresAt", 0L)
                    val now = System.currentTimeMillis()
                    val eval = AccessKeyRules.evaluate(plan, expiresAt, blocked, now)

                    prefs(context).edit()
                        .putString(KEY_CODE, cleanKey)
                        .putString(KEY_PLAN, plan)
                        .putLong(KEY_EXPIRES_AT, expiresAt)
                        .putBoolean(KEY_BLOCKED, blocked)
                        .putBoolean(KEY_ACTIVE, eval.active)
                        .putLong(KEY_LAST_CHECK, now)
                        .apply()

                    refreshInfo(context)
                    if (!eval.active) {
                        Result.failure(IllegalStateException(eval.statusText))
                    } else {
                        Result.success(_info.value)
                    }
                }
            } catch (e: IOException) {
                Result.failure(IOException("Network error while activating key", e))
            }
        }
    }

    suspend fun liveCheck(context: Context) {
        val appCtx = context.applicationContext
        if (!initialized) refreshInfo(appCtx)
        val p = prefs(appCtx)
        val key = p.getString(KEY_CODE, "").orEmpty().trim()
        if (key.isEmpty()) return

        val now = System.currentTimeMillis()
        val lastCheck = p.getLong(KEY_LAST_CHECK, 0L)
        if (now - lastCheck < LIVE_CHECK_INTERVAL_MS) {
            refreshInfo(appCtx)
            return
        }

        val endpoint = withContext(Dispatchers.IO) { readEndpoint(appCtx) } ?: return
        val deviceId = getDeviceId(appCtx)

        withContext(Dispatchers.IO) {
            val payload = JSONObject()
                .put("key", key)
                .put("deviceId", deviceId)
                .put("action", "check")
            val req = Request.Builder()
                .url(endpoint)
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .build()

            try {
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext // Fail open on transient server errors
                    val body = resp.body?.string().orEmpty()
                    val json = runCatching { JSONObject(body) }.getOrNull() ?: return@withContext
                    val blocked = json.optBoolean("blocked", false)
                    val plan = json.optString("plan", p.getString(KEY_PLAN, "").orEmpty())
                    val expiresAt = json.optLong("expiresAt", p.getLong(KEY_EXPIRES_AT, 0L))
                    val eval = AccessKeyRules.evaluate(plan, expiresAt, blocked, System.currentTimeMillis())

                    p.edit()
                        .putString(KEY_PLAN, plan)
                        .putLong(KEY_EXPIRES_AT, expiresAt)
                        .putBoolean(KEY_BLOCKED, blocked)
                        .putBoolean(KEY_ACTIVE, eval.active)
                        .putLong(KEY_LAST_CHECK, System.currentTimeMillis())
                        .apply()
                    refreshInfo(appCtx)
                }
            } catch (_: IOException) {
                // Fail open on network errors; keep cached local state.
            }
        }
    }

    fun clearKey(context: Context) {
        prefs(context).edit().clear().apply()
        refreshInfo(context)
    }

    private fun readEndpoint(context: Context): String? {
        return runCatching {
            context.assets.open(CONFIG_ASSET_NAME).bufferedReader().use { reader ->
                val obj = JSONObject(reader.readText())
                obj.optString("endpoint", "").trim().takeIf { it.isNotEmpty() }
            }
        }.getOrNull()
    }

    @SuppressLint("HardwareIds")
    private fun getDeviceId(context: Context): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
}

@Composable
fun AccessKeyBanner(
    modifier: Modifier = Modifier,
    onNavigateToProfile: () -> Unit = {}
) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val info by AccessKeyManager.info.collectAsState()
    androidx.compose.runtime.LaunchedEffect(Unit) {
        AccessKeyManager.refreshInfo(context)
    }
    if (info.active) return

    NovaGlassCard(
        modifier = modifier.fillMaxWidth(),
        borderColor = colors.warning.copy(alpha = 0.55f),
        onClick = onNavigateToProfile
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Rounded.WarningAmber,
                contentDescription = null,
                tint = colors.warning
            )
            Spacer(Modifier.width(NovaSpacing.md))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Access Key Required",
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary
                )
                Text(
                    text = "${info.statusText} • Tap to activate in Profile",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
            }
        }
    }
}

@Composable
fun AccessKeySection(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val colors = LocalNovaColors.current
    val scope = rememberCoroutineScope()
    val info by AccessKeyManager.info.collectAsState()
    var keyInput by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        AccessKeyManager.refreshInfo(context)
    }

    NovaGlassCard(modifier = modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (info.active) Icons.Rounded.VerifiedUser else Icons.Rounded.Key,
                contentDescription = null,
                tint = if (info.active) colors.success else colors.accent
            )
            Spacer(Modifier.width(NovaSpacing.md))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Access License",
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary
                )
                Text(
                    text = info.statusText,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (info.blocked) colors.error else colors.textSecondary
                )
            }
        }
        Spacer(Modifier.height(NovaSpacing.md))
        NovaTextField(
            value = keyInput,
            onValueChange = { keyInput = it },
            placeholder = "Enter access key",
            testTag = "access_key_input"
        )
        feedback?.let { msg ->
            Spacer(Modifier.height(NovaSpacing.xs))
            Text(
                text = msg,
                style = MaterialTheme.typography.bodySmall,
                color = colors.warning
            )
        }
        Spacer(Modifier.height(NovaSpacing.md))
        Row(verticalAlignment = Alignment.CenterVertically) {
            NovaButton(
                text = if (busy) "Checking..." else "Activate Key",
                enabled = !busy && keyInput.isNotBlank(),
                onClick = {
                    busy = true
                    feedback = null
                    scope.launch {
                        val res = AccessKeyManager.activate(context, keyInput)
                        busy = false
                        feedback = res.fold(
                            onSuccess = { "Activated: ${it.statusText}" },
                            onFailure = { it.message ?: "Activation failed" }
                        )
                    }
                }
            )
            if (info.hasRememberedKey) {
                Spacer(Modifier.width(NovaSpacing.sm))
                NovaButton(
                    text = "Clear",
                    style = NovaButtonStyle.TEXT,
                    onClick = {
                        AccessKeyManager.clearKey(context)
                        feedback = "Cleared saved key"
                    }
                )
            }
        }
    }
}
