package com.Lia.assistant.agent.core

data class TargetSpec(
    val textAnyOf: List<String> = emptyList(),
    val viewIdContains: List<String> = emptyList(),
    val editableOnly: Boolean = false,
    val clickableOnly: Boolean = false
)

object TargetResolver {
    fun resolve(observation: ScreenObservation, spec: TargetSpec): UiElement? {
        val candidates = observation.elements.filter { el ->
            if (spec.editableOnly && !el.editable) return@filter false
            if (spec.clickableOnly && !el.clickable) return@filter false
            true
        }

        if (spec.viewIdContains.isNotEmpty()) {
            for (vidPart in spec.viewIdContains) {
                val match = candidates.firstOrNull {
                    it.viewId.contains(vidPart, ignoreCase = true)
                }
                if (match != null) return match
            }
        }

        if (spec.textAnyOf.isNotEmpty()) {
            // Exact match first
            for (needle in spec.textAnyOf) {
                val exact = candidates.firstOrNull {
                    it.text.equals(needle, ignoreCase = true) ||
                        it.contentDescription.equals(needle, ignoreCase = true)
                }
                if (exact != null) return exact
            }
            // Contains match second
            for (needle in spec.textAnyOf) {
                val partial = candidates.firstOrNull {
                    it.text.contains(needle, ignoreCase = true) ||
                        it.contentDescription.contains(needle, ignoreCase = true)
                }
                if (partial != null) return partial
            }
        }

        if (spec.editableOnly) {
            return candidates.firstOrNull()
        }

        return null
    }
}

class UiActionExecutor(
    private val driver: ScreenDriver,
    private val observer: ScreenObserver
) {
    suspend fun clickAndVerify(
        observation: ScreenObservation,
        element: UiElement,
        expectTargetGone: Boolean = true
    ): ActionResult {
        val res = driver.clickElement(observation, element)
        when (res.status) {
            DriverStatus.STALE -> return ActionResult.Failed(FailureReason.STALE_OBSERVATION, res.detail)
            DriverStatus.NOT_FOUND -> return ActionResult.Failed(FailureReason.TARGET_NOT_FOUND, res.detail)
            DriverStatus.UNSUPPORTED -> return ActionResult.Failed(FailureReason.UNSUPPORTED, res.detail)
            DriverStatus.FAILED -> return ActionResult.Failed(FailureReason.ACTION_FAILED, res.detail)
            DriverStatus.OK -> Unit
        }

        if (!expectTargetGone) return ActionResult.Success(res.detail)

        val nextObs = observer.observe()
            ?: return ActionResult.Success("Clicked (no post-observation)")
        val stillSameScreenAndTarget = nextObs.windowStamp == observation.windowStamp &&
            nextObs.elements.any { it.id == element.id && it.label == element.label }

        return if (!stillSameScreenAndTarget) {
            ActionResult.Success("Verified UI changed after tap")
        } else {
            ActionResult.Failed(FailureReason.VERIFICATION_FAILED, "Target did not respond to tap")
        }
    }
}

class TextInputExecutor(
    private val driver: ScreenDriver,
    private val observer: ScreenObserver
) {
    suspend fun typeAndVerify(
        observation: ScreenObservation,
        element: UiElement,
        text: String
    ): ActionResult {
        val res = driver.setText(observation, element, text)
        when (res.status) {
            DriverStatus.STALE -> return ActionResult.Failed(FailureReason.STALE_OBSERVATION, res.detail)
            DriverStatus.NOT_FOUND -> return ActionResult.Failed(FailureReason.TARGET_NOT_FOUND, res.detail)
            DriverStatus.UNSUPPORTED -> return ActionResult.Failed(FailureReason.UNSUPPORTED, res.detail)
            DriverStatus.FAILED -> return ActionResult.Failed(FailureReason.ACTION_FAILED, res.detail)
            DriverStatus.OK -> Unit
        }

        val nextObs = observer.observe()
            ?: return ActionResult.Failed(FailureReason.VERIFICATION_FAILED, "Could not verify input")
        val verified = nextObs.elements.any {
            it.editable && it.text.contains(text.take(24), ignoreCase = false)
        }
        return if (verified) {
            ActionResult.Success("Text verified in field")
        } else {
            ActionResult.Failed(FailureReason.VERIFICATION_FAILED, "Entered text not observed in field")
        }
    }
}
