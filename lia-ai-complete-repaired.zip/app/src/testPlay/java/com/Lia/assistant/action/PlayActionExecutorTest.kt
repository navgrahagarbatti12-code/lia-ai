package com.Lia.assistant.action

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.Lia.assistant.voice.LiaToolCatalog
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PlayActionExecutorTest {

    @Test
    fun playToolCatalog_omitsAccessibilityAndSocialTools() {
        val decls = LiaToolCatalog.declarations()
        val names = (0 until decls.length()).map { decls.getJSONObject(it).getString("name") }.toSet()
        assertTrue(names.contains("open_app"))
        assertTrue(names.contains("call_contact"))
        assertTrue(names.contains("message_contact"))
        assertTrue(names.contains("build_website"))
        assertFalse(names.contains("read_screen"))
        assertFalse(names.contains("tap_text"))
        assertFalse(names.contains("execute_social_media_task"))
    }

    @Test
    fun playActionExecutor_rejectsAccessibilityToolsAndHandlesNoContactsPermission() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val unknownRes = ActionExecutor.execute(context, "read_screen", JSONObject())
        assertEquals("Unknown tool: read_screen", unknownRes.getString("error"))

        val callRes = ActionExecutor.execute(context, "call_contact", JSONObject().put("contact", "Mummy"))
        assertEquals("no_contacts_permission", callRes.getString("status"))
    }
}
